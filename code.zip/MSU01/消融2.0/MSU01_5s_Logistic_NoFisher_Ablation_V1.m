function MSU01_5s_Logistic_NoFisher_Ablation_V1
% MSU01 最终版消融实验
%
% 最终主模型：
% 5 s + Logistic + NoFisher
%
% 共10组：
% 1 Baseline      完整 Entropy + PLV + Granger，不使用Fisher
% 2 NoEntropy     去掉全部熵
% 3 NoPLV         去掉PLV
% 4 NoGranger     去掉Granger
% 5 NoApEn        去掉ApEn
% 6 NoFuzzyEn     去掉FuzzyEn
% 7 NoSampEn      去掉SampEn
% 8 NoPermEn      去掉PermEn
% 9 NoSpecEn      去掉SpecEn
% 10 WithFisher   完整特征 + Fisher Top50
%
% 固定设置：
% - 5秒窗口
% - 16通道
% - 每窗口440维 = 80熵 + 120 PLV + 240 Granger
% - 受试者分组LOPO
% - 训练折内缺失值处理
% - 训练折内标准化
% - Logistic: fitclinear + ridge + Lambda=1e-3
% - 测试受试者窗口分数取均值形成受试者级结果
%
% 输出目录：
% D:\Database\Schizophrenia\MSU\MSU01\消融实验2.0

clc;
close all;

rootDir = 'D:\Database\Schizophrenia\MSU\MSU01';
featureFile = fullfile(rootDir,'MSU01_window_features_V1.mat');
outDir = fullfile(rootDir,'消融实验2.0');

if ~isfile(featureFile)
    error('未找到特征缓存：%s',featureFile);
end

if ~exist(outDir,'dir')
    mkdir(outDir);
end

logFile = fullfile(outDir, ...
    'MSU01_5s_Logistic_NoFisher_Ablation_log_V1.txt');

if isfile(logFile)
    delete(logFile);
end

diary(logFile);
cleanupDiary = onCleanup(@() diary('off')); %#ok<NASGU>

totalTimer = tic;

fprintf('==================================================\n');
fprintf('MSU01 最终版 5秒 Logistic + NoFisher 消融实验\n');
fprintf('开始时间：%s\n',datestr(now));
fprintf('特征缓存：%s\n',featureFile);
fprintf('输出目录：%s\n',outDir);
fprintf('==================================================\n');

%% 读取5秒窗口特征
F = load(featureFile, ...
    'featureSets','labelSets','subjectSets', ...
    'windowSecs','ySubject','subjectIDs');

required = { ...
    'featureSets','labelSets','subjectSets', ...
    'windowSecs','ySubject'};

for k = 1:numel(required)
    if ~isfield(F,required{k})
        error('特征缓存缺少变量：%s',required{k});
    end
end

scaleIndex = find(double(F.windowSecs(:))==5,1);

if isempty(scaleIndex)
    error('特征缓存中没有5秒窗口特征。');
end

XAll = double(F.featureSets{scaleIndex});
yWindow = double(F.labelSets{scaleIndex}(:));
subjectWindow = double(F.subjectSets{scaleIndex}(:));
ySubject = double(F.ySubject(:));

valid = subjectWindow>0;

XAll = XAll(valid,:);
yWindow = yWindow(valid);
subjectWindow = subjectWindow(valid);

if size(XAll,2)~=440
    error('当前程序要求440维窗口特征，实际为%d维。', ...
        size(XAll,2));
end

nSubjects = numel(ySubject);

if max(subjectWindow)~=nSubjects
    error('窗口受试者索引最大值%d与受试者数%d不一致。', ...
        max(subjectWindow),nSubjects);
end

if isfield(F,'subjectIDs') && ...
        numel(F.subjectIDs)==nSubjects
    subjectIDs = string(F.subjectIDs(:));
else
    subjectIDs = compose("MSU%03d",(1:nSubjects)');
end

fprintf('受试者：%d，HC=%d，SZ=%d\n', ...
    nSubjects,sum(ySubject==0),sum(ySubject==1));

fprintf('5秒窗口总数：%d\n',size(XAll,1));
fprintf('每窗口特征：440维\n\n');

%% 特征索引
% 16通道：
% Entropy = 16×5 = 80
% PLV = 16×15/2 = 120
% Granger = 16×15 = 240

allIdx = 1:440;
entropyIdx = 1:80;
plvIdx = 81:200;
grangerIdx = 201:440;

% 每个通道5种熵顺序：
% ApEn, FuzzyEn, SampEn, PermEn, SpecEn

apenIdx = 1:5:76;
fuzzyIdx = 2:5:77;
sampenIdx = 3:5:78;
permenIdx = 4:5:79;
specenIdx = 5:5:80;

%% 10组最终消融配置
configuration = [ ...
    "Baseline"; ...
    "NoEntropy"; ...
    "NoPLV"; ...
    "NoGranger"; ...
    "NoApEn"; ...
    "NoFuzzyEn"; ...
    "NoSampEn"; ...
    "NoPermEn"; ...
    "NoSpecEn"; ...
    "WithFisher"];

ablationGroup = [ ...
    "Baseline"; ...
    "Module"; ...
    "Module"; ...
    "Module"; ...
    "EntropyLOO"; ...
    "EntropyLOO"; ...
    "EntropyLOO"; ...
    "EntropyLOO"; ...
    "EntropyLOO"; ...
    "Fisher"];

description = [ ...
    "完整Entropy + PLV + Granger，不使用Fisher"; ...
    "去掉全部Entropy，仅PLV + Granger，不使用Fisher"; ...
    "去掉PLV，仅Entropy + Granger，不使用Fisher"; ...
    "去掉Granger，仅Entropy + PLV，不使用Fisher"; ...
    "Leave-One-Out：去掉ApEn，不使用Fisher"; ...
    "Leave-One-Out：去掉FuzzyEn，不使用Fisher"; ...
    "Leave-One-Out：去掉SampEn，不使用Fisher"; ...
    "Leave-One-Out：去掉PermEn，不使用Fisher"; ...
    "Leave-One-Out：去掉SpecEn，不使用Fisher"; ...
    "完整440维特征，训练折内Fisher Top50"];

featureIndex = { ...
    allIdx; ...
    [plvIdx grangerIdx]; ...
    [entropyIdx grangerIdx]; ...
    [entropyIdx plvIdx]; ...
    setdiff(allIdx,apenIdx,'stable'); ...
    setdiff(allIdx,fuzzyIdx,'stable'); ...
    setdiff(allIdx,sampenIdx,'stable'); ...
    setdiff(allIdx,permenIdx,'stable'); ...
    setdiff(allIdx,specenIdx,'stable'); ...
    allIdx};

useFisher = [ ...
    false; false; false; false; false; ...
    false; false; false; false; true];

selectedFeatureCount = 50;
nConfigs = numel(configuration);

%% 结果容器
inputFeatureCount = zeros(nConfigs,1);
finalFeatureCount = zeros(nConfigs,1);

subjectAccuracy = zeros(nConfigs,1);
subjectSensitivity = zeros(nConfigs,1);
subjectSpecificity = zeros(nConfigs,1);
subjectPrecision = zeros(nConfigs,1);
subjectF1 = zeros(nConfigs,1);
subjectBalancedAccuracy = zeros(nConfigs,1);
subjectMCC = zeros(nConfigs,1);
subjectAUC = zeros(nConfigs,1);

windowAccuracy = zeros(nConfigs,1);
windowSensitivity = zeros(nConfigs,1);
windowSpecificity = zeros(nConfigs,1);
windowPrecision = zeros(nConfigs,1);
windowF1 = zeros(nConfigs,1);
windowBalancedAccuracy = zeros(nConfigs,1);
windowMCC = zeros(nConfigs,1);
windowAUC = zeros(nConfigs,1);

results = cell(nConfigs,1);

predictionTable = table( ...
    subjectIDs,ySubject, ...
    'VariableNames',{'SubjectID','TrueLabel'});

%% 运行10组消融
for configIndex = 1:nConfigs

    X = XAll(:,featureIndex{configIndex});
    inputFeatureCount(configIndex) = size(X,2);

    fprintf('\n==================================================\n');
    fprintf('[%d/%d] %s\n', ...
        configIndex,nConfigs,configuration(configIndex));

    fprintf('%s\n',description(configIndex));

    fprintf('输入维数：%d；Fisher：%d\n', ...
        size(X,2),useFisher(configIndex));

    result = runLogisticLOPO( ...
        X,yWindow,subjectWindow,ySubject, ...
        useFisher(configIndex),selectedFeatureCount);

    results{configIndex} = result;

    finalFeatureCount(configIndex) = ...
        result.SelectedFeatureCount;

    sm = result.SubjectMetrics;
    wm = result.WindowMetrics;

    subjectAccuracy(configIndex) = sm.Accuracy;
    subjectSensitivity(configIndex) = sm.Sensitivity;
    subjectSpecificity(configIndex) = sm.Specificity;
    subjectPrecision(configIndex) = sm.Precision;
    subjectF1(configIndex) = sm.F1;
    subjectBalancedAccuracy(configIndex) = ...
        sm.BalancedAccuracy;
    subjectMCC(configIndex) = sm.MCC;
    subjectAUC(configIndex) = sm.AUC;

    windowAccuracy(configIndex) = wm.Accuracy;
    windowSensitivity(configIndex) = wm.Sensitivity;
    windowSpecificity(configIndex) = wm.Specificity;
    windowPrecision(configIndex) = wm.Precision;
    windowF1(configIndex) = wm.F1;
    windowBalancedAccuracy(configIndex) = ...
        wm.BalancedAccuracy;
    windowMCC(configIndex) = wm.MCC;
    windowAUC(configIndex) = wm.AUC;

    predictionTable.(['Pred_' ...
        char(configuration(configIndex))]) = ...
        result.SubjectPredictedLabel;

    predictionTable.(['Score_' ...
        char(configuration(configIndex))]) = ...
        result.SubjectPatientScore;

    fprintf(['Acc=%.4f，Sen=%.4f，Spe=%.4f，' ...
        'F1=%.4f，BalAcc=%.4f，MCC=%.4f，AUC=%.4f\n'], ...
        sm.Accuracy,sm.Sensitivity,sm.Specificity, ...
        sm.F1,sm.BalancedAccuracy,sm.MCC,sm.AUC);
end

%% 汇总
metricsTable = table( ...
    ablationGroup,configuration,description, ...
    inputFeatureCount,finalFeatureCount,useFisher, ...
    subjectAccuracy,subjectSensitivity,subjectSpecificity, ...
    subjectPrecision,subjectF1,subjectBalancedAccuracy, ...
    subjectMCC,subjectAUC, ...
    windowAccuracy,windowSensitivity,windowSpecificity, ...
    windowPrecision,windowF1,windowBalancedAccuracy, ...
    windowMCC,windowAUC, ...
    'VariableNames',{ ...
    'AblationGroup','Configuration','Description', ...
    'InputFeatureCount','SelectedFeatureCount','UseFisher', ...
    'SubjectAccuracy','SubjectSensitivity','SubjectSpecificity', ...
    'SubjectPrecision','SubjectF1','SubjectBalancedAccuracy', ...
    'SubjectMCC','SubjectAUC', ...
    'WindowAccuracy','WindowSensitivity','WindowSpecificity', ...
    'WindowPrecision','WindowF1','WindowBalancedAccuracy', ...
    'WindowMCC','WindowAUC'});

% 所有Delta均相对于最终Baseline：
% 5s + Logistic + NoFisher
metricsTable.DeltaAccuracy = ...
    metricsTable.SubjectAccuracy - ...
    metricsTable.SubjectAccuracy(1);

metricsTable.DeltaBalancedAccuracy = ...
    metricsTable.SubjectBalancedAccuracy - ...
    metricsTable.SubjectBalancedAccuracy(1);

metricsTable.DeltaMCC = ...
    metricsTable.SubjectMCC - ...
    metricsTable.SubjectMCC(1);

metricsTable.DeltaAUC = ...
    metricsTable.SubjectAUC - ...
    metricsTable.SubjectAUC(1);

%% 自动找最关键模块与最关键熵
moduleMask = ...
    metricsTable.AblationGroup=="Module";

entropyMask = ...
    metricsTable.AblationGroup=="EntropyLOO";

moduleTable = metricsTable(moduleMask,:);
entropyTable = metricsTable(entropyMask,:);

[~,moduleIndex] = ...
    min(moduleTable.DeltaBalancedAccuracy);

[~,entropyIndex] = ...
    min(entropyTable.DeltaBalancedAccuracy);

mostImportantModule = ...
    moduleTable.Configuration(moduleIndex);

mostImportantEntropy = ...
    entropyTable.Configuration(entropyIndex);

%% 保存
metricsFile = fullfile(outDir, ...
    'MSU01_5s_Logistic_NoFisher_ablation_metrics_V1.xlsx');

predictionFile = fullfile(outDir, ...
    'MSU01_5s_Logistic_NoFisher_ablation_predictions_V1.xlsx');

matFile = fullfile(outDir, ...
    'MSU01_5s_Logistic_NoFisher_ablation_results_V1.mat');

summaryFile = fullfile(outDir, ...
    'MSU01_5s_Logistic_NoFisher_ablation_summary_V1.txt');

if isfile(metricsFile)
    delete(metricsFile);
end

if isfile(predictionFile)
    delete(predictionFile);
end

writetable(metricsTable,metricsFile, ...
    'Sheet','AblationMetrics', ...
    'FileType','spreadsheet');

writetable(moduleTable,metricsFile, ...
    'Sheet','ModuleAblation', ...
    'FileType','spreadsheet');

writetable(entropyTable,metricsFile, ...
    'Sheet','EntropyLOO', ...
    'FileType','spreadsheet');

fisherTable = metricsTable( ...
    metricsTable.Configuration=="Baseline" | ...
    metricsTable.Configuration=="WithFisher",:);

writetable(fisherTable,metricsFile, ...
    'Sheet','FisherComparison', ...
    'FileType','spreadsheet');

writetable(predictionTable,predictionFile, ...
    'FileType','spreadsheet');

save(matFile, ...
    'results','metricsTable','moduleTable','entropyTable', ...
    'fisherTable','predictionTable', ...
    'featureIndex','useFisher', ...
    'selectedFeatureCount','subjectIDs','ySubject', ...
    'mostImportantModule','mostImportantEntropy', ...
    '-v7.3');

writeSummary( ...
    summaryFile,metricsTable, ...
    mostImportantModule,mostImportantEntropy, ...
    featureFile);

fprintf('\n==================================================\n');
fprintf('最终版消融实验完成\n');
fprintf('Baseline：5s + Logistic + NoFisher\n');
fprintf('Baseline BA=%.4f，MCC=%.4f，AUC=%.4f\n', ...
    metricsTable.SubjectBalancedAccuracy(1), ...
    metricsTable.SubjectMCC(1), ...
    metricsTable.SubjectAUC(1));

fprintf('最关键模块消融：%s，DeltaBA=%+.4f\n', ...
    mostImportantModule, ...
    min(moduleTable.DeltaBalancedAccuracy));

fprintf('最关键单熵消融：%s，DeltaBA=%+.4f\n', ...
    mostImportantEntropy, ...
    min(entropyTable.DeltaBalancedAccuracy));

fprintf('Fisher Top50：DeltaBA=%+.4f\n', ...
    metricsTable.DeltaBalancedAccuracy( ...
    metricsTable.Configuration=="WithFisher"));

fprintf('\n主结果：%s\n',metricsFile);
fprintf('预测结果：%s\n',predictionFile);
fprintf('MAT结果：%s\n',matFile);
fprintf('摘要：%s\n',summaryFile);
fprintf('总耗时：%.1f分钟\n',toc(totalTimer)/60);
fprintf('结束时间：%s\n',datestr(now));
fprintf('==================================================\n');

end

%% =========================================================
%% Logistic + 受试者分组LOPO
%% =========================================================
function result = runLogisticLOPO( ...
    X,yWindow,subjectWindow,ySubject, ...
    useFisher,selectedFeatureCount)

nSubjects = numel(ySubject);
nWindows = size(X,1);

subjectPredictedLabel = zeros(nSubjects,1);
subjectPatientScore = zeros(nSubjects,1);

windowPredictedLabel = zeros(nWindows,1);
windowPatientScore = zeros(nWindows,1);

selectedFeatureIndex = cell(nSubjects,1);

for heldOutSubject = 1:nSubjects

    trainMask = ...
        subjectWindow~=heldOutSubject;

    testMask = ...
        subjectWindow==heldOutSubject;

    XTrain = X(trainMask,:);
    yTrain = yWindow(trainMask);
    XTest = X(testMask,:);

    %% 训练折中位数补缺失值
    featureMedian = finiteColumnMedian(XTrain);

    XTrain = replaceNonfinite( ...
        XTrain,featureMedian);

    XTest = replaceNonfinite( ...
        XTest,featureMedian);

    %% 训练折标准化
    trainingMean = mean(XTrain,1);
    trainingStd = std(XTrain,0,1);

    trainingStd(trainingStd<1e-12) = 1;

    XTrain = ...
        (XTrain-trainingMean)./trainingStd;

    XTest = ...
        (XTest-trainingMean)./trainingStd;

    %% Fisher只用于最后一组WithFisher
    if useFisher
        fisherScore = ...
            calculateFisherScore(XTrain,yTrain);

        [~,ranked] = ...
            sort(fisherScore,'descend');

        selected = ranked( ...
            1:min(selectedFeatureCount,size(XTrain,2)));
    else
        selected = 1:size(XTrain,2);
    end

    selectedFeatureIndex{heldOutSubject} = selected;

    %% Logistic
    model = fitclinear( ...
        XTrain(:,selected),yTrain, ...
        'Learner','logistic', ...
        'Regularization','ridge', ...
        'Lambda',1e-3, ...
        'ClassNames',[0;1]);

    [predictedLabel,score] = ...
        predict(model,XTest(:,selected));

    positiveColumn = ...
        find(model.ClassNames==1,1);

    patientScore = ...
        score(:,positiveColumn);

    windowPredictedLabel(testMask) = ...
        predictedLabel;

    windowPatientScore(testMask) = ...
        patientScore;

    %% 受试者级预测
    meanScore = mean(patientScore);

    subjectPatientScore(heldOutSubject) = ...
        meanScore;

    subjectPredictedLabel(heldOutSubject) = ...
        double(meanScore>=0.5);
end

result = struct();

result.SubjectPredictedLabel = ...
    subjectPredictedLabel;

result.SubjectPatientScore = ...
    subjectPatientScore;

result.WindowPredictedLabel = ...
    windowPredictedLabel;

result.WindowPatientScore = ...
    windowPatientScore;

result.SelectedFeatureIndex = ...
    selectedFeatureIndex;

if useFisher
    result.SelectedFeatureCount = ...
        min(selectedFeatureCount,size(X,2));
else
    result.SelectedFeatureCount = ...
        size(X,2);
end

result.SubjectMetrics = ...
    calculateMetrics( ...
    ySubject,subjectPredictedLabel, ...
    subjectPatientScore);

result.WindowMetrics = ...
    calculateMetrics( ...
    yWindow,windowPredictedLabel, ...
    windowPatientScore);

end

%% =========================================================
%% Fisher
%% =========================================================
function score = calculateFisherScore(X,y)

class0 = X(y==0,:);
class1 = X(y==1,:);

score = ...
    (mean(class1,1)-mean(class0,1)).^2 ./ ...
    (var(class0,0,1)+var(class1,0,1)+eps);

score(~isfinite(score)) = 0;

end

%% =========================================================
%% 缺失值
%% =========================================================
function medianValues = finiteColumnMedian(X)

medianValues = zeros(1,size(X,2));

for columnIndex = 1:size(X,2)

    values = X( ...
        isfinite(X(:,columnIndex)), ...
        columnIndex);

    if isempty(values)
        medianValues(columnIndex) = 0;
    else
        medianValues(columnIndex) = median(values);
    end
end

end

function X = replaceNonfinite(X,replacement)

for columnIndex = 1:size(X,2)

    invalid = ...
        ~isfinite(X(:,columnIndex));

    X(invalid,columnIndex) = ...
        replacement(columnIndex);
end

end

%% =========================================================
%% 指标
%% =========================================================
function metrics = calculateMetrics( ...
    trueLabel,predictedLabel,score)

trueLabel = double(trueLabel(:));
predictedLabel = double(predictedLabel(:));
score = double(score(:));

TN = sum( ...
    trueLabel==0 & predictedLabel==0);

FP = sum( ...
    trueLabel==0 & predictedLabel==1);

FN = sum( ...
    trueLabel==1 & predictedLabel==0);

TP = sum( ...
    trueLabel==1 & predictedLabel==1);

accuracy = ...
    (TP+TN)/max(TP+TN+FP+FN,1);

sensitivity = ...
    TP/max(TP+FN,1);

specificity = ...
    TN/max(TN+FP,1);

precision = ...
    TP/max(TP+FP,1);

f1 = ...
    2*precision*sensitivity / ...
    max(precision+sensitivity,eps);

balancedAccuracy = ...
    (sensitivity+specificity)/2;

mccDenominator = sqrt(max( ...
    (TP+FP)*(TP+FN)*(TN+FP)*(TN+FN), ...
    eps));

mcc = ...
    (TP*TN-FP*FN)/mccDenominator;

auc = ...
    calculateAUC(trueLabel,score);

metrics = struct();

metrics.Accuracy = accuracy;
metrics.Sensitivity = sensitivity;
metrics.Specificity = specificity;
metrics.Precision = precision;
metrics.F1 = f1;
metrics.BalancedAccuracy = balancedAccuracy;
metrics.MCC = mcc;
metrics.AUC = auc;
metrics.ConfusionMatrix = [TN FP;FN TP];

end

function auc = calculateAUC(y,score)

positiveScore = ...
    score(y==1);

negativeScore = ...
    score(y==0);

comparison = ...
    positiveScore(:)>negativeScore(:).';

ties = ...
    positiveScore(:)==negativeScore(:).';

auc = ...
    (sum(comparison(:)) + ...
    0.5*sum(ties(:))) / ...
    max(numel(positiveScore)* ...
    numel(negativeScore),1);

end

%% =========================================================
%% 摘要
%% =========================================================
function writeSummary( ...
    fileName,T,mostImportantModule, ...
    mostImportantEntropy,featureFile)

fid = fopen(fileName,'w');

if fid<0
    return;
end

cleanupFile = ...
    onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid, ...
    'MSU01 最终版 5秒 Logistic + NoFisher 消融实验\n');

fprintf(fid, ...
    '生成时间：%s\n',datestr(now));

fprintf(fid, ...
    '特征缓存：%s\n\n',featureFile);

fprintf(fid, ...
    'Baseline = 5s + Logistic + 完整440维 + NoFisher\n');

fprintf(fid, ...
    'Delta = 当前配置 - Baseline\n\n');

fprintf(fid, ...
    ['%-12s  Feature  Fisher  Acc      BalAcc   ' ...
    'MCC      AUC      dBalAcc\n'], ...
    'Config');

for k = 1:height(T)

    fprintf(fid, ...
        ['%-12s  %4d     %d       %.4f   %.4f   ' ...
        '%.4f   %.4f   %+.4f\n'], ...
        char(T.Configuration(k)), ...
        T.SelectedFeatureCount(k), ...
        T.UseFisher(k), ...
        T.SubjectAccuracy(k), ...
        T.SubjectBalancedAccuracy(k), ...
        T.SubjectMCC(k), ...
        T.SubjectAUC(k), ...
        T.DeltaBalancedAccuracy(k));
end

fprintf(fid,'\n');

fprintf(fid, ...
    '最关键模块消融：%s\n', ...
    char(mostImportantModule));

fprintf(fid, ...
    '最关键单熵消融：%s\n', ...
    char(mostImportantEntropy));

fisherRow = ...
    T.Configuration=="WithFisher";

fprintf(fid, ...
    'WithFisher相对Baseline：DeltaBA=%+.4f，DeltaMCC=%+.4f，DeltaAUC=%+.4f\n', ...
    T.DeltaBalancedAccuracy(fisherRow), ...
    T.DeltaMCC(fisherRow), ...
    T.DeltaAUC(fisherRow));

end
