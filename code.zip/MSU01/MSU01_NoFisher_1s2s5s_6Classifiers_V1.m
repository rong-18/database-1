function MSU01_NoFisher_1s2s5s_6Classifiers_V1
% MSU01 方案B：NoFisher全流程重跑
%
% 目的：
% 1) 1s / 2s / 5s 三种窗口全部取消 Fisher Top50；
% 2) 重新比较6个分类器；
% 3) 对存在随机性的 RBFSVM 与 RF 使用20个固定随机种子；
% 4) 重新判断 NoFisher 条件下最佳窗口与最佳分类器。
%
% 特征缓存：
% D:\Database\Schizophrenia\MSU\MSU01\MSU01_window_features_V1.mat
%
% 输出目录：
% D:\Database\Schizophrenia\MSU\MSU01\消融实验

clc;
close all;

rootDir = 'D:\Database\Schizophrenia\MSU\MSU01';
featureFile = fullfile(rootDir,'MSU01_window_features_V1.mat');
outDir = fullfile(rootDir,'消融实验');

if ~isfile(featureFile)
    error('未找到特征缓存：%s',featureFile);
end
if ~exist(outDir,'dir')
    mkdir(outDir);
end

logFile = fullfile(outDir, ...
    'MSU01_NoFisher_1s2s5s_6Classifiers_log_V1.txt');

if isfile(logFile)
    delete(logFile);
end

diary(logFile);
cleanupDiary = onCleanup(@() diary('off')); %#ok<NASGU>

totalTimer = tic;

%% 基本设置
targetWindowSecs = [1 2 5];

classifierCodes = { ...
    'LinearSVM','RBFSVM','Logistic','LDA','KNN','RF'};

classifierDescriptions = { ...
    '线性支持向量机','高斯核支持向量机','L2逻辑回归', ...
    '正则化线性判别分析','5近邻','随机森林'};

% RBFSVM的KernelScale='auto'以及RF都存在随机性。
% 两者做20个固定seed重复；其余4个确定性分类器只跑1次。
nStochasticRepeats = 20;
seeds = (20260727:20260746)';

numberOfTrees = 100;

fprintf('==================================================\n');
fprintf('MSU01 方案B：NoFisher 1s/2s/5s × 6分类器\n');
fprintf('开始时间：%s\n',datestr(now));
fprintf('特征缓存：%s\n',featureFile);
fprintf('结果目录：%s\n',outDir);
fprintf('RBFSVM / RF重复次数：%d\n',nStochasticRepeats);
fprintf('随机种子：%d - %d\n',seeds(1),seeds(end));
fprintf('RF树数量：%d\n',numberOfTrees);
fprintf('==================================================\n');

%% 读取特征缓存
F = load(featureFile, ...
    'featureSets','labelSets','subjectSets', ...
    'windowSecs','ySubject','subjectIDs');

required = {'featureSets','labelSets','subjectSets', ...
    'windowSecs','ySubject'};

for k = 1:numel(required)
    if ~isfield(F,required{k})
        error('特征缓存缺少变量：%s',required{k});
    end
end

windowSecs = double(F.windowSecs(:))';
ySubject = double(F.ySubject(:));
nSubjects = numel(ySubject);

if isfield(F,'subjectIDs') && numel(F.subjectIDs)==nSubjects
    subjectIDs = string(F.subjectIDs(:));
else
    subjectIDs = compose("MSU%03d",(1:nSubjects)');
end

fprintf('受试者：%d，HC=%d，SZ=%d\n', ...
    nSubjects,sum(ySubject==0),sum(ySubject==1));

%% 结果容器
summaryRows = {};
runRows = {};
predictionRows = {};

summaryRowIndex = 0;
runRowIndex = 0;
predictionRowIndex = 0;

allResults = cell(numel(targetWindowSecs),numel(classifierCodes));

%% 1s / 2s / 5s × 6分类器
for scaleCounter = 1:numel(targetWindowSecs)
    scaleSec = targetWindowSecs(scaleCounter);

    scaleIndex = find(windowSecs==scaleSec,1);
    if isempty(scaleIndex)
        error('特征缓存中没有%d秒窗口特征。',scaleSec);
    end

    X = double(F.featureSets{scaleIndex});
    yWindow = double(F.labelSets{scaleIndex}(:));
    subjectWindow = double(F.subjectSets{scaleIndex}(:));

    valid = subjectWindow>0;
    X = X(valid,:);
    yWindow = yWindow(valid);
    subjectWindow = subjectWindow(valid);

    if size(X,2)~=440
        error('%d秒窗口要求440维特征，实际为%d维。', ...
            scaleSec,size(X,2));
    end

    if max(subjectWindow)~=nSubjects
        error('%d秒窗口受试者索引与ySubject不一致。',scaleSec);
    end

    fprintf('\n==================================================\n');
    fprintf('%d秒窗口：%d个窗口，完整440维，不使用Fisher\n', ...
        scaleSec,size(X,1));
    fprintf('==================================================\n');

    for classifierIndex = 1:numel(classifierCodes)
        classifierCode = classifierCodes{classifierIndex};
        classifierDescription = classifierDescriptions{classifierIndex};

        if any(strcmp(classifierCode,{'RBFSVM','RF'}))
            repeatCount = nStochasticRepeats;
        else
            repeatCount = 1;
        end

        subjectMetricMatrix = zeros(repeatCount,8);
        windowMetricMatrix = zeros(repeatCount,8);
        classifierResults = cell(repeatCount,1);

        fprintf('\n[%ds] %s：重复%d次\n', ...
            scaleSec,classifierCode,repeatCount);

        for repeatIndex = 1:repeatCount
            if repeatCount==1
                currentSeed = seeds(1);
            else
                currentSeed = seeds(repeatIndex);
            end

            rng(currentSeed,'twister');

            result = runLOPONoFisher( ...
                X,yWindow,subjectWindow,ySubject, ...
                classifierCode,numberOfTrees);

            classifierResults{repeatIndex} = result;

            sm = result.SubjectMetrics;
            wm = result.WindowMetrics;

            subjectMetricMatrix(repeatIndex,:) = metricsToRow(sm);
            windowMetricMatrix(repeatIndex,:) = metricsToRow(wm);

            runRowIndex = runRowIndex + 1;
            runRows(runRowIndex,:) = { ...
                scaleSec,string(classifierCode), ...
                string(classifierDescription),repeatIndex,currentSeed, ...
                sm.Accuracy,sm.Sensitivity,sm.Specificity, ...
                sm.Precision,sm.F1,sm.BalancedAccuracy,sm.MCC,sm.AUC, ...
                wm.Accuracy,wm.Sensitivity,wm.Specificity, ...
                wm.Precision,wm.F1,wm.BalancedAccuracy,wm.MCC,wm.AUC};

            % 保存每一次受试者级预测，便于后续检查随机稳定性
            for subjectIndex = 1:nSubjects
                predictionRowIndex = predictionRowIndex + 1;
                predictionRows(predictionRowIndex,:) = { ...
                    scaleSec,string(classifierCode), ...
                    repeatIndex,currentSeed, ...
                    subjectIDs(subjectIndex),ySubject(subjectIndex), ...
                    result.SubjectPredictedLabel(subjectIndex), ...
                    result.SubjectPatientScore(subjectIndex)};
            end

            fprintf('  Repeat %02d/%02d Seed=%d：BA=%.4f MCC=%.4f AUC=%.4f\n', ...
                repeatIndex,repeatCount,currentSeed, ...
                sm.BalancedAccuracy,sm.MCC,sm.AUC);
        end

        allResults{scaleCounter,classifierIndex} = classifierResults;

        subjectMean = mean(subjectMetricMatrix,1);
        subjectStd = std(subjectMetricMatrix,0,1);

        windowMean = mean(windowMetricMatrix,1);
        windowStd = std(windowMetricMatrix,0,1);

        summaryRowIndex = summaryRowIndex + 1;
        summaryRows(summaryRowIndex,:) = { ...
            scaleSec,string(classifierCode),string(classifierDescription), ...
            repeatCount,440,false, ...
            subjectMean(1),subjectStd(1), ...
            subjectMean(2),subjectStd(2), ...
            subjectMean(3),subjectStd(3), ...
            subjectMean(4),subjectStd(4), ...
            subjectMean(5),subjectStd(5), ...
            subjectMean(6),subjectStd(6), ...
            subjectMean(7),subjectStd(7), ...
            subjectMean(8),subjectStd(8), ...
            windowMean(1),windowStd(1), ...
            windowMean(6),windowStd(6), ...
            windowMean(7),windowStd(7), ...
            windowMean(8),windowStd(8)};

        fprintf('  汇总：BA=%.4f ± %.4f，MCC=%.4f ± %.4f，AUC=%.4f ± %.4f\n', ...
            subjectMean(6),subjectStd(6), ...
            subjectMean(7),subjectStd(7), ...
            subjectMean(8),subjectStd(8));
    end
end

%% 汇总表
summaryTable = cell2table(summaryRows, ...
    'VariableNames',{ ...
    'ScaleSec','Classifier','ClassifierDescription', ...
    'RepeatCount','InputFeatureCount','UseFisher', ...
    'AccuracyMean','AccuracyStd', ...
    'SensitivityMean','SensitivityStd', ...
    'SpecificityMean','SpecificityStd', ...
    'PrecisionMean','PrecisionStd', ...
    'F1Mean','F1Std', ...
    'BalancedAccuracyMean','BalancedAccuracyStd', ...
    'MCCMean','MCCStd', ...
    'AUCMean','AUCStd', ...
    'WindowAccuracyMean','WindowAccuracyStd', ...
    'WindowBalancedAccuracyMean','WindowBalancedAccuracyStd', ...
    'WindowMCCMean','WindowMCCStd', ...
    'WindowAUCMean','WindowAUCStd'});

summaryTable.Classifier = string(summaryTable.Classifier);
summaryTable.ClassifierDescription = string(summaryTable.ClassifierDescription);

runTable = cell2table(runRows, ...
    'VariableNames',{ ...
    'ScaleSec','Classifier','ClassifierDescription', ...
    'Repeat','Seed', ...
    'SubjectAccuracy','SubjectSensitivity','SubjectSpecificity', ...
    'SubjectPrecision','SubjectF1','SubjectBalancedAccuracy', ...
    'SubjectMCC','SubjectAUC', ...
    'WindowAccuracy','WindowSensitivity','WindowSpecificity', ...
    'WindowPrecision','WindowF1','WindowBalancedAccuracy', ...
    'WindowMCC','WindowAUC'});

runTable.Classifier = string(runTable.Classifier);
runTable.ClassifierDescription = string(runTable.ClassifierDescription);

predictionTable = cell2table(predictionRows, ...
    'VariableNames',{ ...
    'ScaleSec','Classifier','Repeat','Seed', ...
    'SubjectID','TrueLabel','PredictedLabel','PatientScore'});

predictionTable.Classifier = string(predictionTable.Classifier);
predictionTable.SubjectID = string(predictionTable.SubjectID);

%% 每种窗口选择NoFisher最佳分类器
bestPerScaleRows = {};

for scaleCounter = 1:numel(targetWindowSecs)
    scaleSec = targetWindowSecs(scaleCounter);
    mask = summaryTable.ScaleSec==scaleSec;
    T = summaryTable(mask,:);

    [~,bestIndex] = max(T.BalancedAccuracyMean);
    bestPerScaleRows(scaleCounter,:) = { ...
        scaleSec,T.Classifier(bestIndex), ...
        T.ClassifierDescription(bestIndex), ...
        T.RepeatCount(bestIndex), ...
        T.AccuracyMean(bestIndex),T.AccuracyStd(bestIndex), ...
        T.BalancedAccuracyMean(bestIndex), ...
        T.BalancedAccuracyStd(bestIndex), ...
        T.MCCMean(bestIndex),T.MCCStd(bestIndex), ...
        T.AUCMean(bestIndex),T.AUCStd(bestIndex)};
end

bestPerScaleTable = cell2table(bestPerScaleRows, ...
    'VariableNames',{ ...
    'ScaleSec','BestClassifier','ClassifierDescription','RepeatCount', ...
    'AccuracyMean','AccuracyStd', ...
    'BalancedAccuracyMean','BalancedAccuracyStd', ...
    'MCCMean','MCCStd','AUCMean','AUCStd'});

bestPerScaleTable.BestClassifier = string(bestPerScaleTable.BestClassifier);
bestPerScaleTable.ClassifierDescription = string(bestPerScaleTable.ClassifierDescription);

[~,overallBestIndex] = max(bestPerScaleTable.BalancedAccuracyMean);
overallBestTable = bestPerScaleTable(overallBestIndex,:);

%% RF三种窗口20-seed专表
rfTable = summaryTable(summaryTable.Classifier=="RF",:);
rfRunTable = runTable(runTable.Classifier=="RF",:);

%% 可选：读取原Fisher主实验结果，形成RF Fisher vs NoFisher对照
comparisonTable = table();

resultCandidates = { ...
    fullfile(rootDir,'MSU01_EPG_6Cls_LOPO_results_V3.mat'), ...
    fullfile(rootDir,'MSU01_EPG_6Cls_LOPO_results_V2.mat'), ...
    fullfile(rootDir,'MSU01_EPG_6Cls_LOPO_results_V1.mat')};

originalResultFile = '';

for k = 1:numel(resultCandidates)
    if isfile(resultCandidates{k})
        originalResultFile = resultCandidates{k};
        break;
    end
end

if ~isempty(originalResultFile)
    R = load(originalResultFile,'results');

    if isfield(R,'results')
        comparisonRows = {};

        for scaleCounter = 1:numel(targetWindowSecs)
            scaleSec = targetWindowSecs(scaleCounter);

            fisherRF = [];
            for resultIndex = 1:numel(R.results)
                if iscell(R.results)
                    r = R.results{resultIndex};
                else
                    r = R.results(resultIndex);
                end

                if ~isempty(r) && ...
                        isfield(r,'ScaleSec') && ...
                        isfield(r,'Classifier') && ...
                        r.ScaleSec==scaleSec && ...
                        strcmp(r.Classifier,'RF')
                    fisherRF = r;
                    break;
                end
            end

            noFisherRow = rfTable(rfTable.ScaleSec==scaleSec,:);

            if ~isempty(fisherRF) && height(noFisherRow)==1
                fm = fisherRF.SubjectMetrics;

                comparisonRows(end+1,:) = { ... %#ok<AGROW>
                    scaleSec, ...
                    fm.Accuracy, ...
                    fm.BalancedAccuracy, ...
                    fm.MCC, ...
                    fm.AUC, ...
                    noFisherRow.AccuracyMean, ...
                    noFisherRow.AccuracyStd, ...
                    noFisherRow.BalancedAccuracyMean, ...
                    noFisherRow.BalancedAccuracyStd, ...
                    noFisherRow.MCCMean, ...
                    noFisherRow.MCCStd, ...
                    noFisherRow.AUCMean, ...
                    noFisherRow.AUCStd, ...
                    noFisherRow.BalancedAccuracyMean-fm.BalancedAccuracy, ...
                    noFisherRow.MCCMean-fm.MCC, ...
                    noFisherRow.AUCMean-fm.AUC};
            end
        end

        if ~isempty(comparisonRows)
            comparisonTable = cell2table(comparisonRows, ...
                'VariableNames',{ ...
                'ScaleSec', ...
                'FisherRF_Accuracy', ...
                'FisherRF_BalancedAccuracy', ...
                'FisherRF_MCC', ...
                'FisherRF_AUC', ...
                'NoFisherRF_AccuracyMean', ...
                'NoFisherRF_AccuracyStd', ...
                'NoFisherRF_BalancedAccuracyMean', ...
                'NoFisherRF_BalancedAccuracyStd', ...
                'NoFisherRF_MCCMean', ...
                'NoFisherRF_MCCStd', ...
                'NoFisherRF_AUCMean', ...
                'NoFisherRF_AUCStd', ...
                'DeltaBA_NoFisherMinusFisher', ...
                'DeltaMCC_NoFisherMinusFisher', ...
                'DeltaAUC_NoFisherMinusFisher'});
        end
    end
end

%% 保存
excelFile = fullfile(outDir, ...
    'MSU01_NoFisher_1s2s5s_6Classifiers_V1.xlsx');

matFile = fullfile(outDir, ...
    'MSU01_NoFisher_1s2s5s_6Classifiers_V1.mat');

summaryFile = fullfile(outDir, ...
    'MSU01_NoFisher_1s2s5s_6Classifiers_summary_V1.txt');

if isfile(excelFile)
    delete(excelFile);
end

writetable(summaryTable,excelFile, ...
    'Sheet','NoFisher_6Classifiers','FileType','spreadsheet');

writetable(bestPerScaleTable,excelFile, ...
    'Sheet','BestPerScale','FileType','spreadsheet');

writetable(overallBestTable,excelFile, ...
    'Sheet','OverallBest','FileType','spreadsheet');

writetable(rfTable,excelFile, ...
    'Sheet','RF20Seeds','FileType','spreadsheet');

writetable(rfRunTable,excelFile, ...
    'Sheet','RF20Runs','FileType','spreadsheet');

writetable(runTable,excelFile, ...
    'Sheet','AllRuns','FileType','spreadsheet');

writetable(predictionTable,excelFile, ...
    'Sheet','Predictions','FileType','spreadsheet');

if ~isempty(comparisonTable)
    writetable(comparisonTable,excelFile, ...
        'Sheet','RF_Fisher_vs_NoFisher','FileType','spreadsheet');
end

save(matFile, ...
    'summaryTable','runTable','predictionTable', ...
    'bestPerScaleTable','overallBestTable', ...
    'rfTable','rfRunTable','comparisonTable', ...
    'allResults','seeds','targetWindowSecs', ...
    'classifierCodes','classifierDescriptions', ...
    'numberOfTrees','featureFile','-v7.3');

writeSummary( ...
    summaryFile,summaryTable,bestPerScaleTable, ...
    overallBestTable,rfTable,comparisonTable, ...
    featureFile,seeds);

fprintf('\n==================================================\n');
fprintf('方案B运行完成\n');
fprintf('Excel：%s\n',excelFile);
fprintf('MAT：%s\n',matFile);
fprintf('摘要：%s\n',summaryFile);
fprintf('总耗时：%.1f分钟\n',toc(totalTimer)/60);
fprintf('结束时间：%s\n',datestr(now));
fprintf('==================================================\n');

fprintf('\nNoFisher各窗口最佳分类器：\n');
disp(bestPerScaleTable);

fprintf('NoFisher总体最佳：\n');
disp(overallBestTable);

end

%% =========================================================
%% NoFisher + 受试者分组LOPO
%% =========================================================
function result = runLOPONoFisher( ...
    X,yWindow,subjectWindow,ySubject, ...
    classifierCode,numberOfTrees)

nSubjects = numel(ySubject);
nWindows = size(X,1);

subjectPredictedLabel = zeros(nSubjects,1);
subjectPatientScore = zeros(nSubjects,1);
windowPredictedLabel = zeros(nWindows,1);
windowPatientScore = zeros(nWindows,1);

for heldOutSubject = 1:nSubjects
    trainMask = subjectWindow~=heldOutSubject;
    testMask = subjectWindow==heldOutSubject;

    XTrain = X(trainMask,:);
    yTrain = yWindow(trainMask);
    XTest = X(testMask,:);

    % 训练折中位数补缺失值
    featureMedian = finiteColumnMedian(XTrain);
    XTrain = replaceNonfinite(XTrain,featureMedian);
    XTest = replaceNonfinite(XTest,featureMedian);

    % 训练折标准化
    trainingMean = mean(XTrain,1);
    trainingStd = std(XTrain,0,1);
    trainingStd(trainingStd<1e-12) = 1;

    XTrain = (XTrain-trainingMean)./trainingStd;
    XTest = (XTest-trainingMean)./trainingStd;

    % 方案B：不执行Fisher，440维全部进入分类器
    model = trainClassifier( ...
        XTrain,yTrain,classifierCode,numberOfTrees);

    [predictedLabel,patientScore,decisionThreshold] = ...
        predictClassifier(model,XTest,classifierCode);

    windowPredictedLabel(testMask) = predictedLabel;
    windowPatientScore(testMask) = patientScore;

    % 与原主实验一致：测试受试者全部窗口分数取均值
    meanScore = mean(patientScore);
    subjectPatientScore(heldOutSubject) = meanScore;
    subjectPredictedLabel(heldOutSubject) = ...
        double(meanScore>=decisionThreshold);
end

result = struct();
result.SubjectPredictedLabel = subjectPredictedLabel;
result.SubjectPatientScore = subjectPatientScore;
result.WindowPredictedLabel = windowPredictedLabel;
result.WindowPatientScore = windowPatientScore;
result.SelectedFeatureCount = size(X,2);

result.SubjectMetrics = calculateMetrics( ...
    ySubject,subjectPredictedLabel,subjectPatientScore);

result.WindowMetrics = calculateMetrics( ...
    yWindow,windowPredictedLabel,windowPatientScore);
end

%% =========================================================
%% 分类器
%% =========================================================
function model = trainClassifier(X,y,classifierCode,numberOfTrees)

switch classifierCode
    case 'LinearSVM'
        model = fitcsvm(X,y, ...
            'KernelFunction','linear', ...
            'BoxConstraint',1, ...
            'ClassNames',[0;1]);

    case 'RBFSVM'
        model = fitcsvm(X,y, ...
            'KernelFunction','rbf', ...
            'KernelScale','auto', ...
            'BoxConstraint',1, ...
            'ClassNames',[0;1]);

    case 'Logistic'
        model = fitclinear(X,y, ...
            'Learner','logistic', ...
            'Regularization','ridge', ...
            'Lambda',1e-3, ...
            'ClassNames',[0;1]);

    case 'LDA'
        model = fitcdiscr(X,y, ...
            'DiscrimType','linear', ...
            'Gamma',0.1, ...
            'ClassNames',[0;1]);

    case 'KNN'
        model = struct();
        model.Type = 'ManualKNN';
        model.XTrain = X;
        model.YTrain = double(y(:));
        model.NumNeighbors = min(5,size(X,1));

    case 'RF'
        model = trainManualRandomForest(X,y,numberOfTrees);

    otherwise
        error('未知分类器：%s',classifierCode);
end
end

function [label,patientScore,threshold] = ...
    predictClassifier(model,X,classifierCode)

if strcmp(classifierCode,'RF')
    [label,patientScore] = predictManualRandomForest(model,X);
    threshold = 0.5;
    return;
end

if strcmp(classifierCode,'KNN')
    [label,patientScore] = predictManualKNN(model,X);
    threshold = 0.5;
    return;
end

[label,score] = predict(model,X);
classNames = model.ClassNames;
positiveColumn = find(classNames==1,1);
patientScore = score(:,positiveColumn);

if any(strcmp(classifierCode,{'LinearSVM','RBFSVM'}))
    threshold = 0;
else
    threshold = 0.5;
end
end

%% =========================================================
%% 手工KNN
%% =========================================================
function [label,patientScore] = predictManualKNN(model,XTest)

nTest = size(XTest,1);
patientScore = zeros(nTest,1);
k = model.NumNeighbors;

for testIndex = 1:nTest
    difference = bsxfun(@minus, ...
        model.XTrain,XTest(testIndex,:));

    squaredDistance = sum(difference.^2,2);
    [sortedDistance,order] = sort(squaredDistance,'ascend');

    neighborIndex = order(1:k);
    neighborDistance = sortedDistance(1:k);
    neighborLabel = model.YTrain(neighborIndex);

    zeroDistance = neighborDistance<=eps;

    if any(zeroDistance)
        patientScore(testIndex) = ...
            mean(neighborLabel(zeroDistance));
    else
        weight = 1./neighborDistance;
        patientScore(testIndex) = ...
            sum(weight.*neighborLabel)/sum(weight);
    end
end

label = double(patientScore>=0.5);
end

%% =========================================================
%% 纯MATLAB随机森林
%% =========================================================
function model = trainManualRandomForest(X,y,numberOfTrees)

y = double(y(:));
[nSamples,nFeatures] = size(X);

model = struct();
model.Type = 'ManualRF';
model.NumTrees = numberOfTrees;
model.Trees = cell(numberOfTrees,1);
model.MinLeafSize = 5;
model.MaxDepth = 10;
model.NumPredictorsToSample = ...
    max(1,floor(sqrt(nFeatures)));
model.MaxSplitCandidates = 16;

for treeIndex = 1:numberOfTrees
    bootstrapIndex = randi(nSamples,nSamples,1);

    model.Trees{treeIndex} = growManualTree( ...
        X(bootstrapIndex,:),y(bootstrapIndex),0, ...
        model.MinLeafSize,model.MaxDepth, ...
        model.NumPredictorsToSample, ...
        model.MaxSplitCandidates);
end
end

function node = growManualTree( ...
    X,y,depth,minLeafSize,maxDepth, ...
    predictorsPerSplit,maxSplitCandidates)

node = struct( ...
    'IsLeaf',true, ...
    'Probability',mean(y), ...
    'Feature',0, ...
    'Threshold',0, ...
    'Left',[], ...
    'Right',[]);

nSamples = size(X,1);

if depth>=maxDepth || ...
        nSamples<2*minLeafSize || ...
        all(y==y(1))
    return;
end

nFeatures = size(X,2);
featureOrder = randperm( ...
    nFeatures,min(predictorsPerSplit,nFeatures));

bestGini = inf;
bestFeature = 0;
bestThreshold = 0;

for featureIndex = featureOrder
    values = X(:,featureIndex);
    [sortedValues,order] = sort(values,'ascend');
    sortedLabels = y(order);

    splitPositions = (1:nSamples-1)';

    validMask = ...
        sortedValues(1:end-1)<sortedValues(2:end) & ...
        splitPositions>=minLeafSize & ...
        (nSamples-splitPositions)>=minLeafSize;

    validPosition = splitPositions(validMask);

    if isempty(validPosition)
        continue;
    end

    if numel(validPosition)>maxSplitCandidates
        selectedPosition = round(linspace( ...
            1,numel(validPosition),maxSplitCandidates));

        validPosition = ...
            validPosition(selectedPosition);
    end

    cumulativePositive = cumsum(sortedLabels==1);
    totalPositive = cumulativePositive(end);

    leftCount = validPosition;
    rightCount = nSamples-validPosition;

    leftPositive = cumulativePositive(validPosition);
    rightPositive = totalPositive-leftPositive;

    leftNegative = leftCount-leftPositive;
    rightNegative = rightCount-rightPositive;

    leftGini = 1- ...
        (leftPositive./leftCount).^2- ...
        (leftNegative./leftCount).^2;

    rightGini = 1- ...
        (rightPositive./rightCount).^2- ...
        (rightNegative./rightCount).^2;

    weightedGini = ...
        (leftCount.*leftGini+ ...
        rightCount.*rightGini)./nSamples;

    [featureBestGini,localIndex] = ...
        min(weightedGini);

    if featureBestGini<bestGini
        splitPosition = ...
            validPosition(localIndex);

        bestGini = featureBestGini;
        bestFeature = featureIndex;
        bestThreshold = ...
            (sortedValues(splitPosition)+ ...
            sortedValues(splitPosition+1))/2;
    end
end

if bestFeature==0
    return;
end

leftMask = X(:,bestFeature)<=bestThreshold;
rightMask = ~leftMask;

if sum(leftMask)<minLeafSize || ...
        sum(rightMask)<minLeafSize
    return;
end

node.IsLeaf = false;
node.Feature = bestFeature;
node.Threshold = bestThreshold;

node.Left = growManualTree( ...
    X(leftMask,:),y(leftMask), ...
    depth+1,minLeafSize,maxDepth, ...
    predictorsPerSplit,maxSplitCandidates);

node.Right = growManualTree( ...
    X(rightMask,:),y(rightMask), ...
    depth+1,minLeafSize,maxDepth, ...
    predictorsPerSplit,maxSplitCandidates);
end

function [label,patientScore] = ...
    predictManualRandomForest(model,X)

nSamples = size(X,1);
patientScore = zeros(nSamples,1);

for treeIndex = 1:model.NumTrees
    tree = model.Trees{treeIndex};

    for sampleIndex = 1:nSamples
        patientScore(sampleIndex) = ...
            patientScore(sampleIndex)+ ...
            predictManualTree(tree,X(sampleIndex,:));
    end
end

patientScore = patientScore/model.NumTrees;
label = double(patientScore>=0.5);
end

function probability = predictManualTree(node,sample)

while ~node.IsLeaf
    if sample(node.Feature)<=node.Threshold
        node = node.Left;
    else
        node = node.Right;
    end
end

probability = node.Probability;
end

%% =========================================================
%% 缺失值处理
%% =========================================================
function medianValues = finiteColumnMedian(X)

medianValues = zeros(1,size(X,2));

for columnIndex = 1:size(X,2)
    values = ...
        X(isfinite(X(:,columnIndex)),columnIndex);

    if isempty(values)
        medianValues(columnIndex) = 0;
    else
        medianValues(columnIndex) = median(values);
    end
end
end

function X = replaceNonfinite(X,replacement)

for columnIndex = 1:size(X,2)
    invalid = ~isfinite(X(:,columnIndex));
    X(invalid,columnIndex) = replacement(columnIndex);
end
end

%% =========================================================
%% 指标
%% =========================================================
function row = metricsToRow(metrics)

row = [ ...
    metrics.Accuracy, ...
    metrics.Sensitivity, ...
    metrics.Specificity, ...
    metrics.Precision, ...
    metrics.F1, ...
    metrics.BalancedAccuracy, ...
    metrics.MCC, ...
    metrics.AUC];
end

function metrics = calculateMetrics( ...
    trueLabel,predictedLabel,score)

trueLabel = double(trueLabel(:));
predictedLabel = double(predictedLabel(:));
score = double(score(:));

TN = sum(trueLabel==0 & predictedLabel==0);
FP = sum(trueLabel==0 & predictedLabel==1);
FN = sum(trueLabel==1 & predictedLabel==0);
TP = sum(trueLabel==1 & predictedLabel==1);

accuracy = ...
    (TP+TN)/max(TP+TN+FP+FN,1);

sensitivity = ...
    TP/max(TP+FN,1);

specificity = ...
    TN/max(TN+FP,1);

precision = ...
    TP/max(TP+FP,1);

f1 = ...
    2*precision*sensitivity/ ...
    max(precision+sensitivity,eps);

balancedAccuracy = ...
    (sensitivity+specificity)/2;

mccDenominator = sqrt(max( ...
    (TP+FP)*(TP+FN)*(TN+FP)*(TN+FN),eps));

mcc = ...
    (TP*TN-FP*FN)/mccDenominator;

auc = calculateAUC(trueLabel,score);

metrics = struct();
metrics.Accuracy = accuracy;
metrics.Sensitivity = sensitivity;
metrics.Specificity = specificity;
metrics.Precision = precision;
metrics.F1 = f1;
metrics.BalancedAccuracy = balancedAccuracy;
metrics.MCC = mcc;
metrics.AUC = auc;
metrics.ConfusionMatrix = [TN FP;FN TP];
end

function auc = calculateAUC(y,score)

positiveScore = score(y==1);
negativeScore = score(y==0);

comparison = ...
    positiveScore(:)>negativeScore(:).';

ties = ...
    positiveScore(:)==negativeScore(:).';

auc = ...
    (sum(comparison(:))+0.5*sum(ties(:))) / ...
    max(numel(positiveScore)*numel(negativeScore),1);
end

%% =========================================================
%% 摘要
%% =========================================================
function writeSummary( ...
    fileName,summaryTable,bestPerScaleTable, ...
    overallBestTable,rfTable,comparisonTable, ...
    featureFile,seeds)

fid = fopen(fileName,'w');

if fid<0
    return;
end

cleanupFile = onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid,'MSU01 方案B：NoFisher 1s/2s/5s × 6分类器\n');
fprintf(fid,'生成时间：%s\n',datestr(now));
fprintf(fid,'特征缓存：%s\n',featureFile);
fprintf(fid,'完整440维特征，不使用Fisher。\n');
fprintf(fid,'RBFSVM和RF随机种子：%d - %d，共%d次。\n\n', ...
    seeds(1),seeds(end),numel(seeds));

fprintf(fid,'================ NoFisher完整结果 ================\n');
fprintf(fid,'Scale  Classifier    BA(mean±std)       MCC(mean±std)      AUC(mean±std)\n');

for k = 1:height(summaryTable)
    fprintf(fid,'%ds     %-10s    %.4f ± %.4f      %.4f ± %.4f      %.4f ± %.4f\n', ...
        summaryTable.ScaleSec(k), ...
        char(summaryTable.Classifier(k)), ...
        summaryTable.BalancedAccuracyMean(k), ...
        summaryTable.BalancedAccuracyStd(k), ...
        summaryTable.MCCMean(k), ...
        summaryTable.MCCStd(k), ...
        summaryTable.AUCMean(k), ...
        summaryTable.AUCStd(k));
end

fprintf(fid,'\n================ 每种窗口最佳分类器 ================\n');

for k = 1:height(bestPerScaleTable)
    fprintf(fid,'%ds：%s，BA=%.4f ± %.4f，MCC=%.4f ± %.4f，AUC=%.4f ± %.4f\n', ...
        bestPerScaleTable.ScaleSec(k), ...
        char(bestPerScaleTable.BestClassifier(k)), ...
        bestPerScaleTable.BalancedAccuracyMean(k), ...
        bestPerScaleTable.BalancedAccuracyStd(k), ...
        bestPerScaleTable.MCCMean(k), ...
        bestPerScaleTable.MCCStd(k), ...
        bestPerScaleTable.AUCMean(k), ...
        bestPerScaleTable.AUCStd(k));
end

fprintf(fid,'\n================ NoFisher总体最佳 ================\n');
fprintf(fid,'%ds + %s：BA=%.4f ± %.4f，MCC=%.4f ± %.4f，AUC=%.4f ± %.4f\n', ...
    overallBestTable.ScaleSec(1), ...
    char(overallBestTable.BestClassifier(1)), ...
    overallBestTable.BalancedAccuracyMean(1), ...
    overallBestTable.BalancedAccuracyStd(1), ...
    overallBestTable.MCCMean(1), ...
    overallBestTable.MCCStd(1), ...
    overallBestTable.AUCMean(1), ...
    overallBestTable.AUCStd(1));

fprintf(fid,'\n================ RF 20-seed ================\n');

for k = 1:height(rfTable)
    fprintf(fid,'%ds RF：BA=%.4f ± %.4f，MCC=%.4f ± %.4f，AUC=%.4f ± %.4f\n', ...
        rfTable.ScaleSec(k), ...
        rfTable.BalancedAccuracyMean(k), ...
        rfTable.BalancedAccuracyStd(k), ...
        rfTable.MCCMean(k), ...
        rfTable.MCCStd(k), ...
        rfTable.AUCMean(k), ...
        rfTable.AUCStd(k));
end

if ~isempty(comparisonTable)
    fprintf(fid,'\n================ 原Fisher RF vs NoFisher RF ================\n');

    for k = 1:height(comparisonTable)
        fprintf(fid,'%ds：Fisher BA=%.4f；NoFisher BA=%.4f ± %.4f；Delta=%+.4f\n', ...
            comparisonTable.ScaleSec(k), ...
            comparisonTable.FisherRF_BalancedAccuracy(k), ...
            comparisonTable.NoFisherRF_BalancedAccuracyMean(k), ...
            comparisonTable.NoFisherRF_BalancedAccuracyStd(k), ...
            comparisonTable.DeltaBA_NoFisherMinusFisher(k));
    end
end
end
