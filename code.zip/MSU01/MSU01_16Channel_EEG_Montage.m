clc; clear; close all;

%% =========================================================
% MSU01_16Channel_EEG_Montage.m
%
% 功能：
%   根据 MSU01 实验中实际使用的 16 个 EEG 通道，
%   绘制标准 10-20 头皮电极布局示意图。
%
% 真实通道：
%   F7, F3, F4, F8,
%   T3, C3, Cz, C4, T4,
%   T5, P3, Pz, P4, T6,
%   O1, O2
%
% 说明：
%   - 图中文字保留数据集/实验中的原始旧式命名 T3/T4/T5/T6。
%   - 空间位置按标准 10-20 系统对应位置绘制：
%       T3 -> T7 位置
%       T4 -> T8 位置
%       T5 -> P7 位置
%       T6 -> P8 位置
%   - 不需要 EEGLAB 或其他额外工具箱。
%   - 输出 600 dpi PNG 和矢量 PDF。
%% =========================================================

%% 1. 输出目录
outputDir = 'D:\Database\Schizophrenia\MSU\MSU01';

if ~isfolder(outputDir)
    mkdir(outputDir);
end

pngFile = fullfile(outputDir, 'MSU01_16Channel_EEG_Montage.png');
pdfFile = fullfile(outputDir, 'MSU01_16Channel_EEG_Montage.pdf');
txtFile = fullfile(outputDir, 'MSU01_16Channel_List.txt');

%% 2. MSU01 实际使用的 16 个通道
labels = { ...
    'F7','F3','F4','F8', ...
    'T3','C3','Cz','C4','T4', ...
    'T5','P3','Pz','P4','T6', ...
    'O1','O2'};

%% 3. 标准 10-20 头皮二维位置
% 坐标系：
%   x < 0 = 左半球
%   x > 0 = 右半球
%   y > 0 = 前额
%   y < 0 = 枕部
%
% T3/T4/T5/T6 使用旧式命名，但位置分别对应 T7/T8/P7/P8。

pos = containers.Map();

pos('F7') = [-0.78,  0.56];
pos('F3') = [-0.38,  0.56];
pos('F4') = [ 0.38,  0.56];
pos('F8') = [ 0.78,  0.56];

pos('T3') = [-0.94,  0.03];   % 旧式 T3，对应现代 T7
pos('C3') = [-0.44,  0.03];
pos('CZ') = [ 0.00,  0.04];
pos('C4') = [ 0.44,  0.03];
pos('T4') = [ 0.94,  0.03];   % 旧式 T4，对应现代 T8

pos('T5') = [-0.78, -0.52];   % 旧式 T5，对应现代 P7
pos('P3') = [-0.38, -0.45];
pos('PZ') = [ 0.00, -0.46];
pos('P4') = [ 0.38, -0.45];
pos('T6') = [ 0.78, -0.52];   % 旧式 T6，对应现代 P8

pos('O1') = [-0.28, -0.82];
pos('O2') = [ 0.28, -0.82];

%% 4. 生成坐标矩阵
xy = zeros(numel(labels), 2);

for i = 1:numel(labels)
    key = upper(labels{i});

    if ~isKey(pos, key)
        error('未定义通道 %s 的标准位置。', labels{i});
    end

    xy(i,:) = pos(key);
end

%% 5. 绘图
fig = figure( ...
    'Color', 'w', ...
    'Position', [100 50 900 980], ...
    'Renderer', 'painters');

ax = axes('Parent', fig);
hold(ax, 'on');
axis(ax, 'equal');
axis(ax, [-1.22 1.22 -1.15 1.18]);
axis(ax, 'off');

%% 6. 头部轮廓
theta = linspace(0, 2*pi, 600);

% 略微椭圆，更接近示例图
headX = 1.00 * cos(theta);
headY = 1.04 * sin(theta) - 0.02;

plot(ax, headX, headY, ...
    'k', ...
    'LineWidth', 2.2);

%% 7. 鼻子
plot(ax, ...
    [-0.09 0 0.09], ...
    [1.01 1.15 1.01], ...
    'k', ...
    'LineWidth', 2.2);

%% 8. 左右耳
earT = linspace(-pi/2, pi/2, 120);

leftEarX  = -1.00 - 0.10*cos(earT);
leftEarY  =  0.21*sin(earT);

rightEarX =  1.00 + 0.10*cos(earT);
rightEarY =  0.21*sin(earT);

plot(ax, leftEarX, leftEarY, ...
    'k', 'LineWidth', 2.0);

plot(ax, rightEarX, rightEarY, ...
    'k', 'LineWidth', 2.0);

%% 9. 电极圆点
markerSize = 1250;

scatter(ax, xy(:,1), xy(:,2), markerSize, ...
    'Marker', 'o', ...
    'MarkerFaceColor', [0.30 0.31 0.56], ...
    'MarkerEdgeColor', 'k', ...
    'LineWidth', 0.8);

%% 10. 电极名称
for i = 1:numel(labels)

    text(ax, xy(i,1), xy(i,2), labels{i}, ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'middle', ...
        'Color', 'w', ...
        'FontName', 'Times New Roman', ...
        'FontSize', 15, ...
        'FontWeight', 'bold', ...
        'Interpreter', 'none');
end

%% 11. 标题
title(ax, 'MSU01 | 16-channel EEG montage', ...
    'FontName', 'Times New Roman', ...
    'FontSize', 20, ...
    'FontWeight', 'bold', ...
    'Interpreter', 'none');

%% 12. 保存 PNG
exportgraphics(fig, pngFile, ...
    'Resolution', 600, ...
    'BackgroundColor', 'white');

%% 13. 保存矢量 PDF
exportgraphics(fig, pdfFile, ...
    'ContentType', 'vector', ...
    'BackgroundColor', 'white');

%% 14. 保存通道列表
fid = fopen(txtFile, 'w', 'n', 'UTF-8');

if fid >= 0
    fprintf(fid, 'MSU01 - 16 EEG channels used in the experiment\n\n');

    for i = 1:numel(labels)
        fprintf(fid, '%02d\t%s\n', i, labels{i});
    end

    fprintf(fid, '\nNote:\n');
    fprintf(fid, 'T3/T4/T5/T6 are retained as the original channel names.\n');
    fprintf(fid, 'Their plotted positions correspond to the standard 10-20 T7/T8/P7/P8 locations.\n');

    fclose(fid);
end

%% 15. 输出信息
fprintf('\n========================================\n');
fprintf('MSU01 脑电通道布局图生成完成\n');
fprintf('通道数：%d\n', numel(labels));
fprintf('PNG：%s\n', pngFile);
fprintf('PDF：%s\n', pdfFile);
fprintf('通道列表：%s\n', txtFile);
fprintf('========================================\n');

close(fig);
