function MSU01_5s_Ablation_RF_V1
% MSU01：5秒窗口特征消融（论文主实验）
% 固定使用当前5秒基线最佳分类器 RF。
% 直接复用 MSU01_window_features_V1.mat，不重新提取EEG特征。
%
% 共10组：
% 1 Baseline
% 2 NoEntropy   3 NoPLV   4 NoGranger
% 5 NoApEn      6 NoFuzzyEn  7 NoSampEn  8 NoPermEn  9 NoSpecEn
% 10 NoFisher
%
% 主实验保持：
% - 5秒窗口
% - 16通道
% - 每窗口440维 = 80熵 + 120 PLV + 240 Granger
% - 受试者分组LOPO
% - 训练折内缺失值处理、标准化、Fisher Top50
% - 纯MATLAB随机森林100棵树
% - 测试受试者12个窗口概率取均值形成受试者级预测

clc;
close all;

rootDir = 'D:\Database\Schizophrenia\MSU\MSU01';
featureFile = fullfile(rootDir,'MSU01_window_features_V1.mat');
outDir = fullfile(rootDir,'消融实验');

if ~isfile(featureFile)
    error('未找到特征缓存：%s',featureFile);
end
if ~exist(outDir,'dir')
    mkdir(outDir);
end

logFile = fullfile(outDir,'MSU01_5s_Ablation_RF_log_V1.txt');
if isfile(logFile)
    delete(logFile);
end
diary(logFile);
cleanupDiary = onCleanup(@() diary('off')); %#ok<NASGU>

totalTimer = tic;

fprintf('==================================================\n');
fprintf('MSU01 5秒 RF 特征消融实验\n');
fprintf('开始时间：%s\n',datestr(now));
fprintf('特征缓存：%s\n',featureFile);
fprintf('结果目录：%s\n',outDir);
fprintf('==================================================\n');

%% 读取已有5秒窗口特征
F = load(featureFile, ...
    'featureSets','labelSets','subjectSets', ...
    'windowSets','windowSecs','ySubject','subjectIDs');

required = {'featureSets','labelSets','subjectSets','windowSecs','ySubject'};
for k = 1:numel(required)
    if ~isfield(F,required{k})
        error('特征缓存缺少变量：%s',required{k});
    end
end

scaleIndex = find(double(F.windowSecs(:))==5,1);
if isempty(scaleIndex)
    error('特征缓存中没有5秒窗口特征。');
end

XAll = double(F.featureSets{scaleIndex});
yWindow = double(F.labelSets{scaleIndex}(:));
subjectWindow = double(F.subjectSets{scaleIndex}(:));
ySubject = double(F.ySubject(:));

valid = subjectWindow>0;
XAll = XAll(valid,:);
yWindow = yWindow(valid);
subjectWindow = subjectWindow(valid);

if size(XAll,2)~=440
    error('当前程序要求440维窗口特征，实际为%d维。',size(XAll,2));
end

nSubjects = numel(ySubject);
if max(subjectWindow)~=nSubjects
    error('窗口受试者索引最大值%d与受试者数%d不一致。', ...
        max(subjectWindow),nSubjects);
end

if isfield(F,'subjectIDs') && numel(F.subjectIDs)==nSubjects
    subjectIDs = string(F.subjectIDs(:));
else
    subjectIDs = compose("MSU%03d",(1:nSubjects)');
end

fprintf('受试者：%d，HC=%d，SZ=%d\n', ...
    nSubjects,sum(ySubject==0),sum(ySubject==1));
fprintf('5秒窗口总数：%d；每窗口特征：440维\n',size(XAll,1));

%% 特征索引
% 16通道：
% Entropy = 16×5 = 80
% PLV = 16×15/2 = 120
% Granger = 16×15 = 240
allIdx = 1:440;
entropyIdx = 1:80;
plvIdx = 81:200;
grangerIdx = 201:440;

% 熵在每个通道内顺序：
% ApEn, FuzzyEn, SampEn, PermEn, SpecEn
apenIdx = 1:5:76;
fuzzyIdx = 2:5:77;
sampenIdx = 3:5:78;
permenIdx = 4:5:79;
specenIdx = 5:5:80;

%% 消融配置
configuration = [ ...
    "Baseline"; ...
    "NoEntropy"; ...
    "NoPLV"; ...
    "NoGranger"; ...
    "NoApEn"; ...
    "NoFuzzyEn"; ...
    "NoSampEn"; ...
    "NoPermEn"; ...
    "NoSpecEn"; ...
    "NoFisher"];

ablationGroup = [ ...
    "Baseline"; ...
    "Module"; ...
    "Module"; ...
    "Module"; ...
    "EntropyLOO"; ...
    "EntropyLOO"; ...
    "EntropyLOO"; ...
    "EntropyLOO"; ...
    "EntropyLOO"; ...
    "Fisher"];

description = [ ...
    "完整特征：Entropy + PLV + Granger；Fisher Top50"; ...
    "去掉全部熵特征，仅 PLV + Granger"; ...
    "去掉 PLV，仅 Entropy + Granger"; ...
    "去掉 Granger，仅 Entropy + PLV"; ...
    "Leave-One-Out：去掉近似熵 ApEn"; ...
    "Leave-One-Out：去掉模糊熵 FuzzyEn"; ...
    "Leave-One-Out：去掉样本熵 SampEn"; ...
    "Leave-One-Out：去掉排列熵 PermEn"; ...
    "Leave-One-Out：去掉谱熵 SpecEn"; ...
    "完整440维特征，不使用 Fisher 筛选"];

featureIndex = { ...
    allIdx; ...
    [plvIdx grangerIdx]; ...
    [entropyIdx grangerIdx]; ...
    [entropyIdx plvIdx]; ...
    setdiff(allIdx,apenIdx,'stable'); ...
    setdiff(allIdx,fuzzyIdx,'stable'); ...
    setdiff(allIdx,sampenIdx,'stable'); ...
    setdiff(allIdx,permenIdx,'stable'); ...
    setdiff(allIdx,specenIdx,'stable'); ...
    allIdx};

useFisher = [ ...
    true; true; true; true; true; ...
    true; true; true; true; false];

selectedFeatureCount = 50;
numberOfTrees = 100;
nConfigs = numel(configuration);

%% 结果容器
inputFeatureCount = zeros(nConfigs,1);
finalFeatureCount = zeros(nConfigs,1);

subjectAccuracy = zeros(nConfigs,1);
subjectSensitivity = zeros(nConfigs,1);
subjectSpecificity = zeros(nConfigs,1);
subjectPrecision = zeros(nConfigs,1);
subjectF1 = zeros(nConfigs,1);
subjectBalancedAccuracy = zeros(nConfigs,1);
subjectMCC = zeros(nConfigs,1);
subjectAUC = zeros(nConfigs,1);

windowAccuracy = zeros(nConfigs,1);
windowSensitivity = zeros(nConfigs,1);
windowSpecificity = zeros(nConfigs,1);
windowPrecision = zeros(nConfigs,1);
windowF1 = zeros(nConfigs,1);
windowBalancedAccuracy = zeros(nConfigs,1);
windowMCC = zeros(nConfigs,1);
windowAUC = zeros(nConfigs,1);

results = cell(nConfigs,1);

predictionTable = table( ...
    subjectIDs,ySubject, ...
    'VariableNames',{'SubjectID','TrueLabel'});

%% 10组消融
for configIndex = 1:nConfigs
    X = XAll(:,featureIndex{configIndex});
    inputFeatureCount(configIndex) = size(X,2);

    fprintf('\n==================================================\n');
    fprintf('[%d/%d] %s\n', ...
        configIndex,nConfigs,configuration(configIndex));
    fprintf('%s\n',description(configIndex));
    fprintf('输入维数：%d；Fisher：%d\n', ...
        size(X,2),useFisher(configIndex));

    % RF存在bootstrap与随机特征子集。
    % 每种消融从同一随机种子开始，降低随机波动对组间比较的影响。
    rng(20260727,'twister');

    result = runRFLOPO( ...
        X,yWindow,subjectWindow,ySubject, ...
        useFisher(configIndex), ...
        selectedFeatureCount,numberOfTrees);

    results{configIndex} = result;
    finalFeatureCount(configIndex) = result.SelectedFeatureCount;

    sm = result.SubjectMetrics;
    wm = result.WindowMetrics;

    subjectAccuracy(configIndex) = sm.Accuracy;
    subjectSensitivity(configIndex) = sm.Sensitivity;
    subjectSpecificity(configIndex) = sm.Specificity;
    subjectPrecision(configIndex) = sm.Precision;
    subjectF1(configIndex) = sm.F1;
    subjectBalancedAccuracy(configIndex) = sm.BalancedAccuracy;
    subjectMCC(configIndex) = sm.MCC;
    subjectAUC(configIndex) = sm.AUC;

    windowAccuracy(configIndex) = wm.Accuracy;
    windowSensitivity(configIndex) = wm.Sensitivity;
    windowSpecificity(configIndex) = wm.Specificity;
    windowPrecision(configIndex) = wm.Precision;
    windowF1(configIndex) = wm.F1;
    windowBalancedAccuracy(configIndex) = wm.BalancedAccuracy;
    windowMCC(configIndex) = wm.MCC;
    windowAUC(configIndex) = wm.AUC;

    predictionTable.(['Pred_' char(configuration(configIndex))]) = ...
        result.SubjectPredictedLabel;
    predictionTable.(['Score_' char(configuration(configIndex))]) = ...
        result.SubjectPatientScore;

    fprintf(['Acc=%.4f，Sen=%.4f，Spe=%.4f，F1=%.4f，' ...
        'BalAcc=%.4f，MCC=%.4f，AUC=%.4f\n'], ...
        sm.Accuracy,sm.Sensitivity,sm.Specificity,sm.F1, ...
        sm.BalancedAccuracy,sm.MCC,sm.AUC);
end

%% 汇总
metricsTable = table( ...
    ablationGroup,configuration,description, ...
    inputFeatureCount,finalFeatureCount,useFisher, ...
    subjectAccuracy,subjectSensitivity,subjectSpecificity, ...
    subjectPrecision,subjectF1,subjectBalancedAccuracy, ...
    subjectMCC,subjectAUC, ...
    windowAccuracy,windowSensitivity,windowSpecificity, ...
    windowPrecision,windowF1,windowBalancedAccuracy, ...
    windowMCC,windowAUC, ...
    'VariableNames',{ ...
    'AblationGroup','Configuration','Description', ...
    'InputFeatureCount','SelectedFeatureCount','UseFisher', ...
    'SubjectAccuracy','SubjectSensitivity','SubjectSpecificity', ...
    'SubjectPrecision','SubjectF1','SubjectBalancedAccuracy', ...
    'SubjectMCC','SubjectAUC', ...
    'WindowAccuracy','WindowSensitivity','WindowSpecificity', ...
    'WindowPrecision','WindowF1','WindowBalancedAccuracy', ...
    'WindowMCC','WindowAUC'});

metricsTable.DeltaAccuracy = ...
    metricsTable.SubjectAccuracy-metricsTable.SubjectAccuracy(1);
metricsTable.DeltaBalancedAccuracy = ...
    metricsTable.SubjectBalancedAccuracy- ...
    metricsTable.SubjectBalancedAccuracy(1);
metricsTable.DeltaMCC = ...
    metricsTable.SubjectMCC-metricsTable.SubjectMCC(1);
metricsTable.DeltaAUC = ...
    metricsTable.SubjectAUC-metricsTable.SubjectAUC(1);

%% 可选：与已有V3主结果的5秒RF核对
resultCandidates = { ...
    fullfile(rootDir,'MSU01_EPG_6Cls_LOPO_results_V3.mat'), ...
    fullfile(rootDir,'MSU01_EPG_6Cls_LOPO_results_V2.mat'), ...
    fullfile(rootDir,'MSU01_EPG_6Cls_LOPO_results_V1.mat')};

resultFile = '';
for k = 1:numel(resultCandidates)
    if isfile(resultCandidates{k})
        resultFile = resultCandidates{k};
        break;
    end
end

if ~isempty(resultFile)
    R = load(resultFile,'results');
    if isfield(R,'results')
        for k = 1:numel(R.results)
            r = R.results{k};
            if ~isempty(r) && isfield(r,'ScaleSec') && ...
                    isfield(r,'Classifier') && ...
                    r.ScaleSec==5 && strcmp(r.Classifier,'RF')
                fprintf('\n已有主结果核对：%s\n',resultFile);
                fprintf('主结果 BalAcc=%.6f，本次Baseline BalAcc=%.6f\n', ...
                    r.SubjectMetrics.BalancedAccuracy, ...
                    metricsTable.SubjectBalancedAccuracy(1));
                fprintf('主结果 Acc=%.6f，本次Baseline Acc=%.6f\n', ...
                    r.SubjectMetrics.Accuracy, ...
                    metricsTable.SubjectAccuracy(1));
                break;
            end
        end
    end
else
    fprintf('\n未找到V3/V2/V1主结果MAT，跳过Baseline核对；不影响消融运行。\n');
end

%% 保存
metricsFile = fullfile(outDir, ...
    'MSU01_5s_RF_ablation_metrics_V1.xlsx');
predictionFile = fullfile(outDir, ...
    'MSU01_5s_RF_ablation_predictions_V1.xlsx');
matFile = fullfile(outDir, ...
    'MSU01_5s_RF_ablation_results_V1.mat');
summaryFile = fullfile(outDir, ...
    'MSU01_5s_RF_ablation_summary_V1.txt');

writetable(metricsTable,metricsFile,'FileType','spreadsheet');
writetable(predictionTable,predictionFile,'FileType','spreadsheet');

save(matFile, ...
    'results','metricsTable','predictionTable', ...
    'featureIndex','useFisher','selectedFeatureCount', ...
    'numberOfTrees','ySubject','subjectIDs','-v7.3');

writeSummary(summaryFile,metricsTable,featureFile);

fprintf('\n==================================================\n');
fprintf('消融实验完成\n');
fprintf('主结果：%s\n',metricsFile);
fprintf('预测结果：%s\n',predictionFile);
fprintf('MAT结果：%s\n',matFile);
fprintf('摘要：%s\n',summaryFile);
fprintf('总耗时：%.1f分钟\n',toc(totalTimer)/60);
fprintf('结束时间：%s\n',datestr(now));
fprintf('==================================================\n');
end

%% =========================================================
%% RF + 受试者分组LOPO
%% =========================================================
function result = runRFLOPO( ...
    X,yWindow,subjectWindow,ySubject, ...
    useFisher,selectedFeatureCount,numberOfTrees)

nSubjects = numel(ySubject);
nWindows = size(X,1);

subjectPredictedLabel = zeros(nSubjects,1);
subjectPatientScore = zeros(nSubjects,1);
windowPredictedLabel = zeros(nWindows,1);
windowPatientScore = zeros(nWindows,1);
selectedFeatureIndex = cell(nSubjects,1);

for heldOutSubject = 1:nSubjects
    trainMask = subjectWindow~=heldOutSubject;
    testMask = subjectWindow==heldOutSubject;

    XTrain = X(trainMask,:);
    yTrain = yWindow(trainMask);
    XTest = X(testMask,:);

    % 训练折中位数补缺失值
    featureMedian = finiteColumnMedian(XTrain);
    XTrain = replaceNonfinite(XTrain,featureMedian);
    XTest = replaceNonfinite(XTest,featureMedian);

    % 训练折标准化
    trainingMean = mean(XTrain,1);
    trainingStd = std(XTrain,0,1);
    trainingStd(trainingStd<1e-12) = 1;

    XTrain = (XTrain-trainingMean)./trainingStd;
    XTest = (XTest-trainingMean)./trainingStd;

    % Fisher只在训练折计算
    if useFisher
        fisherScore = calculateFisherScore(XTrain,yTrain);
        [~,ranked] = sort(fisherScore,'descend');
        selected = ranked(1:min(selectedFeatureCount,size(XTrain,2)));
    else
        selected = 1:size(XTrain,2);
    end

    selectedFeatureIndex{heldOutSubject} = selected;

    model = trainManualRandomForest( ...
        XTrain(:,selected),yTrain,numberOfTrees);

    [predictedLabel,patientScore] = ...
        predictManualRandomForest( ...
        model,XTest(:,selected));

    windowPredictedLabel(testMask) = predictedLabel;
    windowPatientScore(testMask) = patientScore;

    % 与主实验一致：测试受试者全部窗口概率取均值
    meanScore = mean(patientScore);
    subjectPatientScore(heldOutSubject) = meanScore;
    subjectPredictedLabel(heldOutSubject) = ...
        double(meanScore>=0.5);
end

result = struct();
result.SubjectPredictedLabel = subjectPredictedLabel;
result.SubjectPatientScore = subjectPatientScore;
result.WindowPredictedLabel = windowPredictedLabel;
result.WindowPatientScore = windowPatientScore;
result.SelectedFeatureIndex = selectedFeatureIndex;

if useFisher
    result.SelectedFeatureCount = ...
        min(selectedFeatureCount,size(X,2));
else
    result.SelectedFeatureCount = size(X,2);
end

result.SubjectMetrics = calculateMetrics( ...
    ySubject,subjectPredictedLabel,subjectPatientScore);

result.WindowMetrics = calculateMetrics( ...
    yWindow,windowPredictedLabel,windowPatientScore);
end

%% =========================================================
%% Fisher
%% =========================================================
function score = calculateFisherScore(X,y)
class0 = X(y==0,:);
class1 = X(y==1,:);

score = ...
    (mean(class1,1)-mean(class0,1)).^2 ./ ...
    (var(class0,0,1)+var(class1,0,1)+eps);

score(~isfinite(score)) = 0;
end

%% =========================================================
%% 纯MATLAB随机森林：与MSU01 V3一致
%% =========================================================
function model = trainManualRandomForest(X,y,numberOfTrees)

y = double(y(:));
[nSamples,nFeatures] = size(X);

model = struct();
model.Type = 'ManualRF';
model.NumTrees = numberOfTrees;
model.Trees = cell(numberOfTrees,1);
model.MinLeafSize = 5;
model.MaxDepth = 10;
model.NumPredictorsToSample = ...
    max(1,floor(sqrt(nFeatures)));
model.MaxSplitCandidates = 16;

for treeIndex = 1:numberOfTrees
    bootstrapIndex = randi(nSamples,nSamples,1);

    model.Trees{treeIndex} = growManualTree( ...
        X(bootstrapIndex,:),y(bootstrapIndex),0, ...
        model.MinLeafSize,model.MaxDepth, ...
        model.NumPredictorsToSample, ...
        model.MaxSplitCandidates);
end
end

function node = growManualTree( ...
    X,y,depth,minLeafSize,maxDepth, ...
    predictorsPerSplit,maxSplitCandidates)

node = struct( ...
    'IsLeaf',true, ...
    'Probability',mean(y), ...
    'Feature',0, ...
    'Threshold',0, ...
    'Left',[], ...
    'Right',[]);

nSamples = size(X,1);

if depth>=maxDepth || ...
        nSamples<2*minLeafSize || ...
        all(y==y(1))
    return;
end

nFeatures = size(X,2);
featureOrder = randperm( ...
    nFeatures,min(predictorsPerSplit,nFeatures));

bestGini = inf;
bestFeature = 0;
bestThreshold = 0;

for featureIndex = featureOrder
    values = X(:,featureIndex);
    [sortedValues,order] = sort(values,'ascend');
    sortedLabels = y(order);

    splitPositions = (1:nSamples-1)';

    validMask = ...
        sortedValues(1:end-1)<sortedValues(2:end) & ...
        splitPositions>=minLeafSize & ...
        (nSamples-splitPositions)>=minLeafSize;

    validPosition = splitPositions(validMask);

    if isempty(validPosition)
        continue;
    end

    if numel(validPosition)>maxSplitCandidates
        selectedPosition = round(linspace( ...
            1,numel(validPosition),maxSplitCandidates));
        validPosition = validPosition(selectedPosition);
    end

    cumulativePositive = cumsum(sortedLabels==1);
    totalPositive = cumulativePositive(end);

    leftCount = validPosition;
    rightCount = nSamples-validPosition;

    leftPositive = cumulativePositive(validPosition);
    rightPositive = totalPositive-leftPositive;

    leftNegative = leftCount-leftPositive;
    rightNegative = rightCount-rightPositive;

    leftGini = 1- ...
        (leftPositive./leftCount).^2- ...
        (leftNegative./leftCount).^2;

    rightGini = 1- ...
        (rightPositive./rightCount).^2- ...
        (rightNegative./rightCount).^2;

    weightedGini = ...
        (leftCount.*leftGini+rightCount.*rightGini)./nSamples;

    [featureBestGini,localIndex] = min(weightedGini);

    if featureBestGini<bestGini
        splitPosition = validPosition(localIndex);

        bestGini = featureBestGini;
        bestFeature = featureIndex;
        bestThreshold = ...
            (sortedValues(splitPosition)+ ...
            sortedValues(splitPosition+1))/2;
    end
end

if bestFeature==0
    return;
end

leftMask = X(:,bestFeature)<=bestThreshold;
rightMask = ~leftMask;

if sum(leftMask)<minLeafSize || ...
        sum(rightMask)<minLeafSize
    return;
end

node.IsLeaf = false;
node.Feature = bestFeature;
node.Threshold = bestThreshold;

node.Left = growManualTree( ...
    X(leftMask,:),y(leftMask), ...
    depth+1,minLeafSize,maxDepth, ...
    predictorsPerSplit,maxSplitCandidates);

node.Right = growManualTree( ...
    X(rightMask,:),y(rightMask), ...
    depth+1,minLeafSize,maxDepth, ...
    predictorsPerSplit,maxSplitCandidates);
end

function [label,patientScore] = ...
    predictManualRandomForest(model,X)

nSamples = size(X,1);
patientScore = zeros(nSamples,1);

for treeIndex = 1:model.NumTrees
    tree = model.Trees{treeIndex};

    for sampleIndex = 1:nSamples
        patientScore(sampleIndex) = ...
            patientScore(sampleIndex)+ ...
            predictManualTree(tree,X(sampleIndex,:));
    end
end

patientScore = patientScore/model.NumTrees;
label = double(patientScore>=0.5);
end

function probability = predictManualTree(node,sample)
while ~node.IsLeaf
    if sample(node.Feature)<=node.Threshold
        node = node.Left;
    else
        node = node.Right;
    end
end
probability = node.Probability;
end

%% =========================================================
%% 缺失值
%% =========================================================
function medianValues = finiteColumnMedian(X)
medianValues = zeros(1,size(X,2));

for columnIndex = 1:size(X,2)
    values = X(isfinite(X(:,columnIndex)),columnIndex);

    if isempty(values)
        medianValues(columnIndex) = 0;
    else
        medianValues(columnIndex) = median(values);
    end
end
end

function X = replaceNonfinite(X,replacement)
for columnIndex = 1:size(X,2)
    invalid = ~isfinite(X(:,columnIndex));
    X(invalid,columnIndex) = replacement(columnIndex);
end
end

%% =========================================================
%% 指标
%% =========================================================
function metrics = calculateMetrics(trueLabel,predictedLabel,score)

trueLabel = double(trueLabel(:));
predictedLabel = double(predictedLabel(:));
score = double(score(:));

TN = sum(trueLabel==0 & predictedLabel==0);
FP = sum(trueLabel==0 & predictedLabel==1);
FN = sum(trueLabel==1 & predictedLabel==0);
TP = sum(trueLabel==1 & predictedLabel==1);

accuracy = (TP+TN)/max(TP+TN+FP+FN,1);
sensitivity = TP/max(TP+FN,1);
specificity = TN/max(TN+FP,1);
precision = TP/max(TP+FP,1);

f1 = ...
    2*precision*sensitivity/ ...
    max(precision+sensitivity,eps);

balancedAccuracy = ...
    (sensitivity+specificity)/2;

mccDenominator = sqrt(max( ...
    (TP+FP)*(TP+FN)*(TN+FP)*(TN+FN),eps));

mcc = ...
    (TP*TN-FP*FN)/mccDenominator;

auc = calculateAUC(trueLabel,score);

metrics = struct();
metrics.Accuracy = accuracy;
metrics.Sensitivity = sensitivity;
metrics.Specificity = specificity;
metrics.Precision = precision;
metrics.F1 = f1;
metrics.BalancedAccuracy = balancedAccuracy;
metrics.MCC = mcc;
metrics.AUC = auc;
metrics.ConfusionMatrix = [TN FP;FN TP];
end

function auc = calculateAUC(y,score)
positiveScore = score(y==1);
negativeScore = score(y==0);

comparison = ...
    positiveScore(:)>negativeScore(:).';

ties = ...
    positiveScore(:)==negativeScore(:).';

auc = ...
    (sum(comparison(:))+0.5*sum(ties(:))) / ...
    max(numel(positiveScore)*numel(negativeScore),1);
end

%% =========================================================
%% 摘要
%% =========================================================
function writeSummary(fileName,T,featureFile)

fid = fopen(fileName,'w');
cleanupFile = onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid,'MSU01 5秒 RF 特征消融\n');
fprintf(fid,'特征缓存：%s\n',featureFile);
fprintf(fid,'Delta = 当前消融 - Baseline\n\n');

fprintf(fid, ...
    '%-12s  Acc      BalAcc   MCC      AUC      dBalAcc\n', ...
    'Config');

for k = 1:height(T)
    fprintf(fid, ...
        '%-12s  %.4f   %.4f   %.4f   %.4f   %+.4f\n', ...
        char(T.Configuration(k)), ...
        T.SubjectAccuracy(k), ...
        T.SubjectBalancedAccuracy(k), ...
        T.SubjectMCC(k), ...
        T.SubjectAUC(k), ...
        T.DeltaBalancedAccuracy(k));
end
end
