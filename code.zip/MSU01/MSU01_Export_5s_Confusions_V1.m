function MSU01_Export_5s_Confusions_V1
% 从已有MSU01结果MAT文件直接导出全部5秒窗口混淆矩阵。
% 不重新提取特征，不重新训练分类器。
%
% 优先读取V3结果；不存在时依次读取V2、V1结果。

clc;
close all;

outDir = ...
    'D:\Database\Schizophrenia\MSU\MSU01';

resultCandidates = { ...
    fullfile(outDir, ...
    'MSU01_EPG_6Cls_LOPO_results_V3.mat'), ...
    fullfile(outDir, ...
    'MSU01_EPG_6Cls_LOPO_results_V2.mat'), ...
    fullfile(outDir, ...
    'MSU01_EPG_6Cls_LOPO_results_V1.mat')};

resultFile = '';

for index = 1:numel(resultCandidates)
    if isfile(resultCandidates{index})
        resultFile = resultCandidates{index};
        break;
    end
end

if isempty(resultFile)
    error('没有找到MSU01实验结果MAT文件。');
end

S = load(resultFile,'results');

if ~isfield(S,'results')
    error('结果文件不包含results变量：%s', ...
        resultFile);
end

outputDir = fullfile(outDir, ...
    'FiveSecond_Confusion_Matrices');

if ~exist(outputDir,'dir')
    mkdir(outputDir);
end

summaryTable = exportFiveSecond( ...
    S.results,outputDir);

writetable(summaryTable,fullfile(outDir, ...
    'MSU01_5s_confusion_summary.xlsx'), ...
    'FileType','spreadsheet');

fprintf('读取结果：%s\n',resultFile);
fprintf('已输出%d张5秒混淆矩阵：%s\n', ...
    height(summaryTable),outputDir);
end

function summaryTable = exportFiveSecond( ...
    results,outputDir)

rows = {};
writeIndex = 0;

for index = 1:numel(results)
    result = results{index};

    if isempty(result) || ...
            ~isfield(result,'ScaleSec') || ...
            result.ScaleSec~=5
        continue;
    end

    writeIndex = writeIndex+1;
    m = result.SubjectMetrics;
    C = m.ConfusionMatrix;
    classifier = string(result.Classifier);

    plotMatrix(C, ...
        sprintf('MSU 5s + %s',classifier), ...
        fullfile(outputDir,sprintf( ...
        'MSU01_5s_%s_confusion.png', ...
        classifier)));

    rows(writeIndex,:) = { ...
        5,classifier, ...
        C(1,1),C(1,2),C(2,1),C(2,2), ...
        m.Accuracy,m.Sensitivity,m.Specificity, ...
        m.Precision,m.F1,m.BalancedAccuracy, ...
        m.MCC,m.AUC}; %#ok<AGROW>
end

if isempty(rows)
    error('结果中没有找到5秒实验。');
end

summaryTable = cell2table(rows, ...
    'VariableNames',{ ...
    'ScaleSec','Classifier', ...
    'TN','FP','FN','TP', ...
    'Accuracy','Sensitivity','Specificity', ...
    'Precision','F1','BalancedAccuracy', ...
    'MCC','AUC'});
end

function plotMatrix(C,name,filePath)
figureHandle = figure( ...
    'Visible','off','Color','w', ...
    'Position',[100 100 760 660]);

imagesc(C);
axis equal tight;
colorbar;
xlabel('预测类别');
ylabel('真实类别');
title(['5秒窗口混淆矩阵：' char(name)], ...
    'Interpreter','none');

labels = {'HC (0)','SZ (1)'};

set(gca,'XTick',[1 2], ...
    'XTickLabel',labels, ...
    'YTick',[1 2], ...
    'YTickLabel',labels, ...
    'TickLabelInterpreter','none');

maximumValue = max(C(:));

for row = 1:2
    for column = 1:2
        if maximumValue>0 && ...
                C(row,column)>0.5*maximumValue
            textColor = 'w';
        else
            textColor = 'k';
        end

        text(column,row,num2str(C(row,column)), ...
            'HorizontalAlignment','center', ...
            'FontWeight','bold', ...
            'FontSize',14, ...
            'Color',textColor);
    end
end

set(figureHandle,'PaperPositionMode','auto');
print(figureHandle,filePath,'-dpng','-r300');
close(figureHandle);
end
