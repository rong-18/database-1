function MPHCED02_Direct_Waveform_Matching_V1
% MPHCED02：ECdata/EOdata的60秒MAT片段与原始EDF波形直接匹配
%
% 数据源：
% F:\Database\MPHCED-Depression\MDD Patients and Healthy Controls EEG Data
%
% 输出：
% D:\Database\Depression\MPHCED\MPHCED02\subject_mapping_V1
%
% 匹配原则：
% 1. ECdata.mat、EOdata.mat中的每一行均视为19通道×60秒MAT片段；
% 2. 在HEC/MEC/HEO/MEO中读取对应组别的全部原始EDF；
% 3. 每个EDF从第1个采样点开始，生成连续、不重叠的60秒候选窗口；
% 4. 使用19通道鲁棒标准化波形签名计算全部MAT—EDF候选距离；
% 5. 执行一对一全局匹配；
% 6. 使用完整19×15360波形计算通道相关系数和归一化RMSE复核；
% 7. 任何片段未通过阈值，程序停止，不生成可供实验使用的映射。
%
% 注意：
% - EDF只用于恢复受试者ID，不作为后续实验的特征数据源；
% - 后续实验仍使用ECdata.mat、EOdata.mat；
% - 标签：HC=0，MDD=1。

clc;
close all;
rng(20260727,'twister');

baseDir = ...
    'F:\Database\MPHCED-Depression\MDD Patients and Healthy Controls EEG Data';

outDir = ...
    'D:\Database\Depression\MPHCED\MPHCED02';

mappingDir = fullfile(outDir,'subject_mapping_V1');

if ~isfolder(baseDir)
    error('源数据目录不存在：%s',baseDir);
end

if ~exist(mappingDir,'dir')
    mkdir(mappingDir);
end

logFile = fullfile(mappingDir, ...
    'MPHCED02_direct_waveform_matching_log_V1.txt');

if isfile(logFile)
    delete(logFile);
end

diary(logFile);
cleanupDiary = onCleanup(@() diary('off')); %#ok<NASGU>

fprintf('开始时间：%s\n',datestr(now));
timerAll = tic;

%% 参数
fs = 256;
nChannels = 19;
segmentSamples = 15360;
signaturePointCount = 160;

minimumMedianCorrelation = 0.995;
minimumChannelCorrelation = 0.950;
maximumMedianNormalizedRMSE = 0.100;
maximumSignatureCost = 0.050;

channelNames = { ...
    'Fp1','F3','C3','P3','O1','F7','T3','T5','Fz', ...
    'Fp2','F4','C4','P4','O2','F8','T4','T6','Cz','Pz'};

%% 读取聚合MAT数据
ECdata = loadRequiredVariableDirect( ...
    fullfile(baseDir,'ECdata.mat'),'ECdata');

EClabel = double(loadRequiredVariableDirect( ...
    fullfile(baseDir,'EClable.mat'),'EClable'));
EClabel = EClabel(:);

EOdata = loadRequiredVariableDirect( ...
    fullfile(baseDir,'EOdata.mat'),'EOdata');

EOlabel = double(loadRequiredVariableDirect( ...
    fullfile(baseDir,'EOlable.mat'),'EOlable'));
EOlabel = EOlabel(:);

validateAggregateDirect( ...
    ECdata,EClabel,nChannels,segmentSamples,'EC');

validateAggregateDirect( ...
    EOdata,EOlabel,nChannels,segmentSamples,'EO');

fprintf('EC：片段=%d，HC=%d，MDD=%d\n', ...
    size(ECdata,1),sum(EClabel==0),sum(EClabel==1));

fprintf('EO：片段=%d，HC=%d，MDD=%d\n', ...
    size(EOdata,1),sum(EOlabel==0),sum(EOlabel==1));

%% EC直接匹配
ECmapping = directMatchState( ...
    baseDir,mappingDir,'EC',ECdata,EClabel, ...
    channelNames,fs,segmentSamples,signaturePointCount, ...
    minimumMedianCorrelation,minimumChannelCorrelation, ...
    maximumMedianNormalizedRMSE,maximumSignatureCost);

%% EO直接匹配
EOmapping = directMatchState( ...
    baseDir,mappingDir,'EO',EOdata,EOlabel, ...
    channelNames,fs,segmentSamples,signaturePointCount, ...
    minimumMedianCorrelation,minimumChannelCorrelation, ...
    maximumMedianNormalizedRMSE,maximumSignatureCost);

%% 保存实验主程序读取的映射
ECmapping = sortrows(ECmapping,'SegmentIndex');
EOmapping = sortrows(EOmapping,'SegmentIndex');

ECmappingFile = fullfile(mappingDir,'ECsubject_mapping.csv');
EOmappingFile = fullfile(mappingDir,'EOsubject_mapping.csv');

writetable(ECmapping,ECmappingFile);
writetable(EOmapping,EOmappingFile);

ECsubjectID = string(ECmapping.SubjectID); %#ok<NASGU>
EOsubjectID = string(EOmapping.SubjectID); %#ok<NASGU>

save(fullfile(mappingDir,'ECsubjectID.mat'), ...
    'ECsubjectID','-v7');

save(fullfile(mappingDir,'EOsubjectID.mat'), ...
    'EOsubjectID','-v7');

summary = vertcat( ...
    makeStateSummaryDirect(ECmapping,'EC'), ...
    makeStateSummaryDirect(EOmapping,'EO'));

writetable(summary,fullfile(mappingDir, ...
    'MPHCED02_direct_match_summary_V1.csv'));

fprintf('\n================================================\n');
fprintf('直接波形匹配全部完成。\n');
printStateSummaryDirect(ECmapping,'EC');
printStateSummaryDirect(EOmapping,'EO');
fprintf('映射目录：%s\n',mappingDir);
fprintf('总耗时：%.1f分钟\n',toc(timerAll)/60);
fprintf('结束时间：%s\n',datestr(now));
fprintf('\n下一步运行：\n');
fprintf(['MPHCED02_EC_EO_MSE_PLV_MVGC_' ...
    '6Classifiers_LOPO_V1\n']);
fprintf('================================================\n');
end

%% =========================================================
%% 状态和组别匹配
%% =========================================================
function mapping = directMatchState( ...
    baseDir,mappingDir,stateCode,aggregateData,labels, ...
    channelNames,fs,segmentSamples,signaturePointCount, ...
    minimumMedianCorrelation,minimumChannelCorrelation, ...
    maximumMedianNormalizedRMSE,maximumSignatureCost)

if strcmp(stateCode,'EC')
    healthyFolder = fullfile(baseDir,'HEC');
    patientFolder = fullfile(baseDir,'MEC');
else
    healthyFolder = fullfile(baseDir,'HEO');
    patientFolder = fullfile(baseDir,'MEO');
end

if ~isfolder(healthyFolder)
    error('缺少目录：%s',healthyFolder);
end
if ~isfolder(patientFolder)
    error('缺少目录：%s',patientFolder);
end

healthyRows = find(labels==0);
patientRows = find(labels==1);

fprintf('\n============================================\n');
fprintf('%s：健康组直接匹配\n',stateCode);
fprintf('============================================\n');

healthyMapping = directMatchGroup( ...
    aggregateData(healthyRows,:),healthyRows, ...
    healthyFolder,stateCode,0,channelNames,fs, ...
    segmentSamples,signaturePointCount, ...
    minimumMedianCorrelation,minimumChannelCorrelation, ...
    maximumMedianNormalizedRMSE,maximumSignatureCost, ...
    mappingDir);

fprintf('\n============================================\n');
fprintf('%s：MDD组直接匹配\n',stateCode);
fprintf('============================================\n');

patientMapping = directMatchGroup( ...
    aggregateData(patientRows,:),patientRows, ...
    patientFolder,stateCode,1,channelNames,fs, ...
    segmentSamples,signaturePointCount, ...
    minimumMedianCorrelation,minimumChannelCorrelation, ...
    maximumMedianNormalizedRMSE,maximumSignatureCost, ...
    mappingDir);

mapping = vertcat(healthyMapping,patientMapping);
mapping = sortrows(mapping,'SegmentIndex');

if height(mapping)~=size(aggregateData,1)
    error('%s匹配结果数量不完整。',stateCode);
end

if any(double(mapping.Label(:))~=labels(:))
    error('%s匹配结果标签顺序异常。',stateCode);
end

validateSubjectLabelsDirect(mapping,stateCode);
end

function mappingTable = directMatchGroup( ...
    groupData,globalRows,groupFolder,stateCode,labelValue, ...
    channelNames,fs,segmentSamples,signaturePointCount, ...
    minimumMedianCorrelation,minimumChannelCorrelation, ...
    maximumMedianNormalizedRMSE,maximumSignatureCost, ...
    mappingDir)

edfFiles = listEDFFilesDirect(groupFolder);
nMAT = size(groupData,1);
nChannels = numel(channelNames);

if isempty(edfFiles)
    error('%s中没有EDF文件。',groupFolder);
end

fprintf('%s/%s：MAT片段=%d，EDF文件=%d\n', ...
    stateCode,lastFolderDirect(groupFolder), ...
    nMAT,numel(edfFiles));

signatureIndices = unique(round(linspace( ...
    1,segmentSamples,signaturePointCount)));

signatureLength = nChannels*numel(signatureIndices);
matSignatures = zeros(nMAT,signatureLength,'single');

%% MAT签名
for matIndex = 1:nMAT
    XMAT = cellRowToChannelMatrixDirect(groupData(matIndex,:));

    matSignatures(matIndex,:) = single( ...
        robustSignatureDirect(XMAT,signatureIndices));

    if mod(matIndex,50)==0 || matIndex==nMAT
        fprintf('  MAT签名：%d/%d\n',matIndex,nMAT);
    end
end

%% EDF候选签名和元数据
candidateSignatures = zeros(0,signatureLength,'single');
candidateEDFIndex = zeros(0,1);
candidateWindowIndex = zeros(0,1);
candidateStartSample = zeros(0,1);
candidateSubjectID = strings(0,1);
candidateEDFName = strings(0,1);
candidateActualFs = zeros(0,1);

edfRows = cell(numel(edfFiles),1);

for edfIndex = 1:numel(edfFiles)
    edfPath = fullfile( ...
        edfFiles(edfIndex).folder,edfFiles(edfIndex).name);

    [XEDF,actualFs,matchedLabels] = ...
        readEDF19Direct(edfPath,channelNames,fs);

    nWindows = floor(size(XEDF,2)/segmentSamples);

    if nWindows<1
        error('EDF不足60秒：%s',edfPath);
    end

    subjectID = parseSubjectIDDirect( ...
        edfFiles(edfIndex).name,labelValue);

    if strlength(subjectID)==0
        error('无法从EDF文件名解析受试者：%s', ...
            edfFiles(edfIndex).name);
    end

    current = zeros(nWindows,signatureLength,'single');

    for windowIndex = 1:nWindows
        startSample = ...
            (windowIndex-1)*segmentSamples+1;
        indices = startSample:(startSample+segmentSamples-1);

        current(windowIndex,:) = single( ...
            robustSignatureDirect( ...
            XEDF(:,indices),signatureIndices));
    end

    oldCount = size(candidateSignatures,1);
    rows = oldCount+(1:nWindows);

    candidateSignatures(rows,:) = current;
    candidateEDFIndex(rows,1) = edfIndex;
    candidateWindowIndex(rows,1) = (1:nWindows)';
    candidateStartSample(rows,1) = ...
        ((0:nWindows-1)*segmentSamples+1)';
    candidateSubjectID(rows,1) = ...
        repmat(subjectID,nWindows,1);
    candidateEDFName(rows,1) = ...
        repmat(string(edfFiles(edfIndex).name),nWindows,1);
    candidateActualFs(rows,1) = actualFs;

    edfRows{edfIndex} = table( ...
        string(stateCode),labelValue,subjectID, ...
        string(edfFiles(edfIndex).name),actualFs, ...
        size(XEDF,2),size(XEDF,2)/actualFs,nWindows, ...
        strjoin(string(matchedLabels),','), ...
        'VariableNames',{ ...
        'State','Label','SubjectID','EDFFileName', ...
        'SamplingRate','TotalSamples','DurationSeconds', ...
        'Candidate60sWindows','MatchedChannelLabels'});

    fprintf(['  EDF %d/%d：%s，受试者=%s，' ...
        '时长=%.1f秒，候选=%d\n'], ...
        edfIndex,numel(edfFiles), ...
        edfFiles(edfIndex).name,subjectID, ...
        size(XEDF,2)/actualFs,nWindows);

    clear XEDF current;
end

edfTable = vertcat(edfRows{:});
writetable(edfTable,fullfile(mappingDir, ...
    sprintf('%s_label%d_EDF_inventory_V1.csv', ...
    stateCode,labelValue)));

nCandidates = size(candidateSignatures,1);

if nCandidates~=nMAT
    error([ ...
        '%s标签%d：原始EDF生成%d个非重叠60秒候选，' ...
        '聚合MAT有%d个片段。' newline ...
        '数量不等，说明MAT切分规则不是从EDF首点开始的连续60秒切分。' ...
        newline '程序停止，不使用推断映射。'], ...
        stateCode,labelValue,nCandidates,nMAT);
end

%% 全部候选距离和一对一分配
costMatrix = 1-double(matSignatures)* ...
    double(candidateSignatures)';
costMatrix = max(costMatrix,0);

assignment = solveAssignmentDirect(costMatrix);

if numel(unique(assignment))~=nMAT || any(assignment<1)
    error('%s标签%d一对一匹配失败。', ...
        stateCode,labelValue);
end

sortedCosts = sort(costMatrix,2,'ascend');
rowBestCost = sortedCosts(:,1);

if nCandidates>1
    secondBestCost = sortedCosts(:,2);
else
    secondBestCost = inf(nMAT,1);
end

assignedCost = zeros(nMAT,1);
for k = 1:nMAT
    assignedCost(k) = costMatrix(k,assignment(k));
end

%% 完整波形复核
medianCorrelation = nan(nMAT,1);
minimumCorrelation = nan(nMAT,1);
meanCorrelation = nan(nMAT,1);
medianNRMSE = nan(nMAT,1);
maximumNRMSE = nan(nMAT,1);
medianAffineNRMSE = nan(nMAT,1);

for edfIndex = 1:numel(edfFiles)
    matRows = find( ...
        candidateEDFIndex(assignment)==edfIndex);

    if isempty(matRows)
        continue;
    end

    edfPath = fullfile( ...
        edfFiles(edfIndex).folder,edfFiles(edfIndex).name);

    [XEDF,~,~] = readEDF19Direct( ...
        edfPath,channelNames,fs);

    for localIndex = 1:numel(matRows)
        matIndex = matRows(localIndex);
        candidateIndex = assignment(matIndex);
        startSample = candidateStartSample(candidateIndex);
        indices = startSample:(startSample+segmentSamples-1);

        XMAT = cellRowToChannelMatrixDirect( ...
            groupData(matIndex,:));
        XCandidate = XEDF(:,indices);

        C = compareWaveformsDirect(XMAT,XCandidate);

        medianCorrelation(matIndex) = C.MedianCorrelation;
        minimumCorrelation(matIndex) = C.MinimumCorrelation;
        meanCorrelation(matIndex) = C.MeanCorrelation;
        medianNRMSE(matIndex) = C.MedianNormalizedRMSE;
        maximumNRMSE(matIndex) = C.MaximumNormalizedRMSE;
        medianAffineNRMSE(matIndex) = ...
            C.MedianAffineNormalizedRMSE;
    end

    clear XEDF;
end

accepted = ...
    assignedCost<=maximumSignatureCost & ...
    medianCorrelation>=minimumMedianCorrelation & ...
    minimumCorrelation>=minimumChannelCorrelation & ...
    medianNRMSE<=maximumMedianNormalizedRMSE;

mappingTable = table( ...
    globalRows(:), ...
    repmat(string(stateCode),nMAT,1), ...
    repmat(labelValue,nMAT,1), ...
    candidateSubjectID(assignment), ...
    candidateEDFName(assignment), ...
    candidateWindowIndex(assignment), ...
    candidateStartSample(assignment), ...
    (candidateStartSample(assignment)-1)/fs, ...
    candidateActualFs(assignment), ...
    assignment(:),assignedCost,rowBestCost, ...
    secondBestCost,secondBestCost-rowBestCost, ...
    medianCorrelation,minimumCorrelation, ...
    meanCorrelation,medianNRMSE,maximumNRMSE, ...
    medianAffineNRMSE,accepted, ...
    repmat("MAT片段与EDF完整波形直接匹配",nMAT,1), ...
    'VariableNames',{ ...
    'SegmentIndex','State','Label','SubjectID', ...
    'SourceEDF','WindowWithinEDF','EDFStartSample', ...
    'EDFStartSecond','EDFSamplingRate', ...
    'AssignedCandidateIndex','SignatureCost', ...
    'RowBestSignatureCost','SecondBestSignatureCost', ...
    'BestSecondMargin','MedianChannelCorrelation', ...
    'MinimumChannelCorrelation','MeanChannelCorrelation', ...
    'MedianNormalizedRMSE','MaximumNormalizedRMSE', ...
    'MedianAffineNormalizedRMSE','MatchAccepted', ...
    'MappingSource'});

mappingTable = sortrows(mappingTable,'SegmentIndex');

diagnosticFile = fullfile(mappingDir, ...
    sprintf('%s_label%d_direct_match_diagnostics_V1.csv', ...
    stateCode,labelValue));
writetable(mappingTable,diagnosticFile);

if any(~accepted)
    failedFile = fullfile(mappingDir, ...
        sprintf('%s_label%d_low_confidence_V1.csv', ...
        stateCode,labelValue));
    writetable(mappingTable(~accepted,:),failedFile);

    error([ ...
        '%s标签%d有%d/%d个片段未通过直接匹配阈值。' ...
        newline '低置信度报告：%s' newline ...
        '请检查通道顺序、EDF读取方式或MAT切分规则。'], ...
        stateCode,labelValue,sum(~accepted), ...
        nMAT,failedFile);
end

fprintf(['%s标签%d全部通过：片段=%d，受试者=%d，' ...
    '签名距离中位数=%.10f，相关中位数=%.10f，' ...
    'NRMSE中位数=%.10f\n'], ...
    stateCode,labelValue,nMAT, ...
    numel(unique(mappingTable.SubjectID)), ...
    median(assignedCost),median(medianCorrelation), ...
    median(medianNRMSE));
end

%% =========================================================
%% EDF读取
%% =========================================================
function files = listEDFFilesDirect(folderPath)
items = dir(folderPath);
items = items(~[items.isdir]);

keep = false(numel(items),1);
for k = 1:numel(items)
    [~,~,extension] = fileparts(items(k).name);
    keep(k) = strcmpi(extension,'.edf');
end

files = items(keep);

if isempty(files)
    return;
end

[~,order] = sort(lower(string({files.name}')));
files = files(order);
end

function [X,actualFs,matchedOriginalLabels] = ...
    readEDF19Direct(edfPath,channelNames,expectedFs)

if exist('edfinfo','file')~=2 || ...
        exist('edfread','file')~=2
    error(['当前MATLAB缺少edfinfo或edfread。' ...
        '需要支持EDF读取的MATLAB版本。']);
end

info = edfinfo(edfPath);
originalLabels = string(info.SignalLabels(:));
normalizedLabels = strings(numel(originalLabels),1);

for k = 1:numel(originalLabels)
    normalizedLabels(k) = ...
        normalizeChannelLabelDirect(originalLabels(k));
end

selectedIndices = zeros(numel(channelNames),1);
matchedOriginalLabels = strings(numel(channelNames),1);

for channelIndex = 1:numel(channelNames)
    desired = upper(string(channelNames{channelIndex}));
    matches = find(normalizedLabels==desired);

    if numel(matches)~=1
        error(['EDF %s中通道%s匹配到%d项。' ...
            '全部标签：%s'], ...
            edfPath,desired,numel(matches), ...
            strjoin(originalLabels,', '));
    end

    selectedIndices(channelIndex) = matches;
    matchedOriginalLabels(channelIndex) = ...
        originalLabels(matches);
end

T = edfread(edfPath);
variableNames = T.Properties.VariableNames;

if numel(variableNames)<max(selectedIndices)
    error('EDF信号变量数不足：%s',edfPath);
end

signals = cell(numel(channelNames),1);
lengths = zeros(numel(channelNames),1);

for channelIndex = 1:numel(channelNames)
    variableName = variableNames{ ...
        selectedIndices(channelIndex)};
    signals{channelIndex} = ...
        concatenateEDFSignalDirect(T.(variableName));
    lengths(channelIndex) = numel(signals{channelIndex});
end

minimumLength = min(lengths);

if minimumLength<1
    error('EDF没有有效数据：%s',edfPath);
end

if any(lengths~=minimumLength)
    warning(['EDF %s所选通道长度不一致，' ...
        '截取为共同长度%d。'],edfPath,minimumLength);
end

X = zeros(numel(channelNames),minimumLength);
for channelIndex = 1:numel(channelNames)
    X(channelIndex,:) = ...
        signals{channelIndex}(1:minimumLength);
end

recordSeconds = durationSecondsDirect( ...
    info.DataRecordDuration);
totalSeconds = double(info.NumDataRecords)*recordSeconds;
actualFs = minimumLength/totalSeconds;

if abs(actualFs-expectedFs)>1e-6
    error('EDF %s采样率为%.9f Hz，预期%d Hz。', ...
        edfPath,actualFs,expectedFs);
end
end

function normalized = normalizeChannelLabelDirect(label)
normalized = upper(strtrim(string(label)));
normalized = regexprep(normalized,'^EEG\s*','');
normalized = regexprep(normalized,'[-_\s]*LE$','');
normalized = regexprep(normalized,'[^A-Z0-9]','');
end

function x = concatenateEDFSignalDirect(value)
if iscell(value)
    pieces = cell(numel(value),1);

    for k = 1:numel(value)
        pieces{k} = double(value{k}(:));
    end

    x = vertcat(pieces{:});

elseif isnumeric(value)
    value = double(value);

    if isvector(value)
        x = value(:);
    else
        x = reshape(value.',[],1);
    end

else
    try
        temporary = cell(value);
        pieces = cell(numel(temporary),1);

        for k = 1:numel(temporary)
            pieces{k} = double(temporary{k}(:));
        end

        x = vertcat(pieces{:});
    catch
        error('无法解析edfread返回类型：%s',class(value));
    end
end

x = double(x(:));
finiteMask = isfinite(x);

if ~all(finiteMask)
    if any(finiteMask)
        replacement = median(x(finiteMask));
    else
        replacement = 0;
    end
    x(~finiteMask) = replacement;
end
end

function secondsValue = durationSecondsDirect(value)
if isduration(value)
    secondsValue = seconds(value);
elseif isnumeric(value)
    secondsValue = double(value);
else
    textValue = string(value);
    try
        secondsValue = seconds(duration(textValue));
    catch
        secondsValue = str2double(textValue);
    end
end

secondsValue = double(secondsValue);

if ~isscalar(secondsValue) || ...
        ~isfinite(secondsValue) || secondsValue<=0
    error('无法解析EDF记录时长：%s',string(value));
end
end

%% =========================================================
%% 波形签名、匹配与复核
%% =========================================================
function X = cellRowToChannelMatrixDirect(cellRow)
nChannels = numel(cellRow);
nSamples = numel(cellRow{1});
X = zeros(nChannels,nSamples);

for channelIndex = 1:nChannels
    x = double(cellRow{channelIndex}(:))';

    if numel(x)~=nSamples
        error('同一MAT片段的通道长度不一致。');
    end

    finiteMask = isfinite(x);
    if ~all(finiteMask)
        if any(finiteMask)
            replacement = median(x(finiteMask));
        else
            replacement = 0;
        end
        x(~finiteMask) = replacement;
    end

    X(channelIndex,:) = x;
end
end

function signature = robustSignatureDirect(X,sampleIndices)
sampled = zeros(size(X,1),numel(sampleIndices));

for channelIndex = 1:size(X,1)
    x = double(X(channelIndex,:));
    center = median(x);
    scale = 1.4826*median(abs(x-center));

    if ~isfinite(scale) || scale<1e-12
        scale = std(x);
    end
    if ~isfinite(scale) || scale<1e-12
        scale = 1;
    end

    z = (x(sampleIndices)-center)/scale;
    z = max(min(z,12),-12);
    sampled(channelIndex,:) = z;
end

signature = sampled(:)';
signature = signature-mean(signature);
normalizer = sqrt(sum(signature.^2));

if normalizer<1e-12
    normalizer = 1;
end

signature = signature/normalizer;
end

function assignment = solveAssignmentDirect(costMatrix)
[nRows,nColumns] = size(costMatrix);

if nRows~=nColumns
    error('匹配代价矩阵必须为方阵。');
end

[~,independentBest] = min(costMatrix,[],2);

if numel(unique(independentBest))==nRows
    assignment = independentBest;
    return;
end

if exist('matchpairs','file')==2
    [pairs,~] = matchpairs(costMatrix,1e6,'min');

    assignment = zeros(nRows,1);
    assignment(pairs(:,1)) = pairs(:,2);

    if all(assignment>0) && ...
            numel(unique(assignment))==nRows
        return;
    end
end

[~,order] = sort(costMatrix(:),'ascend');
usedRows = false(nRows,1);
usedColumns = false(nColumns,1);
assignment = zeros(nRows,1);
assignedCount = 0;

for k = 1:numel(order)
    [row,column] = ind2sub(size(costMatrix),order(k));

    if ~usedRows(row) && ~usedColumns(column)
        assignment(row) = column;
        usedRows(row) = true;
        usedColumns(column) = true;
        assignedCount = assignedCount+1;

        if assignedCount==nRows
            break;
        end
    end
end

if assignedCount~=nRows
    error('一对一分配未覆盖全部片段。');
end
end

function C = compareWaveformsDirect(XMAT,XEDF)
if ~isequal(size(XMAT),size(XEDF))
    error('MAT和EDF候选波形尺寸不一致。');
end

nChannels = size(XMAT,1);
correlations = zeros(nChannels,1);
normalizedRMSE = zeros(nChannels,1);
affineNRMSE = zeros(nChannels,1);

for channelIndex = 1:nChannels
    a = double(XMAT(channelIndex,:));
    b = double(XEDF(channelIndex,:));

    aCentered = a-mean(a);
    bCentered = b-mean(b);

    aScale = std(aCentered);
    bScale = std(bCentered);

    if aScale<1e-12
        aScale = 1;
    end
    if bScale<1e-12
        bScale = 1;
    end

    za = aCentered/aScale;
    zb = bCentered/bScale;

    denominator = sqrt(sum(za.^2)*sum(zb.^2));
    if denominator<1e-12
        correlations(channelIndex) = 0;
    else
        correlations(channelIndex) = ...
            sum(za.*zb)/denominator;
    end

    normalizedRMSE(channelIndex) = ...
        sqrt(mean((za-zb).^2));

    design = [a(:),ones(numel(a),1)];
    beta = design\b(:);
    residual = b(:)-design*beta;

    affineNRMSE(channelIndex) = ...
        sqrt(mean(residual.^2))/max(std(b),eps);
end

C = struct();
C.MedianCorrelation = median(correlations);
C.MinimumCorrelation = min(correlations);
C.MeanCorrelation = mean(correlations);
C.MedianNormalizedRMSE = median(normalizedRMSE);
C.MaximumNormalizedRMSE = max(normalizedRMSE);
C.MedianAffineNormalizedRMSE = median(affineNRMSE);
end

function id = parseSubjectIDDirect(fileName,labelValue)
if labelValue==0
    token = regexp(fileName, ...
        '(?i)^H\s*S\s*(\d+)', ...
        'tokens','once');

    if isempty(token)
        id = "";
    else
        id = "HC_S"+compose( ...
            '%03d',str2double(token{1}));
    end
else
    token = regexp(fileName, ...
        '(?i)^MDD\s*S\s*(\d+)', ...
        'tokens','once');

    if isempty(token)
        id = "";
    else
        id = "MDD_S"+compose( ...
            '%03d',str2double(token{1}));
    end
end
end

%% =========================================================
%% 验证、摘要和基础读取
%% =========================================================
function value = loadRequiredVariableDirect(filePath,variableName)
if ~isfile(filePath)
    error('缺少文件：%s',filePath);
end

S = load(filePath,variableName);

if ~isfield(S,variableName)
    error('%s中缺少变量%s。',filePath,variableName);
end

value = S.(variableName);
end

function validateAggregateDirect( ...
    data,labels,nChannels,nSamples,stateCode)

if ~iscell(data)
    error('%sdata必须为cell。',stateCode);
end
if size(data,2)~=nChannels
    error('%sdata通道数为%d，预期%d。', ...
        stateCode,size(data,2),nChannels);
end
if size(data,1)~=numel(labels)
    error('%sdata行数与标签数不一致。',stateCode);
end
if any(~ismember(labels,[0 1]))
    error('%s标签包含0/1以外的值。',stateCode);
end

for row = 1:size(data,1)
    lengths = cellfun(@numel,data(row,:));
    if any(lengths~=nSamples)
        error('%s第%d行存在非%d点通道。', ...
            stateCode,row,nSamples);
    end
end
end

function validateSubjectLabelsDirect(mapping,stateCode)
subjects = unique(string(mapping.SubjectID),'stable');

for k = 1:numel(subjects)
    labels = unique(mapping.Label( ...
        string(mapping.SubjectID)==subjects(k)));

    if numel(labels)~=1
        error('%s受试者%s出现标签冲突。', ...
            stateCode,subjects(k));
    end
end
end

function T = makeStateSummaryDirect(mapping,stateCode)
T = table( ...
    string(stateCode),height(mapping), ...
    numel(unique(string(mapping.SubjectID))), ...
    numel(unique(string(mapping.SubjectID(mapping.Label==0)))), ...
    numel(unique(string(mapping.SubjectID(mapping.Label==1)))), ...
    median(mapping.SignatureCost),max(mapping.SignatureCost), ...
    median(mapping.MedianChannelCorrelation), ...
    min(mapping.MinimumChannelCorrelation), ...
    median(mapping.MedianNormalizedRMSE), ...
    max(mapping.MedianNormalizedRMSE), ...
    sum(mapping.MatchAccepted), ...
    'VariableNames',{ ...
    'State','NumSegments','NumSubjects','NumHC','NumMDD', ...
    'MedianSignatureCost','MaximumSignatureCost', ...
    'MedianChannelCorrelation', ...
    'MinimumChannelCorrelationOverall', ...
    'MedianNormalizedRMSE','MaximumMedianNormalizedRMSE', ...
    'AcceptedSegments'});
end

function printStateSummaryDirect(mapping,stateCode)
fprintf(['%s：片段=%d，受试者=%d，HC=%d，MDD=%d，' ...
    '相关中位数=%.8f，RMSE中位数=%.8f\n'], ...
    stateCode,height(mapping), ...
    numel(unique(string(mapping.SubjectID))), ...
    numel(unique(string(mapping.SubjectID(mapping.Label==0)))), ...
    numel(unique(string(mapping.SubjectID(mapping.Label==1)))), ...
    median(mapping.MedianChannelCorrelation), ...
    median(mapping.MedianNormalizedRMSE));
end

function name = lastFolderDirect(folderPath)
[~,name,~] = fileparts(folderPath);
end
