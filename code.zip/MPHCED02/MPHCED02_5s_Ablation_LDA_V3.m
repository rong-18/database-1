function MPHCED02_5s_Ablation_LDA_V3
% MPHCED02：5秒窗口特征消融（论文主实验）
%
% 固定使用当前5秒主结果：EC_EO + LDA。
% 直接复用主实验已经保存的受试者级特征文件，不重新提取EEG特征。
% 优先读取 MPHCED02_subject_features_V3.mat；
% 若不存在，则自动读取 MPHCED02_subject_features_V2.mat。
%
% EC或EO每名受试者：
%   608维窗口特征的均值 + 608维标准差 = 1216维
% EC_EO：
%   EC 1216维 + EO 1216维 = 2432维
%
% 共10组：
% 1 Baseline
% 2 NoEntropy   3 NoPLV   4 NoGranger
% 5 NoApEn      6 NoFuzzyEn  7 NoSampEn  8 NoPermEn  9 NoSpecEn
% 10 NoFisher
%
% Baseline及除NoFisher外的消融：训练折内Fisher Top15。
% NoFisher：完整保留对应配置的全部输入特征。

clc;
close all;
rng(20260725,'twister');

%% 路径
rootDir = 'D:\Database\Depression\MPHCED\MPHCED02';
baseDir = ...
    'F:\Database\MPHCED-Depression\MDD Patients and Healthy Controls EEG Data';
outDir = fullfile(rootDir,'消融实验');

featureCandidates = { ...
    fullfile(rootDir,'MPHCED02_subject_features_V3.mat'), ...
    fullfile(rootDir,'MPHCED02_subject_features_V2.mat')};

sourceFeatureFile = '';
for k = 1:numel(featureCandidates)
    if isfile(featureCandidates{k})
        sourceFeatureFile = featureCandidates{k};
        break;
    end
end

if isempty(sourceFeatureFile)
    error(['未找到受试者级特征文件。请确认以下任一文件存在：\n' ...
        '%s\n%s'],featureCandidates{1},featureCandidates{2});
end

if ~exist(outDir,'dir')
    mkdir(outDir);
end

logFile = fullfile(outDir, ...
    'MPHCED02_5s_Ablation_LDA_log_V3.txt');
if exist(logFile,'file')
    delete(logFile);
end
diary(logFile);
cleanupDiary = onCleanup(@() diary('off')); %#ok<NASGU>

totalTimer = tic;
fprintf('MPHCED02 5秒 LDA 特征消融\n');
fprintf('开始时间：%s\n',datestr(now));
fprintf('源特征：%s\n',sourceFeatureFile);
fprintf('输出目录：%s\n\n',outDir);

%% 读取主实验已保存的受试者级特征
S = load(sourceFeatureFile,'stateFeatures','windowSecs');

if ~isfield(S,'stateFeatures') || ...
        ~isfield(S.stateFeatures,'EC') || ...
        ~isfield(S.stateFeatures,'EO')
    error('特征文件中缺少stateFeatures.EC或stateFeatures.EO。');
end

if ~isfield(S,'windowSecs')
    error('特征文件中缺少windowSecs。');
end

scaleIndex = find(double(S.windowSecs(:))==5,1);
if isempty(scaleIndex)
    error('特征文件中没有5秒窗口特征。');
end

ECsubjects = string(S.stateFeatures.EC.Subjects(:));
EOsubjects = string(S.stateFeatures.EO.Subjects(:));
subjects = intersect(ECsubjects,EOsubjects,'stable');

[foundEC,ecIndex] = ismember(subjects,ECsubjects);
[foundEO,eoIndex] = ismember(subjects,EOsubjects);

if any(~foundEC) || any(~foundEO)
    error('EC/EO共同受试者索引构建失败。');
end

labelsEC = double(S.stateFeatures.EC.Labels(ecIndex));
labelsEO = double(S.stateFeatures.EO.Labels(eoIndex));

if any(labelsEC~=labelsEO)
    error('EC与EO共同受试者存在标签冲突。');
end

XEC = double(S.stateFeatures.EC.FeatureSets{scaleIndex}(ecIndex,:));
XEO = double(S.stateFeatures.EO.FeatureSets{scaleIndex}(eoIndex,:));

XAll = [XEC,XEO];
y = labelsEC(:);

if size(XAll,1)~=numel(y) || numel(subjects)~=numel(y)
    error('EC_EO受试者、标签和特征行数不一致。');
end
if size(XAll,2)~=2432
    error('当前程序要求EC_EO为2432维，实际为%d维。',size(XAll,2));
end

fprintf('条件：EC_EO\n');
fprintf('受试者：%d，HC=%d，MDD=%d\n', ...
    numel(y),sum(y==0),sum(y==1));
fprintf('5秒受试者级特征：2432维\n');
fprintf('固定分类器：LDA，Gamma=0.1\n');
fprintf('Baseline Fisher：Top15\n\n');

%% 混杂校正：与主实验保持同一规则
% 主实验只有在存在MPHCED_subject_covariates.csv时才启用。
covariates = [];
confoundUsed = false;

covariateCandidates = { ...
    fullfile(baseDir,'MPHCED_subject_covariates.csv'), ...
    fullfile(rootDir,'MPHCED_subject_covariates.csv')};

for k = 1:numel(covariateCandidates)
    if isfile(covariateCandidates{k})
        confoundUsed = true;
        break;
    end
end

if confoundUsed
    covariateTable = loadCovariates(baseDir,rootDir);
    covariates = alignCovariates(covariateTable,subjects);
    fprintf('检测到个体级协变量，启用训练折内年龄/性别混杂校正。\n\n');
else
    fprintf('未检测到个体级协变量，本次不执行混杂校正。\n\n');
end

%% 特征索引
% 每个状态1216维：
% [Mean_608, Std_608]
% 每个608维：Entropy 95 + PLV 171 + Granger 342。
stateOffsets = [0 1216];
statOffsets = [0 608];

entropyLocal = 1:95;
plvLocal = 96:266;
grangerLocal = 267:608;

apenLocal = 1:5:91;
fuzzyLocal = 2:5:92;
sampenLocal = 3:5:93;
permenLocal = 4:5:94;
specenLocal = 5:5:95;

entropyIdx = expandIndices(entropyLocal,stateOffsets,statOffsets);
plvIdx = expandIndices(plvLocal,stateOffsets,statOffsets);
grangerIdx = expandIndices(grangerLocal,stateOffsets,statOffsets);

apenIdx = expandIndices(apenLocal,stateOffsets,statOffsets);
fuzzyIdx = expandIndices(fuzzyLocal,stateOffsets,statOffsets);
sampenIdx = expandIndices(sampenLocal,stateOffsets,statOffsets);
permenIdx = expandIndices(permenLocal,stateOffsets,statOffsets);
specenIdx = expandIndices(specenLocal,stateOffsets,statOffsets);

allIdx = 1:2432;

if numel(entropyIdx)~=380 || numel(plvIdx)~=684 || ...
        numel(grangerIdx)~=1368
    error('特征模块索引数量异常。');
end

%% 10组消融
configuration = [ ...
    "Baseline"
    "NoEntropy"
    "NoPLV"
    "NoGranger"
    "NoApEn"
    "NoFuzzyEn"
    "NoSampEn"
    "NoPermEn"
    "NoSpecEn"
    "NoFisher"];

description = [ ...
    "Entropy + PLV + Granger，Fisher Top15"
    "去掉全部Entropy"
    "去掉全部PLV"
    "去掉全部Granger"
    "Leave-One-Out：去掉ApEn"
    "Leave-One-Out：去掉FuzzyEn"
    "Leave-One-Out：去掉SampEn"
    "Leave-One-Out：去掉PermEn"
    "Leave-One-Out：去掉SpecEn"
    "完整2432维，不使用Fisher"];

ablationGroup = [ ...
    "Baseline"
    "FeatureModule"
    "FeatureModule"
    "FeatureModule"
    "EntropyLOO"
    "EntropyLOO"
    "EntropyLOO"
    "EntropyLOO"
    "EntropyLOO"
    "Fisher"];

featureIndex = cell(10,1);
featureIndex{1} = allIdx;
featureIndex{2} = setdiff(allIdx,entropyIdx,'stable');
featureIndex{3} = setdiff(allIdx,plvIdx,'stable');
featureIndex{4} = setdiff(allIdx,grangerIdx,'stable');
featureIndex{5} = setdiff(allIdx,apenIdx,'stable');
featureIndex{6} = setdiff(allIdx,fuzzyIdx,'stable');
featureIndex{7} = setdiff(allIdx,sampenIdx,'stable');
featureIndex{8} = setdiff(allIdx,permenIdx,'stable');
featureIndex{9} = setdiff(allIdx,specenIdx,'stable');
featureIndex{10} = allIdx;

useFisher = true(10,1);
useFisher(10) = false;
selectedFeatureCount = 15;

results = cell(10,1);
metricsRows = cell(10,1);
predictionRows = cell(10,1);

for configIndex = 1:10
    rng(20260725,'twister');

    currentIdx = featureIndex{configIndex};
    X = XAll(:,currentIdx);

    fprintf('==================================================\n');
    fprintf('[%d/10] %s\n',configIndex,configuration(configIndex));
    fprintf('%s\n',description(configIndex));
    fprintf('输入维数：%d；Fisher：%d\n', ...
        size(X,2),useFisher(configIndex));

    result = runLOPO( ...
        X,y,subjects,covariates, ...
        useFisher(configIndex),selectedFeatureCount);

    result.Configuration = configuration(configIndex);
    result.Description = description(configIndex);
    result.AblationGroup = ablationGroup(configIndex);
    result.OriginalFeatureIndex = currentIdx;
    results{configIndex} = result;

    m = result.Metrics;
    metricsRows{configIndex} = table( ...
        ablationGroup(configIndex), ...
        configuration(configIndex), ...
        description(configIndex), ...
        size(X,2),result.SelectedFeatureCount, ...
        useFisher(configIndex), ...
        m.Accuracy,m.Sensitivity,m.Specificity, ...
        m.Precision,m.F1,m.BalancedAccuracy,m.MCC,m.AUC, ...
        'VariableNames',{ ...
        'AblationGroup','Configuration','Description', ...
        'InputFeatureCount','SelectedFeatureCount','UseFisher', ...
        'SubjectAccuracy','SubjectSensitivity','SubjectSpecificity', ...
        'SubjectPrecision','SubjectF1','SubjectBalancedAccuracy', ...
        'SubjectMCC','SubjectAUC'});

    predictionRows{configIndex} = table( ...
        subjects,y,result.PredictedLabel,result.PatientScore, ...
        repmat(configuration(configIndex),numel(y),1), ...
        'VariableNames',{ ...
        'SubjectID','TrueLabel','PredictedLabel', ...
        'PatientScore','Configuration'});

    fprintf(['Acc=%.4f，Sen=%.4f，Spe=%.4f，F1=%.4f，' ...
        'BalAcc=%.4f，MCC=%.4f，AUC=%.4f\n\n'], ...
        m.Accuracy,m.Sensitivity,m.Specificity,m.F1, ...
        m.BalancedAccuracy,m.MCC,m.AUC);
end

%% 汇总及相对Baseline变化
metricsTable = vertcat(metricsRows{:});
predictionTable = vertcat(predictionRows{:});

baseline = metricsTable(1,:);
metricsTable.DeltaAccuracy = ...
    metricsTable.SubjectAccuracy-baseline.SubjectAccuracy;
metricsTable.DeltaBalancedAccuracy = ...
    metricsTable.SubjectBalancedAccuracy-baseline.SubjectBalancedAccuracy;
metricsTable.DeltaMCC = ...
    metricsTable.SubjectMCC-baseline.SubjectMCC;
metricsTable.DeltaAUC = ...
    metricsTable.SubjectAUC-baseline.SubjectAUC;

%% 可选：与已有主结果文件中的EC_EO+5s+LDA核对
storedBaseline = table();

resultCandidates = { ...
    fullfile(rootDir,'MPHCED02_EC_EO_MSE_PLV_MVGC_LOPO_results_V3.mat'), ...
    fullfile(rootDir,'MPHCED02_EC_EO_MSE_PLV_MVGC_LOPO_results_V2.mat')};

resultFile = '';
for k = 1:numel(resultCandidates)
    if isfile(resultCandidates{k})
        resultFile = resultCandidates{k};
        break;
    end
end

if ~isempty(resultFile)
    R = load(resultFile,'metricsTable');
    if isfield(R,'metricsTable') && istable(R.metricsTable)
        mask = string(R.metricsTable.Condition)=="EC_EO" & ...
            R.metricsTable.ScaleSec==5 & ...
            string(R.metricsTable.Classifier)=="LDA";

        if sum(mask)==1
            storedBaseline = R.metricsTable(mask,:);
            fprintf('已有主结果基线核对：\n');
            fprintf('主结果 BalAcc=%.6f，本次Baseline BalAcc=%.6f\n', ...
                storedBaseline.BalancedAccuracy, ...
                baseline.SubjectBalancedAccuracy);
            fprintf('主结果 Acc=%.6f，本次Baseline Acc=%.6f\n\n', ...
                storedBaseline.Accuracy,baseline.SubjectAccuracy);
        end
    end
else
    fprintf('未找到V3/V2主结果MAT，跳过Baseline数值核对；不影响消融运行。\n\n');
end

%% 保存
metricsFile = fullfile(outDir, ...
    'MPHCED02_5s_LDA_ablation_metrics_V3.xlsx');
predictionFile = fullfile(outDir, ...
    'MPHCED02_5s_LDA_ablation_predictions_V3.xlsx');
matFile = fullfile(outDir, ...
    'MPHCED02_5s_LDA_ablation_results_V3.mat');
summaryFile = fullfile(outDir, ...
    'MPHCED02_5s_LDA_ablation_summary_V3.txt');

writetable(metricsTable,metricsFile,'FileType','spreadsheet');
writetable(predictionTable,predictionFile,'FileType','spreadsheet');

save(matFile, ...
    'results','metricsTable','predictionTable', ...
    'storedBaseline','featureIndex','configuration', ...
    'description','ablationGroup','confoundUsed','-v7.3');

writeSummary(summaryFile,metricsTable,sourceFeatureFile);

fprintf('==================================================\n');
fprintf('全部消融完成。\n');
fprintf('指标表：%s\n',metricsFile);
fprintf('预测表：%s\n',predictionFile);
fprintf('MAT结果：%s\n',matFile);
fprintf('摘要：%s\n',summaryFile);
fprintf('总耗时：%.1f分钟\n',toc(totalTimer)/60);
fprintf('结束时间：%s\n',datestr(now));
end

%% =========================================================
%% 特征索引展开
%% =========================================================
function idx = expandIndices(localIdx,stateOffsets,statOffsets)
idx = [];
for stateOffset = stateOffsets
    for statOffset = statOffsets
        idx = [idx,localIdx+stateOffset+statOffset]; %#ok<AGROW>
    end
end
idx = sort(idx);
end

%% =========================================================
%% 受试者级LOPO：固定LDA
%% =========================================================
function result = runLOPO( ...
    X,y,subjectIDs,covariates,useFisher,selectedFeatureCount)

nSubjects = numel(y);
predictedLabel = zeros(nSubjects,1);
patientScore = zeros(nSubjects,1);
selectedIndices = cell(nSubjects,1);

for heldOut = 1:nSubjects
    trainMask = true(nSubjects,1);
    trainMask(heldOut) = false;

    XTrain = X(trainMask,:);
    XTest = X(heldOut,:);
    yTrain = y(trainMask);

    medianValues = finiteColumnMedian(XTrain);
    XTrain = replaceNonfinite(XTrain,medianValues);
    XTest = replaceNonfinite(XTest,medianValues);

    if ~isempty(covariates)
        [XTrain,XTest] = correctConfoundsTrainingOnly( ...
            XTrain,XTest,covariates(trainMask,:),covariates(heldOut,:));
    end

    trainingMean = mean(XTrain,1);
    trainingStd = std(XTrain,0,1);
    trainingStd(trainingStd<1e-12) = 1;

    XTrain = (XTrain-trainingMean)./trainingStd;
    XTest = (XTest-trainingMean)./trainingStd;

    if useFisher
        fisherScore = calculateFisherScore(XTrain,yTrain);
        [~,rankedFeatures] = sort(fisherScore,'descend');
        selected = rankedFeatures( ...
            1:min(selectedFeatureCount,size(XTrain,2)));
    else
        selected = 1:size(XTrain,2);
    end

    selectedIndices{heldOut} = selected;

    model = fitcdiscr( ...
        XTrain(:,selected),yTrain, ...
        'DiscrimType','linear', ...
        'Gamma',0.1, ...
        'ClassNames',[0;1]);

    [~,score] = predict(model,XTest(:,selected));
    positiveColumn = find(model.ClassNames==1,1);
    patientScore(heldOut) = score(:,positiveColumn);
    predictedLabel(heldOut) = double(patientScore(heldOut)>=0.5);

    fprintf('  留出%2d/%2d，ID=%s，真实=%d，预测=%d，分数=%.4f\n', ...
        heldOut,nSubjects,subjectIDs(heldOut), ...
        y(heldOut),predictedLabel(heldOut),patientScore(heldOut));
end

result = struct();
result.SubjectIDs = subjectIDs;
result.TrueLabel = y;
result.PredictedLabel = predictedLabel;
result.PatientScore = patientScore;
result.SelectedIndices = selectedIndices;

if useFisher
    result.SelectedFeatureCount = ...
        min(selectedFeatureCount,size(X,2));
else
    result.SelectedFeatureCount = size(X,2);
end

result.Metrics = calculateMetrics(y,predictedLabel,patientScore);
end

%% =========================================================
%% Fisher
%% =========================================================
function score = calculateFisherScore(X,y)
class0 = X(y==0,:);
class1 = X(y==1,:);
score = (mean(class1,1)-mean(class0,1)).^2./ ...
    (var(class1,0,1)+var(class0,0,1)+eps);
score(~isfinite(score)) = 0;
end

%% =========================================================
%% 混杂校正：完全复用V3训练折内规则
%% =========================================================
function T = loadCovariates(baseDir,rootDir)
candidates = { ...
    fullfile(baseDir,'MPHCED_subject_covariates.csv'), ...
    fullfile(rootDir,'MPHCED_subject_covariates.csv')};

covariateFile = '';
for k = 1:numel(candidates)
    if isfile(candidates{k})
        covariateFile = candidates{k};
        break;
    end
end
if isempty(covariateFile)
    error('原V3启用了混杂校正，但没有找到MPHCED_subject_covariates.csv。');
end

R = readtable(covariateFile,'VariableNamingRule','preserve');
required = {'SubjectID','Age','GenderMale1'};
for k = 1:numel(required)
    if ~ismember(required{k},R.Properties.VariableNames)
        error('混杂变量文件缺少列：%s',required{k});
    end
end

T = table( ...
    string(R.SubjectID(:)),double(R.Age(:)),double(R.GenderMale1(:)), ...
    'VariableNames',{'SubjectID','Age','GenderMale1'});
end

function covariates = alignCovariates(T,subjects)
covariates = zeros(numel(subjects),2);
for k = 1:numel(subjects)
    row = find(T.SubjectID==subjects(k));
    if numel(row)~=1
        error('混杂表中受试者%s未唯一匹配。',subjects(k));
    end
    covariates(k,:) = [T.Age(row),T.GenderMale1(row)];
end
end

function [trainCorrected,testCorrected] = ...
    correctConfoundsTrainingOnly(XTrain,XTest,covTrain,covTest)

covMean = mean(covTrain,1);
covStd = std(covTrain,0,1);
covStd(covStd<1e-12) = 1;

covTrainZ = (covTrain-covMean)./covStd;
covTestZ = (covTest-covMean)./covStd;

designTrain = [ones(size(covTrainZ,1),1),covTrainZ];
designTest = [ones(size(covTestZ,1),1),covTestZ];

penalty = eye(size(designTrain,2));
penalty(1,1) = 0;
lambda = 1e-6;

beta = (designTrain'*designTrain+lambda*penalty)\ ...
    (designTrain'*XTrain);

trainCorrected = XTrain-designTrain*beta;
testCorrected = XTest-designTest*beta;
end

%% =========================================================
%% 缺失值
%% =========================================================
function medianValues = finiteColumnMedian(X)
medianValues = zeros(1,size(X,2));
for columnIndex = 1:size(X,2)
    values = X(isfinite(X(:,columnIndex)),columnIndex);
    if isempty(values)
        medianValues(columnIndex) = 0;
    else
        medianValues(columnIndex) = median(values);
    end
end
end

function X = replaceNonfinite(X,replacement)
for columnIndex = 1:size(X,2)
    invalid = ~isfinite(X(:,columnIndex));
    X(invalid,columnIndex) = replacement(columnIndex);
end
end

%% =========================================================
%% 指标
%% =========================================================
function metrics = calculateMetrics(trueLabel,predictedLabel,score)
trueLabel = double(trueLabel(:));
predictedLabel = double(predictedLabel(:));
score = double(score(:));

TN = sum(trueLabel==0 & predictedLabel==0);
FP = sum(trueLabel==0 & predictedLabel==1);
FN = sum(trueLabel==1 & predictedLabel==0);
TP = sum(trueLabel==1 & predictedLabel==1);

accuracy = (TP+TN)/max(TP+TN+FP+FN,1);
sensitivity = TP/max(TP+FN,1);
specificity = TN/max(TN+FP,1);
precision = TP/max(TP+FP,1);
f1 = 2*precision*sensitivity/max(precision+sensitivity,eps);
balancedAccuracy = (sensitivity+specificity)/2;

mccDenominator = sqrt(max( ...
    (TP+FP)*(TP+FN)*(TN+FP)*(TN+FN),eps));
mcc = (TP*TN-FP*FN)/mccDenominator;
auc = calculateAUC(trueLabel,score);

metrics = struct();
metrics.Accuracy = accuracy;
metrics.Sensitivity = sensitivity;
metrics.Specificity = specificity;
metrics.Precision = precision;
metrics.F1 = f1;
metrics.BalancedAccuracy = balancedAccuracy;
metrics.MCC = mcc;
metrics.AUC = auc;
metrics.ConfusionMatrix = [TN FP;FN TP];
end

function auc = calculateAUC(y,score)
positiveScores = score(y==1);
negativeScores = score(y==0);
comparison = positiveScores(:)>negativeScores(:)';
ties = positiveScores(:)==negativeScores(:)';
auc = (sum(comparison(:))+0.5*sum(ties(:)))/ ...
    max(numel(positiveScores)*numel(negativeScores),1);
end

%% =========================================================
%% 摘要
%% =========================================================
function writeSummary(fileName,T,sourceFeatureFile)
fid = fopen(fileName,'w');
cleanupFile = onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid,'MPHCED02 5秒 LDA 特征消融\n');
fprintf(fid,'条件：EC_EO\n');
fprintf(fid,'源特征：%s\n',sourceFeatureFile);
fprintf(fid,'Baseline：Fisher Top15\n');
fprintf(fid,'Delta = 当前消融 - Baseline\n\n');
fprintf(fid,'%-12s  Acc      BalAcc   MCC      AUC      dBalAcc\n','Config');

for i = 1:height(T)
    fprintf(fid,'%-12s  %.4f   %.4f   %.4f   %.4f   %+.4f\n', ...
        char(T.Configuration(i)), ...
        T.SubjectAccuracy(i), ...
        T.SubjectBalancedAccuracy(i), ...
        T.SubjectMCC(i), ...
        T.SubjectAUC(i), ...
        T.DeltaBalancedAccuracy(i));
end
end
