function MPHCED02_EC_EO_MSE_PLV_MVGC_6Classifiers_LOPO_V1
% MPHCED：EC/EO多尺度五种熵 + PLV + 条件多变量Granger
% 六分类器、受试者级LOPO
%
% 输入目录：
% F:\Database\MPHCED-Depression\MDD Patients and Healthy Controls EEG Data
%
% 核心实验输入：
% ECdata.mat、EClable.mat、EOdata.mat、EOlable.mat
%
% 所有滤波、分窗、熵、PLV、Granger和分类都使用ECdata/EOdata。
%
% 本程序不推断受试者映射。运行前必须先执行：
% MPHCED02_Direct_Waveform_Matching_V1
%
% 主程序只读取经完整MAT—EDF波形直接匹配并通过阈值的
% ECsubject_mapping.csv和EOsubject_mapping.csv。
%
% 标签：HC=0，MDD=1
%
% 输出目录：
% D:\Database\Depression\MPHCED\MPHCED02
%
% ECdata/EOdata每行是一个60秒片段，19列是19个EEG通道。
% 277/287是片段数，不是受试者数。程序必须恢复每个片段所属
% 受试者后，先进行受试者内部聚合，再做LOPO。
%
% 每窗口特征：
% 19×5种熵 = 95
% PLV上三角 = 171
% 19节点条件多变量Granger = 342
% 合计608维。
%
% 每名受试者、每种状态、每种尺度的窗口特征求均值和标准差，
% 得到1216维受试者级特征。
%
% 实验组合：EC、EO、EC+EO × 1/2/5秒 × 6分类器，共54组。
%
% 需要：Signal Processing Toolbox、Statistics and Machine Learning Toolbox

clc;
close all;
rng(20260725, 'twister');

%% 路径
baseDir = ...
    'F:\Database\MPHCED-Depression\MDD Patients and Healthy Controls EEG Data';

outDir = ...
    'D:\Database\Depression\MPHCED\MPHCED02';

if ~isfolder(baseDir)
    error('源数据目录不存在：%s', baseDir);
end
if ~exist(outDir, 'dir')
    mkdir(outDir);
end

cacheDir = fullfile(outDir, 'subject_feature_cache_V1');
if ~exist(cacheDir, 'dir')
    mkdir(cacheDir);
end

mappingDir = fullfile(outDir, 'subject_mapping_V1');
if ~exist(mappingDir, 'dir')
    mkdir(mappingDir);
end

logFile = fullfile(outDir, 'MPHCED02_run_log_V1.txt');
if isfile(logFile)
    delete(logFile);
end
diary(logFile);
cleanupDiary = onCleanup(@() diary('off')); %#ok<NASGU>

fprintf('开始时间：%s\n', datestr(now));
fprintf('核心EEG数据源：ECdata.mat和EOdata.mat。\n');
fprintf('受试者映射来自MPHCED02直接MAT—EDF波形匹配结果。\n');
totalTimer = tic;

%% 参数
fs = 256;
expectedChannels = 19;
expectedSamplesPerSegment = 15360;

% 论文列出的19个10-20电极。若geECdata.m/geEOdata.m中的列顺序不同，
% 必须按生成脚本修改下面顺序，但不要重排ECdata/EOdata本身。
% 重要：必须与EDF以及dataSet前19行的真实顺序完全一致。
% EDF头顺序为：
% Fp1,F3,C3,P3,O1,F7,T3,T5,Fz,Fp2,F4,C4,P4,O2,F8,T4,T6,Cz,Pz
channelNames = { ...
    'Fp1','F3','C3','P3','O1','F7','T3','T5','Fz', ...
    'Fp2','F4','C4','P4','O2','F8','T4','T6','Cz','Pz'};

coordinates = standard1020Coordinates(channelNames);

filterOrder = 4;
passBand = [1 45];

baseArtifactEpochSec = 1;
artifactRobustZ = 8;
artifactExpansionEpochs = 1;

windowSecs = [1 2 5];
grangerOrders = [2 3 5];

% 每名受试者、每个状态、每个尺度最多均匀选择12个干净窗口。
% 这样可控制19节点条件多变量Granger计算量，并避免片段多的受试者
% 在特征聚合中权重更高。
maxWindowsPerSubjectStateScale = 12;
minimumCleanWindows = [6 6 6];

entropyM = 2;
entropyRRatio = 0.20;
fuzzyExponent = 2;
permutationOrder = 3;
permutationTau = 1;
maxEntropyTemplates = 48;

grangerRidgeLambda = 1e-2;
selectedFeatureCount = 15;
numberOfTrees = 100;

% true时忽略已有V3特征缓存并重新计算。
forceRecomputeFeatures = false;

classifierCodes = { ...
    'LinearSVM','RBFSVM','Logistic','LDA','KNN','RF'};

classifierDescriptions = { ...
    '线性支持向量机', ...
    '高斯核支持向量机', ...
    'L2逻辑回归', ...
    '正则化线性判别分析', ...
    '5近邻', ...
    '随机森林'};

conditionCodes = {'EC','EO','EC_EO'};
conditionDescriptions = {'闭眼','睁眼','闭眼+睁眼'};

configSignature = sprintf( ...
    ['MPHCED02_V1_DirectWaveMatch_FS%d_Ch%d_W%s_GC%s_Band%.1f-%.1f_' ...
     'MaxWin%d_EntTpl%d'], ...
    fs, expectedChannels, mat2str(windowSecs), ...
    mat2str(grangerOrders), passBand(1), passBand(2), ...
    maxWindowsPerSubjectStateScale, maxEntropyTemplates);

%% 读取聚合数据
ECdata = loadRequiredVariable( ...
    fullfile(baseDir, 'ECdata.mat'), 'ECdata');
EClabel = double(loadRequiredVariable( ...
    fullfile(baseDir, 'EClable.mat'), 'EClable'));

EOdata = loadRequiredVariable( ...
    fullfile(baseDir, 'EOdata.mat'), 'EOdata');
EOlabel = double(loadRequiredVariable( ...
    fullfile(baseDir, 'EOlable.mat'), 'EOlable'));

EClabel = EClabel(:);
EOlabel = EOlabel(:);

validateAggregateData( ...
    ECdata, EClabel, expectedChannels, ...
    expectedSamplesPerSegment, 'EC');

validateAggregateData( ...
    EOdata, EOlabel, expectedChannels, ...
    expectedSamplesPerSegment, 'EO');

fprintf('EC片段：%d，HC=%d，MDD=%d\n', ...
    size(ECdata,1), sum(EClabel==0), sum(EClabel==1));

fprintf('EO片段：%d，HC=%d，MDD=%d\n', ...
    size(EOdata,1), sum(EOlabel==0), sum(EOlabel==1));

%% 恢复每个片段的受试者ID
[ECsubjectID, ECmapping] = resolveSubjectIDs( ...
    baseDir, mappingDir, 'EC', EClabel, ECdata);

[EOsubjectID, EOmapping] = resolveSubjectIDs( ...
    baseDir, mappingDir, 'EO', EOlabel, EOdata);

writetable(ECmapping, fullfile(mappingDir, ...
    'MPHCED02_EC_segment_mapping_V1.csv'));

writetable(EOmapping, fullfile(mappingDir, ...
    'MPHCED02_EO_segment_mapping_V1.csv'));

validateSubjectMapping(ECsubjectID, EClabel, 'EC');
validateSubjectMapping(EOsubjectID, EOlabel, 'EO');

ECsubjects = unique(ECsubjectID, 'stable');
EOsubjects = unique(EOsubjectID, 'stable');
commonSubjects = intersect(ECsubjects, EOsubjects, 'stable');

fprintf('EC受试者数：%d\n', numel(ECsubjects));
fprintf('EO受试者数：%d\n', numel(EOsubjects));
fprintf('EC与EO共同受试者数：%d\n', numel(commonSubjects));

%% 可选个体级混杂变量
% 可在源目录放置MPHCED_subject_covariates.csv，列为：
% SubjectID,Age,GenderMale1
% 没有个体级信息时跳过混杂回归，不使用论文组均值伪造协变量。
[covariateTable, hasCovariates] = ...
    loadOptionalCovariates(baseDir, outDir);

if hasCovariates
    writetable(covariateTable, fullfile(outDir, ...
        'MPHCED02_covariates_used_V1.csv'));
    fprintf('已加载年龄和性别个体级混杂变量。\n');
else
    fprintf(['未发现MPHCED_subject_covariates.csv，' ...
             '本次不执行混杂校正。\n']);
end

%% 特征名称
[windowFeatureNames, windowFeatureTypes] = ...
    makeFeatureNames(expectedChannels, channelNames);

nWindowFeatures = numel(windowFeatureNames);
if nWindowFeatures ~= 608
    error('窗口特征数为%d，预期608。', nWindowFeatures);
end

subjectFeatureNames = [ ...
    strcat('Mean_', windowFeatureNames), ...
    strcat('Std_', windowFeatureNames)];

subjectFeatureTypes = [ ...
    strcat(windowFeatureTypes, '_Mean'), ...
    strcat(windowFeatureTypes, '_Std')];

nSubjectFeatures = numel(subjectFeatureNames);

featureNameTable = table( ...
    (1:nSubjectFeatures)', ...
    string(subjectFeatureNames(:)), ...
    string(subjectFeatureTypes(:)), ...
    'VariableNames', ...
    {'FeatureIndex','FeatureName','FeatureType'});

writetable(featureNameTable, fullfile(outDir, ...
    'MPHCED02_feature_names_V1.csv'));

%% 状态数据结构
stateData = struct();
stateData.EC.Data = ECdata;
stateData.EC.Label = EClabel;
stateData.EC.SubjectID = ECsubjectID;
stateData.EO.Data = EOdata;
stateData.EO.Label = EOlabel;
stateData.EO.SubjectID = EOsubjectID;

stateCodes = {'EC','EO'};
stateFeatures = struct();
qualityRows = {};

%% 逐受试者提取EC和EO特征
for stateIndex = 1:numel(stateCodes)
    stateCode = stateCodes{stateIndex};
    dataCell = stateData.(stateCode).Data;
    segmentLabels = stateData.(stateCode).Label;
    segmentSubjectIDs = stateData.(stateCode).SubjectID;
    subjects = unique(segmentSubjectIDs, 'stable');

    featureSets = cell(numel(windowSecs),1);
    for scaleIndex = 1:numel(windowSecs)
        featureSets{scaleIndex} = ...
            nan(numel(subjects), nSubjectFeatures);
    end

    subjectLabels = zeros(numel(subjects),1);

    for subjectIndex = 1:numel(subjects)
        subjectID = subjects(subjectIndex);
        segmentRows = find(segmentSubjectIDs == subjectID);
        labelsHere = unique(segmentLabels(segmentRows));

        if numel(labelsHere) ~= 1
            error('%s受试者%s的片段标签不唯一。', ...
                stateCode, subjectID);
        end

        subjectLabels(subjectIndex) = labelsHere;

        cacheFile = fullfile(cacheDir, sprintf( ...
            '%s_%s_features_V1.mat', char(subjectID), stateCode));

        cacheOK = false;
        if isfile(cacheFile) && ~forceRecomputeFeatures
            C = load(cacheFile, ...
                'subjectIDCached','stateCodeCached', ...
                'configSignatureSaved', ...
                'subjectScaleFeatures','qualityRow');

            cacheOK = ...
                isfield(C,'configSignatureSaved') && ...
                strcmp(C.configSignatureSaved,configSignature) && ...
                string(C.subjectIDCached)==subjectID && ...
                strcmp(C.stateCodeCached,stateCode);
        end

        if cacheOK
            subjectScaleFeatures = C.subjectScaleFeatures;
            qualityRow = C.qualityRow;
            fprintf('读取缓存：%s，%2d/%2d，ID=%s\n', ...
                stateCode, subjectIndex, numel(subjects), subjectID);
        else
            subjectTimer = tic;

            [subjectScaleFeatures, qualityRow] = ...
                extractSubjectStateFeatures( ...
                dataCell(segmentRows,:), segmentRows, ...
                subjectID, labelsHere, stateCode, fs, ...
                channelNames, coordinates, ...
                filterOrder, passBand, ...
                baseArtifactEpochSec, artifactRobustZ, ...
                artifactExpansionEpochs, ...
                windowSecs, grangerOrders, ...
                maxWindowsPerSubjectStateScale, ...
                minimumCleanWindows, ...
                entropyM, entropyRRatio, fuzzyExponent, ...
                permutationOrder, permutationTau, ...
                maxEntropyTemplates, grangerRidgeLambda, ...
                nWindowFeatures);

            subjectIDCached = subjectID; %#ok<NASGU>
            stateCodeCached = stateCode; %#ok<NASGU>
            configSignatureSaved = configSignature; %#ok<NASGU>

            save(cacheFile, ...
                'subjectIDCached','stateCodeCached', ...
                'configSignatureSaved', ...
                'subjectScaleFeatures','qualityRow','-v7.3');

            fprintf(['完成特征：%s，%2d/%2d，ID=%s，' ...
                     '片段=%d，耗时%.1f分钟\n'], ...
                stateCode, subjectIndex, numel(subjects), ...
                subjectID, numel(segmentRows), ...
                toc(subjectTimer)/60);
        end

        for scaleIndex = 1:numel(windowSecs)
            featureSets{scaleIndex}(subjectIndex,:) = ...
                double(subjectScaleFeatures{scaleIndex});
        end

        qualityRows{end+1,1} = qualityRow; %#ok<AGROW>
    end

    stateFeatures.(stateCode).Subjects = subjects;
    stateFeatures.(stateCode).Labels = subjectLabels;
    stateFeatures.(stateCode).FeatureSets = featureSets;
end

qualityTable = vertcat(qualityRows{:});
writetable(qualityTable, fullfile(outDir, ...
    'MPHCED02_quality_report_V1.csv'));

save(fullfile(outDir, ...
    'MPHCED02_subject_features_V1.mat'), ...
    'stateFeatures','windowFeatureNames','windowFeatureTypes', ...
    'subjectFeatureNames','subjectFeatureTypes', ...
    'channelNames','coordinates','windowSecs','grangerOrders', ...
    'configSignature','-v7.3');

%% 构建EC、EO、EC+EO三套受试者级数据
experimentData = struct();

experimentData.EC.Subjects = stateFeatures.EC.Subjects;
experimentData.EC.Labels = stateFeatures.EC.Labels;
experimentData.EC.FeatureSets = stateFeatures.EC.FeatureSets;
experimentData.EC.FeatureNames = subjectFeatureNames;

experimentData.EO.Subjects = stateFeatures.EO.Subjects;
experimentData.EO.Labels = stateFeatures.EO.Labels;
experimentData.EO.FeatureSets = stateFeatures.EO.FeatureSets;
experimentData.EO.FeatureNames = subjectFeatureNames;

[~, ecIndex] = ismember(commonSubjects, stateFeatures.EC.Subjects);
[~, eoIndex] = ismember(commonSubjects, stateFeatures.EO.Subjects);

labelsEC = stateFeatures.EC.Labels(ecIndex);
labelsEO = stateFeatures.EO.Labels(eoIndex);

if any(labelsEC ~= labelsEO)
    error('EC与EO共同受试者存在标签冲突。');
end

combinedFeatureSets = cell(numel(windowSecs),1);
for scaleIndex = 1:numel(windowSecs)
    combinedFeatureSets{scaleIndex} = [ ...
        stateFeatures.EC.FeatureSets{scaleIndex}(ecIndex,:), ...
        stateFeatures.EO.FeatureSets{scaleIndex}(eoIndex,:)];
end

experimentData.EC_EO.Subjects = commonSubjects;
experimentData.EC_EO.Labels = labelsEC;
experimentData.EC_EO.FeatureSets = combinedFeatureSets;
experimentData.EC_EO.FeatureNames = [ ...
    strcat('EC_',subjectFeatureNames), ...
    strcat('EO_',subjectFeatureNames)];

%% 54组LOPO
nConditions = numel(conditionCodes);
nScales = numel(windowSecs);
nClassifiers = numel(classifierCodes);
nExperiments = nConditions*nScales*nClassifiers;

results = cell(nExperiments,1);
metricsRows = cell(nExperiments,1);
predictionRows = cell(nExperiments,1);
selectionRows = cell(nExperiments,1);
experimentIndex = 0;

for conditionIndex = 1:nConditions
    conditionCode = conditionCodes{conditionIndex};
    subjects = experimentData.(conditionCode).Subjects;
    y = experimentData.(conditionCode).Labels;
    featureNamesCurrent = ...
        experimentData.(conditionCode).FeatureNames;

    covariates = alignCovariates( ...
        covariateTable,hasCovariates,subjects);

    fprintf('\n===== %s：受试者%d，HC=%d，MDD=%d =====\n', ...
        conditionCode,numel(subjects),sum(y==0),sum(y==1));

    for scaleIndex = 1:nScales
        X = double(experimentData.(conditionCode).FeatureSets{scaleIndex});

        for classifierIndex = 1:nClassifiers
            experimentIndex = experimentIndex+1;
            classifierCode = classifierCodes{classifierIndex};

            fprintf('\n[%d/%d] %s + %d秒 + %s\n', ...
                experimentIndex,nExperiments,conditionCode, ...
                windowSecs(scaleIndex),classifierCode);

            result = runSubjectLOPO( ...
                X,y,subjects,covariates,classifierCode, ...
                selectedFeatureCount,numberOfTrees);

            result.Condition = conditionCode;
            result.ScaleSec = windowSecs(scaleIndex);
            result.Classifier = classifierCode;
            results{experimentIndex} = result;

            m = result.Metrics;

            metricsRows{experimentIndex} = table( ...
                string(conditionCode), ...
                string(conditionDescriptions{conditionIndex}), ...
                windowSecs(scaleIndex), ...
                string(classifierCode), ...
                string(classifierDescriptions{classifierIndex}), ...
                numel(subjects),sum(y==0),sum(y==1), ...
                size(X,2),result.SelectedFeatureCount, ...
                hasCovariates, ...
                m.Accuracy,m.Sensitivity,m.Specificity, ...
                m.Precision,m.F1,m.BalancedAccuracy,m.MCC,m.AUC, ...
                'VariableNames', { ...
                'Condition','ConditionDescription','ScaleSec', ...
                'Classifier','ClassifierDescription', ...
                'NumSubjects','NumHC','NumMDD', ...
                'OriginalFeatureCount','SelectedFeatureCount', ...
                'ConfoundCorrectionUsed', ...
                'Accuracy','Sensitivity','Specificity', ...
                'Precision','F1','BalancedAccuracy','MCC','AUC'});

            predictionRows{experimentIndex} = table( ...
                subjects,y,result.PredictedLabel, ...
                result.PatientScore, ...
                repmat(string(conditionCode),numel(subjects),1), ...
                repmat(windowSecs(scaleIndex),numel(subjects),1), ...
                repmat(string(classifierCode),numel(subjects),1), ...
                'VariableNames', { ...
                'SubjectID','TrueLabel','PredictedLabel', ...
                'PatientScore','Condition','ScaleSec','Classifier'});

            selectionRows{experimentIndex} = ...
                makeSelectionTable( ...
                result.SelectionFrequency,featureNamesCurrent, ...
                conditionCode,windowSecs(scaleIndex), ...
                classifierCode,numel(subjects));

            fprintf(['Acc=%.4f，Sen=%.4f，Spe=%.4f，' ...
                     'F1=%.4f，BalAcc=%.4f，MCC=%.4f，AUC=%.4f\n'], ...
                m.Accuracy,m.Sensitivity,m.Specificity, ...
                m.F1,m.BalancedAccuracy,m.MCC,m.AUC);
        end
    end
end

metricsTable = vertcat(metricsRows{:});
predictionTable = vertcat(predictionRows{:});
selectionTable = vertcat(selectionRows{:});

rankingKey = [ ...
    -metricsTable.BalancedAccuracy, ...
    -metricsTable.AUC, ...
    -metricsTable.MCC, ...
    -metricsTable.Accuracy];

[~,rankingOrder] = sortrows(rankingKey,1:4);
rankingTable = metricsTable(rankingOrder,:);
rankingTable = addvars(rankingTable, ...
    (1:height(rankingTable))','Before',1, ...
    'NewVariableNames','Rank');

bestExperimentIndex = rankingOrder(1);
bestResult = results{bestExperimentIndex};

writetable(metricsTable, fullfile(outDir, ...
    'MPHCED02_54experiment_metrics_V1.csv'));

writetable(rankingTable, fullfile(outDir, ...
    'MPHCED02_54experiment_ranking_V1.csv'));

writetable(predictionTable, fullfile(outDir, ...
    'MPHCED02_subject_predictions_V1.csv'));

writetable(selectionTable, fullfile(outDir, ...
    'MPHCED02_selected_feature_frequency_V1.csv'));

save(fullfile(outDir, ...
    'MPHCED02_EC_EO_MSE_PLV_MVGC_LOPO_results_V1.mat'), ...
    'results','metricsTable','rankingTable', ...
    'predictionTable','selectionTable', ...
    'bestExperimentIndex','bestResult', ...
    'experimentData','configSignature','-v7.3');

bestName = sprintf('%s_%ds_%s', ...
    bestResult.Condition,bestResult.ScaleSec, ...
    bestResult.Classifier);

plotConfusionMatrix( ...
    bestResult.Metrics.ConfusionMatrix,bestName, ...
    fullfile(outDir,'MPHCED02_BEST_confusion_V1.png'));

plotROC( ...
    bestResult.TrueLabel,bestResult.PatientScore, ...
    bestResult.Metrics.AUC,bestName, ...
    fullfile(outDir,'MPHCED02_BEST_ROC_V1.png'));

writeMPHCEDSummary( ...
    fullfile(outDir,'MPHCED02_summary_V1.txt'), ...
    rankingTable,bestResult,hasCovariates, ...
    maxWindowsPerSubjectStateScale, ...
    selectedFeatureCount,configSignature);

fprintf('\n==================================================\n');
fprintf('最佳实验：%s + %d秒 + %s\n', ...
    bestResult.Condition,bestResult.ScaleSec, ...
    bestResult.Classifier);
fprintf('Accuracy          = %.4f\n',bestResult.Metrics.Accuracy);
fprintf('Sensitivity       = %.4f\n',bestResult.Metrics.Sensitivity);
fprintf('Specificity       = %.4f\n',bestResult.Metrics.Specificity);
fprintf('Precision         = %.4f\n',bestResult.Metrics.Precision);
fprintf('F1                = %.4f\n',bestResult.Metrics.F1);
fprintf('BalancedAccuracy  = %.4f\n',bestResult.Metrics.BalancedAccuracy);
fprintf('MCC               = %.4f\n',bestResult.Metrics.MCC);
fprintf('AUC               = %.4f\n',bestResult.Metrics.AUC);
fprintf('==================================================\n');
fprintf('结果目录：%s\n',outDir);
fprintf('总耗时：%.1f分钟\n',toc(totalTimer)/60);
fprintf('结束时间：%s\n',datestr(now));
end

%% ====================== 数据与映射 ======================
function value = loadRequiredVariable(filePath,variableName)
if ~isfile(filePath)
    error('文件不存在：%s',filePath);
end
S = load(filePath,variableName);
if ~isfield(S,variableName)
    error('%s中缺少变量%s。',filePath,variableName);
end
value = S.(variableName);
end

function validateAggregateData( ...
    data,labels,expectedChannels,expectedSamples,stateCode)

if ~iscell(data)
    error('%sdata必须是cell。',stateCode);
end
if size(data,2)~=expectedChannels
    error('%sdata通道数为%d，预期%d。', ...
        stateCode,size(data,2),expectedChannels);
end
if size(data,1)~=numel(labels)
    error('%s数据行数与标签数不一致。',stateCode);
end
if any(~ismember(labels,[0 1]))
    error('%s标签含有0和1以外的值。',stateCode);
end

for row = 1:size(data,1)
    lengths = cellfun(@numel,data(row,:));
    if any(lengths~=expectedSamples)
        error('%s第%d行存在非%d点通道。', ...
            stateCode,row,expectedSamples);
    end
end
end

function [subjectIDs,mappingTable] = ...
    resolveSubjectIDs( ...
    ~,mappingDir,stateCode,labels,~)
% 仅读取直接波形匹配程序生成并通过阈值的受试者映射。

mappingFile = fullfile(mappingDir, ...
    [stateCode 'subject_mapping.csv']);

if ~isfile(mappingFile)
    error([ ...
        '缺少%s直接波形匹配映射：%s' newline ...
        '请先运行MPHCED02_Direct_Waveform_Matching_V1。'], ...
        stateCode,mappingFile);
end

T = readtable(mappingFile, ...
    'VariableNamingRule','preserve');

requiredVariables = { ...
    'SegmentIndex','Label','SubjectID','SourceEDF', ...
    'MedianChannelCorrelation','MedianNormalizedRMSE', ...
    'MatchAccepted'};

for k = 1:numel(requiredVariables)
    if ~any(strcmp(T.Properties.VariableNames, ...
            requiredVariables{k}))
        error('%s映射缺少列：%s', ...
            stateCode,requiredVariables{k});
    end
end

T = sortrows(T,'SegmentIndex');

if height(T)~=numel(labels)
    error('%s映射为%d行，预期%d行。', ...
        stateCode,height(T),numel(labels));
end

if any(double(T.Label(:))~=labels(:))
    error('%s映射标签顺序与聚合标签不一致。',stateCode);
end

if any(~logical(T.MatchAccepted))
    error('%s映射中存在未通过直接匹配的片段。',stateCode);
end

if any(T.MedianChannelCorrelation<0.995)
    error('%s映射中存在相关系数低于0.995的片段。',stateCode);
end

if any(T.MedianNormalizedRMSE>0.100)
    error('%s映射中存在归一化RMSE高于0.100的片段。',stateCode);
end

subjectIDs = string(T.SubjectID);
mappingTable = T;

validateSubjectMapping(subjectIDs,labels,stateCode);

fprintf(['%s：读取直接匹配映射，片段=%d，受试者=%d，' ...
    '相关系数中位数=%.8f。\n'], ...
    stateCode,height(T),numel(unique(subjectIDs)), ...
    median(T.MedianChannelCorrelation));
end

function ids = normalizeIDVector(value)
if iscell(value)
    ids = string(value(:));
elseif isstring(value)
    ids = value(:);
elseif ischar(value)
    ids = string(cellstr(value));
elseif isnumeric(value)
    ids = string(value(:));
else
    error('受试者ID列无法转换为字符串。');
end
ids = strtrim(ids);
if any(strlength(ids)==0)
    error('受试者ID中存在空值。');
end
end

function validateSubjectMapping(subjectIDs,labels,stateCode)
if numel(subjectIDs)~=numel(labels)
    error('%s受试者ID数与片段数不一致。',stateCode);
end
subjects = unique(subjectIDs);
for k = 1:numel(subjects)
    y = unique(labels(subjectIDs==subjects(k)));
    if numel(y)~=1
        error('%s受试者%s具有多个标签。', ...
            stateCode,subjects(k));
    end
end
end

function index = findVariable(T,candidates)
index = [];
for k = 1:numel(candidates)
    match = find(strcmpi(T.Properties.VariableNames,candidates{k}),1);
    if ~isempty(match)
        index = match;
        return;
    end
end
end

function [T,available] = loadOptionalCovariates(baseDir,outDir)
candidates = { ...
    fullfile(baseDir,'MPHCED_subject_covariates.csv'), ...
    fullfile(outDir,'MPHCED_subject_covariates.csv')};
T = table();
available = false;

for k = 1:numel(candidates)
    if ~isfile(candidates{k})
        continue;
    end

    R = readtable(candidates{k},'VariableNamingRule','preserve');
    idIndex = findVariable(R,{'SubjectID','subjectID','ID'});
    ageIndex = findVariable(R,{'Age','age'});
    genderIndex = findVariable(R, ...
        {'GenderMale1','genderMale1','Gender','gender'});

    if isempty(idIndex)||isempty(ageIndex)||isempty(genderIndex)
        error(['混杂变量CSV需要SubjectID、Age、' ...
               'GenderMale1三列。']);
    end

    subjectID = normalizeIDVector(R{:,idIndex});
    age = double(R{:,ageIndex});
    genderRaw = R{:,genderIndex};

    if isnumeric(genderRaw)
        gender = double(genderRaw);
    else
        text = upper(strtrim(string(genderRaw)));
        gender = nan(numel(text),1);
        gender(text=="M"|text=="MALE"|text=="男") = 1;
        gender(text=="F"|text=="FEMALE"|text=="女") = 0;
    end

    if any(~isfinite(age))||any(~isfinite(gender))
        error('混杂变量存在缺失或非法值。');
    end

    T = table(subjectID,age,gender, ...
        'VariableNames',{'SubjectID','Age','GenderMale1'});
    available = true;
    return;
end
end

function covariates = alignCovariates(T,available,subjects)
if ~available
    covariates = [];
    return;
end
covariates = zeros(numel(subjects),2);
for k = 1:numel(subjects)
    row = find(T.SubjectID==subjects(k));
    if numel(row)~=1
        error('混杂表中受试者%s未唯一匹配。',subjects(k));
    end
    covariates(k,:) = [T.Age(row),T.GenderMale1(row)];
end
end
%% ====================== 受试者级特征提取 ======================
function [subjectScaleFeatures,qualityRow] = ...
    extractSubjectStateFeatures( ...
    segmentCells,segmentRows,subjectID,label,stateCode,fs, ...
    channelNames,coordinates,filterOrder,passBand, ...
    baseArtifactEpochSec,artifactRobustZ,artifactExpansionEpochs, ...
    windowSecs,grangerOrders,maximumWindows,minimumCleanWindows, ...
    entropyM,entropyRRatio,fuzzyExponent, ...
    permutationOrder,permutationTau,maxEntropyTemplates, ...
    grangerLambda,nWindowFeatures)

nSegments = size(segmentCells,1);
processedSegments = cell(nSegments,1);
artifactMasks = cell(nSegments,1);
badChannelCounts = zeros(nSegments,1);
artifactEpochCounts = zeros(nSegments,1);

for segmentIndex = 1:nSegments
    X = segmentCellRowToMatrix(segmentCells(segmentIndex,:));

    [X,badChannels] = preprocessSegment( ...
        X,fs,coordinates,filterOrder,passBand);

    artifactMask = detectArtifactEpochs( ...
        X,fs,baseArtifactEpochSec,channelNames, ...
        artifactRobustZ,artifactExpansionEpochs);

    processedSegments{segmentIndex} = X;
    artifactMasks{segmentIndex} = artifactMask;
    badChannelCounts(segmentIndex) = sum(badChannels);
    artifactEpochCounts(segmentIndex) = sum(artifactMask);
end

subjectScaleFeatures = cell(numel(windowSecs),1);
candidateCounts = zeros(1,numel(windowSecs));
selectedCounts = zeros(1,numel(windowSecs));

for scaleIndex = 1:numel(windowSecs)
    windowSec = windowSecs(scaleIndex);
    windowSamples = round(windowSec*fs);
    baseEpochsPerWindow = round(windowSec/baseArtifactEpochSec);

    candidateSegment = [];
    candidateWindow = [];

    for segmentIndex = 1:nSegments
        nWindows = floor(size(processedSegments{segmentIndex},1)/windowSamples);
        mask = artifactMasks{segmentIndex};

        for windowIndex = 1:nWindows
            baseStart = (windowIndex-1)*baseEpochsPerWindow+1;
            baseRange = baseStart:(baseStart+baseEpochsPerWindow-1);

            if max(baseRange)<=numel(mask) && ~any(mask(baseRange))
                candidateSegment(end+1,1) = segmentIndex; %#ok<AGROW>
                candidateWindow(end+1,1) = windowIndex; %#ok<AGROW>
            end
        end
    end

    candidateCounts(scaleIndex) = numel(candidateSegment);

    if candidateCounts(scaleIndex)<minimumCleanWindows(scaleIndex)
        error(['%s受试者%s在%d秒尺度只有%d个干净候选窗口，' ...
               '低于要求的%d个。'], ...
            stateCode,subjectID,windowSec, ...
            candidateCounts(scaleIndex),minimumCleanWindows(scaleIndex));
    end

    selectedCandidateIndex = selectUniformIndices( ...
        candidateCounts(scaleIndex),maximumWindows);

    selectedCounts(scaleIndex) = numel(selectedCandidateIndex);
    windowFeatures = zeros(selectedCounts(scaleIndex),nWindowFeatures);

    for localIndex = 1:selectedCounts(scaleIndex)
        candidateIndex = selectedCandidateIndex(localIndex);
        segmentIndex = candidateSegment(candidateIndex);
        windowIndex = candidateWindow(candidateIndex);

        sampleIndices = (windowIndex-1)*windowSamples+(1:windowSamples);
        XWindow = processedSegments{segmentIndex}(sampleIndices,:);
        XWindow = normalizeColumns(detrend(XWindow,'linear'));

        windowFeatures(localIndex,:) = extractWindowFeaturesMPHCED( ...
            XWindow,fs,grangerOrders(scaleIndex), ...
            entropyM,entropyRRatio,fuzzyExponent, ...
            permutationOrder,permutationTau,maxEntropyTemplates, ...
            grangerLambda);
    end

    subjectScaleFeatures{scaleIndex} = single([ ...
        mean(windowFeatures,1),std(windowFeatures,0,1)]);
end

qualityRow = table( ...
    subjectID,string(stateCode),label,nSegments, ...
    mean(badChannelCounts),max(badChannelCounts), ...
    sum(artifactEpochCounts), ...
    candidateCounts(1),candidateCounts(2),candidateCounts(3), ...
    selectedCounts(1),selectedCounts(2),selectedCounts(3), ...
    strjoin(string(segmentRows),','), ...
    'VariableNames', { ...
    'SubjectID','State','Label','NumSegments', ...
    'MeanBadChannelsPerSegment','MaxBadChannelsPerSegment', ...
    'TotalArtifactOneSecondEpochs', ...
    'CandidateWindows1s','CandidateWindows2s','CandidateWindows5s', ...
    'SelectedWindows1s','SelectedWindows2s','SelectedWindows5s', ...
    'SourceSegmentRows'});
end

function X = segmentCellRowToMatrix(cellRow)
nChannels = numel(cellRow);
nSamples = numel(cellRow{1});
X = zeros(nSamples,nChannels);
for channelIndex = 1:nChannels
    signal = double(cellRow{channelIndex}(:));
    if numel(signal)~=nSamples
        error('同一片段内通道长度不一致。');
    end
    X(:,channelIndex) = signal;
end
end

function [X,badChannels] = preprocessSegment( ...
    X,fs,coordinates,filterOrder,passBand)

for channelIndex = 1:size(X,2)
    signal = X(:,channelIndex);
    valid = isfinite(signal);
    if any(valid)
        signal(~valid) = median(signal(valid));
    else
        signal(:) = 0;
    end
    X(:,channelIndex) = signal;
end

X = detrend(X,'linear');
[b,a] = butter(filterOrder,passBand/(fs/2),'bandpass');
X = filtfilt(b,a,X);

channelStd = std(X,0,1)';
validStd = channelStd(isfinite(channelStd)&channelStd>0);
if isempty(validStd)
    medianStd = 1;
else
    medianStd = median(validStd);
end

scaleRatio = channelStd/max(medianStd,eps);
flatBad = ~isfinite(channelStd)|scaleRatio<0.01;
extremeScaleBad = scaleRatio<0.05|scaleRatio>20;
badChannels = flatBad|extremeScaleBad;

X = interpolateBadChannels( ...
    X,badChannels,coordinates,4);

% 公共平均参考。若确认ECdata/EOdata已经是其他固定参考，可将此行注释，
% 并在方法部分说明实际参考方案。
X = X-mean(X,2);
X = normalizeColumns(X);
end

function XOut = interpolateBadChannels( ...
    X,badChannels,coordinates,neighborCount)

XOut = X;
if ~any(badChannels)
    return;
end

goodChannels = find(~badChannels);
badIndices = find(badChannels);
if isempty(goodChannels)
    error('一个60秒片段全部通道均被判为坏导。');
end

unitCoordinates = normalizeRows(coordinates);

for badChannel = badIndices'
    angularDistance = acos(max(min( ...
        unitCoordinates(goodChannels,:)* ...
        unitCoordinates(badChannel,:)',1),-1));

    [sortedDistance,order] = sort(angularDistance,'ascend');
    count = min(neighborCount,numel(goodChannels));
    selected = goodChannels(order(1:count));
    distance = sortedDistance(1:count);

    weights = 1./(distance.^2+1e-6);
    weights = weights/sum(weights);
    XOut(:,badChannel) = X(:,selected)*weights;
end
end

function artifactMask = detectArtifactEpochs( ...
    X,fs,epochSec,channelNames,zThreshold,expansionEpochs)

epochSamples = round(epochSec*fs);
nEpochs = floor(size(X,1)/epochSamples);
nChannels = size(X,2);

metrics = zeros(nEpochs,5);
rmsMatrix = zeros(nEpochs,nChannels);

frontalChannels = find(ismember(channelNames, ...
    {'Fp1','Fp2','F3','F4','F7','F8','Fz'}));

nfft = 2^nextpow2(epochSamples);
frequencies = (0:nfft-1)*fs/nfft;
positive = 1:(floor(nfft/2)+1);
frequencies = frequencies(positive);

totalBand = frequencies>=1&frequencies<=45;
lowBand = frequencies>=1&frequencies<=4;
highBand = frequencies>=30&frequencies<=45;

for epochIndex = 1:nEpochs
    indices = (epochIndex-1)*epochSamples+(1:epochSamples);
    segment = X(indices,:);

    peakToPeak = max(segment,[],1)-min(segment,[],1);
    derivativeRMS = sqrt(mean(diff(segment,1,1).^2,1));
    rmsMatrix(epochIndex,:) = sqrt(mean(segment.^2,1));

    centered = segment-mean(segment,1);
    variance = mean(centered.^2,1);
    kurtosisValue = mean(centered.^4,1)./(variance.^2+eps);

    spectrum = fft(segment,nfft,1);
    powerSpectrum = abs(spectrum(positive,:)).^2;
    totalPower = sum(powerSpectrum(totalBand,:),1)+eps;
    highRatio = sum(powerSpectrum(highBand,:),1)./totalPower;
    lowRatio = sum(powerSpectrum(lowBand,:),1)./totalPower;

    metrics(epochIndex,1) = median(peakToPeak);
    metrics(epochIndex,2) = median(derivativeRMS);
    metrics(epochIndex,3) = median(highRatio);
    metrics(epochIndex,4) = median(lowRatio(frontalChannels));
    metrics(epochIndex,5) = median(abs(kurtosisValue-3));
end

metricZ = zeros(size(metrics));
for metricIndex = 1:size(metrics,2)
    metricZ(:,metricIndex) = robustZ(metrics(:,metricIndex));
end

rmsZ = zeros(size(rmsMatrix));
for channelIndex = 1:nChannels
    rmsZ(:,channelIndex) = ...
        robustZ(log(rmsMatrix(:,channelIndex)+eps));
end

outlierChannelFraction = mean(abs(rmsZ)>zThreshold,2);
artifactMask = any(metricZ>zThreshold,2)| ...
    outlierChannelFraction>0.20;

if expansionEpochs>0
    artifactMask = conv(double(artifactMask), ...
        ones(2*expansionEpochs+1,1),'same')>0;
end
end

function selected = selectUniformIndices(totalCount,maximumCount)
if totalCount<=maximumCount
    selected = (1:totalCount)';
else
    selected = unique(round(linspace( ...
        1,totalCount,maximumCount)))';

    if numel(selected)<maximumCount
        remaining = setdiff((1:totalCount)',selected,'stable');
        selected = [selected; ...
            remaining(1:maximumCount-numel(selected))];
        selected = sort(selected);
    end
end
end

%% ====================== 窗口特征 ======================
function features = extractWindowFeaturesMPHCED( ...
    X,fs,gcOrder,entropyM,entropyRRatio,fuzzyExponent, ...
    permutationOrder,permutationTau,maxEntropyTemplates, ...
    grangerLambda)

nChannels = size(X,2);
entropyMatrix = zeros(nChannels,5);

for channelIndex = 1:nChannels
    signal = X(:,channelIndex);
    signal = (signal-mean(signal))/max(std(signal),eps);
    tolerance = entropyRRatio*std(signal);

    entropyMatrix(channelIndex,1) = approximateEntropy( ...
        signal,entropyM,tolerance,maxEntropyTemplates);
    entropyMatrix(channelIndex,2) = fuzzyEntropy( ...
        signal,entropyM,tolerance,fuzzyExponent,maxEntropyTemplates);
    entropyMatrix(channelIndex,3) = sampleEntropy( ...
        signal,entropyM,tolerance,maxEntropyTemplates);
    entropyMatrix(channelIndex,4) = permutationEntropy( ...
        signal,permutationOrder,permutationTau);
    entropyMatrix(channelIndex,5) = spectralEntropyValue(signal,fs);
end

entropyFeatures = reshape(entropyMatrix',1,[]);
plvFeatures = vectorizePLV(calculatePLV(X));

gcMatrix = conditionalMultivariateGranger( ...
    X,gcOrder,grangerLambda);
gcFeatures = vectorizeDirectedGranger(gcMatrix);

features = [entropyFeatures,plvFeatures,gcFeatures];
features(~isfinite(features)) = 0;
end

function gc = conditionalMultivariateGranger(X,order,lambda)
% gc(source,target)：控制其余18个通道及目标自身历史后，
% source对target的附加预测增益。

X = normalizeColumns(X);
[nSamples,nSignals] = size(X);

if nSamples<=order+nSignals*order+5
    error('采样点不足以估计%d阶19变量VAR。',order);
end

lagMatrix = zeros(nSamples-order,nSignals*order);
for lag = 1:order
    columns = (lag-1)*nSignals+(1:nSignals);
    lagMatrix(:,columns) = ...
        X(order+1-lag:nSamples-lag,:);
end

fullDesign = [ones(size(lagMatrix,1),1),lagMatrix];
penaltyFull = eye(size(fullDesign,2));
penaltyFull(1,1) = 0;

gc = zeros(nSignals,nSignals);

for target = 1:nSignals
    response = X(order+1:end,target);

    betaFull = (fullDesign'*fullDesign+lambda*penaltyFull)\ ...
        (fullDesign'*response);
    residualFull = response-fullDesign*betaFull;
    varianceFull = mean(residualFull.^2);

    for source = 1:nSignals
        if source==target
            continue;
        end

        sourceColumns = 1+source+(0:order-1)*nSignals;
        keepColumns = true(1,size(fullDesign,2));
        keepColumns(sourceColumns) = false;

        restrictedDesign = fullDesign(:,keepColumns);
        penaltyRestricted = eye(size(restrictedDesign,2));
        penaltyRestricted(1,1) = 0;

        betaRestricted = ...
            (restrictedDesign'*restrictedDesign+ ...
             lambda*penaltyRestricted)\ ...
            (restrictedDesign'*response);

        residualRestricted = response-restrictedDesign*betaRestricted;
        varianceRestricted = mean(residualRestricted.^2);

        score = log((varianceRestricted+eps)/(varianceFull+eps));
        gc(source,target) = max(score,0);
    end
end
end

function feature = vectorizeDirectedGranger(matrix)
n = size(matrix,1);
feature = zeros(1,n*(n-1));
writeIndex = 1;
for source = 1:n
    for target = 1:n
        if source~=target
            feature(writeIndex) = matrix(source,target);
            writeIndex = writeIndex+1;
        end
    end
end
end

%% ====================== 受试者级LOPO ======================
function result = runSubjectLOPO( ...
    X,y,subjectIDs,covariates,classifierCode, ...
    selectedFeatureCount,numberOfTrees)

nSubjects = numel(y);
predictedLabel = zeros(nSubjects,1);
patientScore = zeros(nSubjects,1);
selectedIndices = cell(nSubjects,1);
selectionFrequency = zeros(1,size(X,2));

for heldOut = 1:nSubjects
    trainMask = true(nSubjects,1);
    trainMask(heldOut) = false;
    testMask = ~trainMask;

    XTrain = X(trainMask,:);
    XTest = X(testMask,:);
    yTrain = y(trainMask);

    medianValues = finiteColumnMedian(XTrain);
    XTrain = replaceNonfinite(XTrain,medianValues);
    XTest = replaceNonfinite(XTest,medianValues);

    if ~isempty(covariates)
        [XTrain,XTest] = correctConfoundsTrainingOnly( ...
            XTrain,XTest,covariates(trainMask,:), ...
            covariates(testMask,:));
    end

    trainingMean = mean(XTrain,1);
    trainingStd = std(XTrain,0,1);
    trainingStd(trainingStd<1e-12) = 1;
    XTrain = (XTrain-trainingMean)./trainingStd;
    XTest = (XTest-trainingMean)./trainingStd;

    fisherScore = calculateFisherScoreSubject(XTrain,yTrain);
    [~,rankedFeatures] = sort(fisherScore,'descend');

    selectedCount = min(selectedFeatureCount,size(XTrain,2));
    selected = rankedFeatures(1:selectedCount);
    selectedIndices{heldOut} = selected;
    selectionFrequency(selected) = selectionFrequency(selected)+1;

    model = trainClassifier( ...
        XTrain(:,selected),yTrain,classifierCode,numberOfTrees);

    [label,score,threshold] = predictClassifier( ...
        model,XTest(:,selected),classifierCode);

    predictedLabel(heldOut) = double(score>=threshold);
    patientScore(heldOut) = score;

    fprintf('  留出%2d/%2d，ID=%s，真实=%d，预测=%d，分数=%.4f\n', ...
        heldOut,nSubjects,subjectIDs(heldOut), ...
        y(heldOut),predictedLabel(heldOut),score);
end

result = struct();
result.SubjectIDs = subjectIDs;
result.TrueLabel = y;
result.PredictedLabel = predictedLabel;
result.PatientScore = patientScore;
result.SelectedIndices = selectedIndices;
result.SelectionFrequency = selectionFrequency;
result.SelectedFeatureCount = min(selectedFeatureCount,size(X,2));
result.Metrics = calculateMetrics(y,predictedLabel,patientScore);
end

function [trainCorrected,testCorrected] = ...
    correctConfoundsTrainingOnly(XTrain,XTest,covTrain,covTest)

covMean = mean(covTrain,1);
covStd = std(covTrain,0,1);
covStd(covStd<1e-12) = 1;

covTrainZ = (covTrain-covMean)./covStd;
covTestZ = (covTest-covMean)./covStd;

designTrain = [ones(size(covTrainZ,1),1),covTrainZ];
designTest = [ones(size(covTestZ,1),1),covTestZ];

penalty = eye(size(designTrain,2));
penalty(1,1) = 0;
lambda = 1e-6;

beta = (designTrain'*designTrain+lambda*penalty)\ ...
    (designTrain'*XTrain);

trainCorrected = XTrain-designTrain*beta;
testCorrected = XTest-designTest*beta;
end

function score = calculateFisherScoreSubject(X,y)
class0 = X(y==0,:);
class1 = X(y==1,:);
score = (mean(class1,1)-mean(class0,1)).^2./ ...
    (var(class1,0,1)+var(class0,0,1)+eps);
score(~isfinite(score)) = 0;
end

function tableOut = makeSelectionTable( ...
    frequency,featureNames,conditionCode,scaleSec, ...
    classifierCode,nSubjects)

tableOut = table( ...
    repmat(string(conditionCode),numel(featureNames),1), ...
    repmat(scaleSec,numel(featureNames),1), ...
    repmat(string(classifierCode),numel(featureNames),1), ...
    string(featureNames(:)),frequency(:),frequency(:)/nSubjects, ...
    'VariableNames',{'Condition','ScaleSec','Classifier', ...
    'FeatureName','SelectedFoldCount','SelectedFoldFraction'});

tableOut = sortrows(tableOut,'SelectedFoldCount','descend');
end

function writeMPHCEDSummary( ...
    filePath,rankingTable,bestResult,hasCovariates, ...
    maximumWindows,selectedFeatureCount,signature)

fileID = fopen(filePath,'w');
cleanup = onCleanup(@() fclose(fileID)); %#ok<NASGU>

fprintf(fileID,'MPHCED：EC/EO多尺度熵+PLV+条件多变量Granger\n\n');
fprintf(fileID,'每个片段：60秒、19通道、256 Hz。\n');
fprintf(fileID,['同一受试者全部片段统一归组，' ...
    '每状态每尺度最多均匀选择%d个干净窗口。\n'],maximumWindows);
fprintf(fileID,['每窗口608维；受试者内均值+标准差后，' ...
    'EC或EO每尺度1216维。\n']);
fprintf(fileID,['EC+EO在受试者级拼接，' ...
    '不把同一人的EC和EO当作独立样本。\n']);
fprintf(fileID,'训练折内Fisher筛选前%d个特征。\n', ...
    selectedFeatureCount);
fprintf(fileID,'个体级混杂校正：%d。\n',hasCovariates);
fprintf(fileID,'配置签名：%s\n\n',signature);

m = bestResult.Metrics;
fprintf(fileID,'最佳实验：%s + %d秒 + %s\n', ...
    bestResult.Condition,bestResult.ScaleSec,bestResult.Classifier);
fprintf(fileID,'Accuracy=%.6f\n',m.Accuracy);
fprintf(fileID,'Sensitivity=%.6f\n',m.Sensitivity);
fprintf(fileID,'Specificity=%.6f\n',m.Specificity);
fprintf(fileID,'Precision=%.6f\n',m.Precision);
fprintf(fileID,'F1=%.6f\n',m.F1);
fprintf(fileID,'BalancedAccuracy=%.6f\n',m.BalancedAccuracy);
fprintf(fileID,'MCC=%.6f\n',m.MCC);
fprintf(fileID,'AUC=%.6f\n\n',m.AUC);

fprintf(fileID,'前20名实验：\n');
for row = 1:min(20,height(rankingTable))
    fprintf(fileID,['%2d. %s + %d秒 + %s，' ...
        'BalAcc=%.4f，AUC=%.4f，MCC=%.4f，Acc=%.4f\n'], ...
        row,rankingTable.Condition(row),rankingTable.ScaleSec(row), ...
        rankingTable.Classifier(row), ...
        rankingTable.BalancedAccuracy(row),rankingTable.AUC(row), ...
        rankingTable.MCC(row),rankingTable.Accuracy(row));
end
end

%% ====================== 基础辅助函数 ======================
function X = normalizeColumns(X)
columnMean = mean(X,1);
columnStd = std(X,0,1);
columnStd(columnStd<1e-12) = 1;
X = (X-columnMean)./columnStd;
end

function z = robustZ(x)
x = double(x(:));
center = median(x);
scale = 1.4826*median(abs(x-center));
if scale<eps
    scale = std(x);
end
if scale<eps
    scale = 1;
end
z = (x-center)/scale;
end

function X = normalizeRows(X)
normValue = sqrt(sum(X.^2,2));
normValue(normValue<eps) = 1;
X = X./normValue;
end

function coordinates = standard1020Coordinates(channelNames)
coordinateMap = containers.Map();
coordinateMap('Fp1') = [-0.35  0.92  0.18];
coordinateMap('Fp2') = [ 0.35  0.92  0.18];
coordinateMap('F7')  = [-0.85  0.42  0.30];
coordinateMap('F3')  = [-0.45  0.50  0.72];
coordinateMap('Fz')  = [ 0.00  0.55  0.84];
coordinateMap('F4')  = [ 0.45  0.50  0.72];
coordinateMap('F8')  = [ 0.85  0.42  0.30];
coordinateMap('T3')  = [-1.00  0.00  0.05];
coordinateMap('C3')  = [-0.55  0.00  0.83];
coordinateMap('Cz')  = [ 0.00  0.00  1.00];
coordinateMap('C4')  = [ 0.55  0.00  0.83];
coordinateMap('T4')  = [ 1.00  0.00  0.05];
coordinateMap('T5')  = [-0.85 -0.45  0.28];
coordinateMap('P3')  = [-0.45 -0.48  0.75];
coordinateMap('Pz')  = [ 0.00 -0.55  0.84];
coordinateMap('P4')  = [ 0.45 -0.48  0.75];
coordinateMap('T6')  = [ 0.85 -0.45  0.28];
coordinateMap('O1')  = [-0.32 -0.90  0.28];
coordinateMap('O2')  = [ 0.32 -0.90  0.28];

coordinates = zeros(numel(channelNames),3);
for k = 1:numel(channelNames)
    coordinates(k,:) = coordinateMap(channelNames{k});
end
coordinates = normalizeRows(coordinates);
end
function value = approximateEntropy(x, m, r, maximumTemplates)
phiM = approximatePhi(x, m, r, maximumTemplates);
phiM1 = approximatePhi(x, m + 1, r, maximumTemplates);
value = phiM - phiM1;
end

function phi = approximatePhi(x, m, r, maximumTemplates)
templates = makeTemplates(x, m);
templates = selectTemplateRows(templates, maximumTemplates);
distanceMatrix = chebyshevDistances(templates);
matchRatio = sum(distanceMatrix <= r, 2) / size(templates, 1);
phi = mean(log(max(matchRatio, eps)));
end

function value = sampleEntropy(x, m, r, maximumTemplates)
templatesM = selectTemplateRows(makeTemplates(x, m), maximumTemplates);
templatesM1 = selectTemplateRows(makeTemplates(x, m + 1), maximumTemplates);

probabilityM = pairMatchProbability(templatesM, r);
probabilityM1 = pairMatchProbability(templatesM1, r);
value = -log((probabilityM1 + eps) / (probabilityM + eps));
end

function probability = pairMatchProbability(templates, r)
n = size(templates, 1);
if n < 2
    probability = 0;
    return;
end

distanceMatrix = chebyshevDistances(templates);
upperMask = triu(true(n), 1);
probability = sum(distanceMatrix(upperMask) <= r) / ...
    (n * (n - 1) / 2);
end

function value = fuzzyEntropy( ...
    x, m, r, fuzzyExponent, maximumTemplates)

phiM = fuzzyPhi(x, m, r, fuzzyExponent, maximumTemplates);
phiM1 = fuzzyPhi(x, m + 1, r, fuzzyExponent, maximumTemplates);
value = log(phiM + eps) - log(phiM1 + eps);
end

function phi = fuzzyPhi( ...
    x, m, r, fuzzyExponent, maximumTemplates)

templates = makeTemplates(x, m);
templates = templates - mean(templates, 2);
templates = selectTemplateRows(templates, maximumTemplates);
n = size(templates, 1);

if n < 2
    phi = 0;
    return;
end

distanceMatrix = chebyshevDistances(templates);
similarity = exp(-(distanceMatrix .^ fuzzyExponent) / max(r, eps));
similarity(1:n+1:end) = 0;
phi = sum(similarity(:)) / (n * (n - 1));
end

function value = permutationEntropy(x, order, tau)
numberOfPatterns = numel(x) - (order - 1) * tau;
patterns = zeros(numberOfPatterns, order);

for rowIndex = 1:numberOfPatterns
    indices = rowIndex + (0:order-1) * tau;
    [~, patterns(rowIndex, :)] = sort(x(indices), 'ascend');
end

[~, ~, patternIndex] = unique(patterns, 'rows');
counts = accumarray(patternIndex, 1);
probabilities = counts / sum(counts);
value = -sum(probabilities .* log(probabilities + eps)) / log(factorial(order));
end

function value = spectralEntropyValue(x, fs)
[powerSpectrum, ~] = pwelch(x, [], [], [], fs);
probabilities = powerSpectrum / max(sum(powerSpectrum), eps);
value = -sum(probabilities .* log(probabilities + eps)) / ...
    log(numel(probabilities));
end

function templates = makeTemplates(x, m)
numberOfTemplates = numel(x) - m + 1;
templates = zeros(numberOfTemplates, m);
for columnIndex = 1:m
    templates(:, columnIndex) = ...
        x(columnIndex:columnIndex + numberOfTemplates - 1);
end
end

function templates = selectTemplateRows(templates, maximumTemplates)
if size(templates, 1) > maximumTemplates
    selectedRows = unique(round(linspace( ...
        1, size(templates, 1), maximumTemplates)), 'stable');
    templates = templates(selectedRows, :);
end
end

function distances = chebyshevDistances(templates)
n = size(templates, 1);
distances = zeros(n, n);
for rowIndex = 1:n
    distances(rowIndex, :) = max(abs( ...
        templates - templates(rowIndex, :)), [], 2).';
end
end

%% ====================== PLV与Granger ======================
function plvMatrix = calculatePLV(X)
phase = angle(hilbert(X));
unitPhase = exp(1i * phase);
plvMatrix = abs((unitPhase' * unitPhase) / size(unitPhase, 1));
plvMatrix = (plvMatrix + plvMatrix') / 2;
plvMatrix(1:size(plvMatrix, 1)+1:end) = 0;
end

function feature = vectorizePLV(plvMatrix)
nChannels = size(plvMatrix, 1);
feature = zeros(1, nChannels * (nChannels - 1) / 2);
writeIndex = 1;

for firstChannel = 1:nChannels-1
    for secondChannel = firstChannel+1:nChannels
        feature(writeIndex) = ...
            plvMatrix(firstChannel, secondChannel);
        writeIndex = writeIndex + 1;
    end
end
end

function model = trainClassifier(X, y, classifierCode, numberOfTrees)
switch classifierCode
    case 'LinearSVM'
        model = fitcsvm(X, y, ...
            'KernelFunction', 'linear', ...
            'BoxConstraint', 1, ...
            'ClassNames', [0; 1]);

    case 'RBFSVM'
        model = fitcsvm(X, y, ...
            'KernelFunction', 'rbf', ...
            'KernelScale', 'auto', ...
            'BoxConstraint', 1, ...
            'ClassNames', [0; 1]);

    case 'Logistic'
        model = fitclinear(X, y, ...
            'Learner', 'logistic', ...
            'Regularization', 'ridge', ...
            'Lambda', 1e-3, ...
            'ClassNames', [0; 1]);

    case 'LDA'
        model = fitcdiscr(X, y, ...
            'DiscrimType', 'linear', ...
            'Gamma', 0.1, ...
            'ClassNames', [0; 1]);

    case 'KNN'
        % 不使用 fitcknn，避免部分 MATLAB 版本中
        % ClassificationKNN/predict 调用 gather 时发生兼容性错误。
        model = struct();
        model.Type = 'ManualKNN';
        model.XTrain = X;
        model.YTrain = double(y(:));
        model.NumNeighbors = min(5, size(X, 1));

    case 'RF'
        % 不使用 TreeBagger/fitctree，避免其内部 growTree 调用
        % 冲突的 gather 函数。这里使用程序内置 CART 随机森林。
        model = trainManualRandomForest(X, y, numberOfTrees);
end
end

function [label, patientScore, threshold] = ...
    predictClassifier(model, X, classifierCode)

if strcmp(classifierCode, 'RF')
    [label, patientScore] = predictManualRandomForest(model, X);
    threshold = 0.5;
    return;
end

if strcmp(classifierCode, 'KNN')
    [label, patientScore] = predictManualKNN(model, X);
    threshold = 0.5;
    return;
end

[label, score] = predict(model, X);
classNames = model.ClassNames;
positiveColumn = find(classNames == 1, 1);
patientScore = score(:, positiveColumn);

if any(strcmp(classifierCode, {'LinearSVM','RBFSVM'}))
    threshold = 0;
else
    threshold = 0.5;
end
end


function [label, patientScore] = predictManualKNN(model, XTest)
% 欧氏距离 + squared-inverse 权重，与原 fitcknn 设置一致。
nTest = size(XTest, 1);
patientScore = zeros(nTest, 1);
k = model.NumNeighbors;

for testIndex = 1:nTest
    difference = bsxfun(@minus, model.XTrain, XTest(testIndex, :));
    squaredDistance = sum(difference .^ 2, 2);
    [sortedDistance, order] = sort(squaredDistance, 'ascend');

    neighborIndex = order(1:k);
    neighborDistance = sortedDistance(1:k);
    neighborLabel = model.YTrain(neighborIndex);

    zeroDistance = neighborDistance <= eps;
    if any(zeroDistance)
        patientScore(testIndex) = mean(neighborLabel(zeroDistance));
    else
        weight = 1 ./ neighborDistance;
        patientScore(testIndex) = ...
            sum(weight .* neighborLabel) / sum(weight);
    end
end

label = double(patientScore >= 0.5);
end


function model = trainManualRandomForest(X, y, numberOfTrees)
% 纯MATLAB二分类随机森林，不调用 TreeBagger、fitctree 或 gather。
y = double(y(:));
[nSamples, nFeatures] = size(X);

model = struct();
model.Type = 'ManualRF';
model.NumTrees = numberOfTrees;
model.Trees = cell(numberOfTrees, 1);
model.MinLeafSize = 5;
model.MaxDepth = 10;
model.NumPredictorsToSample = max(1, floor(sqrt(nFeatures)));
model.MaxSplitCandidates = 16;

for treeIndex = 1:numberOfTrees
    bootstrapIndex = randi(nSamples, nSamples, 1);
    model.Trees{treeIndex} = growManualTree( ...
        X(bootstrapIndex, :), y(bootstrapIndex), 0, ...
        model.MinLeafSize, model.MaxDepth, ...
        model.NumPredictorsToSample, model.MaxSplitCandidates);
end
end

function node = growManualTree( ...
    X, y, depth, minLeafSize, maxDepth, ...
    predictorsPerSplit, maxSplitCandidates)

node = struct( ...
    'IsLeaf', true, ...
    'Probability', mean(y), ...
    'Feature', 0, ...
    'Threshold', 0, ...
    'Left', [], ...
    'Right', []);

nSamples = size(X, 1);
if depth >= maxDepth || ...
        nSamples < 2 * minLeafSize || ...
        all(y == y(1))
    return;
end

nFeatures = size(X, 2);
featureOrder = randperm(nFeatures, min(predictorsPerSplit, nFeatures));
bestGini = inf;
bestFeature = 0;
bestThreshold = 0;

for featureIndex = featureOrder
    values = X(:, featureIndex);
    [sortedValues, order] = sort(values, 'ascend');
    sortedLabels = y(order);

    splitPositions = (1:nSamples-1)';
    validMask = ...
        sortedValues(1:end-1) < sortedValues(2:end) & ...
        splitPositions >= minLeafSize & ...
        (nSamples - splitPositions) >= minLeafSize;
    validPosition = splitPositions(validMask);

    if isempty(validPosition)
        continue;
    end

    if numel(validPosition) > maxSplitCandidates
        selectedPosition = round(linspace( ...
            1, numel(validPosition), maxSplitCandidates));
        validPosition = validPosition(selectedPosition);
    end

    cumulativePositive = cumsum(sortedLabels == 1);
    totalPositive = cumulativePositive(end);

    leftCount = validPosition;
    rightCount = nSamples - validPosition;
    leftPositive = cumulativePositive(validPosition);
    rightPositive = totalPositive - leftPositive;

    leftNegative = leftCount - leftPositive;
    rightNegative = rightCount - rightPositive;

    leftGini = 1 - ...
        (leftPositive ./ leftCount) .^ 2 - ...
        (leftNegative ./ leftCount) .^ 2;
    rightGini = 1 - ...
        (rightPositive ./ rightCount) .^ 2 - ...
        (rightNegative ./ rightCount) .^ 2;

    weightedGini = ...
        (leftCount .* leftGini + rightCount .* rightGini) ./ nSamples;
    [featureBestGini, localIndex] = min(weightedGini);

    if featureBestGini < bestGini
        splitPosition = validPosition(localIndex);
        bestGini = featureBestGini;
        bestFeature = featureIndex;
        bestThreshold = ...
            (sortedValues(splitPosition) + ...
             sortedValues(splitPosition + 1)) / 2;
    end
end

if bestFeature == 0
    return;
end

leftMask = X(:, bestFeature) <= bestThreshold;
rightMask = ~leftMask;
if sum(leftMask) < minLeafSize || sum(rightMask) < minLeafSize
    return;
end

node.IsLeaf = false;
node.Feature = bestFeature;
node.Threshold = bestThreshold;
node.Left = growManualTree( ...
    X(leftMask, :), y(leftMask), depth + 1, ...
    minLeafSize, maxDepth, predictorsPerSplit, maxSplitCandidates);
node.Right = growManualTree( ...
    X(rightMask, :), y(rightMask), depth + 1, ...
    minLeafSize, maxDepth, predictorsPerSplit, maxSplitCandidates);
end

function [label, patientScore] = predictManualRandomForest(model, X)
nSamples = size(X, 1);
patientScore = zeros(nSamples, 1);

for treeIndex = 1:model.NumTrees
    tree = model.Trees{treeIndex};
    for sampleIndex = 1:nSamples
        patientScore(sampleIndex) = patientScore(sampleIndex) + ...
            predictManualTree(tree, X(sampleIndex, :));
    end
end

patientScore = patientScore / model.NumTrees;
label = double(patientScore >= 0.5);
end

function probability = predictManualTree(node, sample)
while ~node.IsLeaf
    if sample(node.Feature) <= node.Threshold
        node = node.Left;
    else
        node = node.Right;
    end
end
probability = node.Probability;
end

function medianValues = finiteColumnMedian(X)
medianValues = zeros(1, size(X, 2));
for columnIndex = 1:size(X, 2)
    values = X(isfinite(X(:, columnIndex)), columnIndex);
    if isempty(values)
        medianValues(columnIndex) = 0;
    else
        medianValues(columnIndex) = median(values);
    end
end
end

function X = replaceNonfinite(X, replacement)
for columnIndex = 1:size(X, 2)
    invalid = ~isfinite(X(:, columnIndex));
    X(invalid, columnIndex) = replacement(columnIndex);
end
end

%% ====================== 指标与输出 ======================
function metrics = calculateMetrics(trueLabel, predictedLabel, score)
trueLabel = double(trueLabel(:));
predictedLabel = double(predictedLabel(:));
score = double(score(:));

TN = sum(trueLabel == 0 & predictedLabel == 0);
FP = sum(trueLabel == 0 & predictedLabel == 1);
FN = sum(trueLabel == 1 & predictedLabel == 0);
TP = sum(trueLabel == 1 & predictedLabel == 1);

accuracy = (TP + TN) / max(TP + TN + FP + FN, 1);
sensitivity = TP / max(TP + FN, 1);
specificity = TN / max(TN + FP, 1);
precision = TP / max(TP + FP, 1);
f1 = 2 * precision * sensitivity / max(precision + sensitivity, eps);
balancedAccuracy = (sensitivity + specificity) / 2;

mccDenominator = sqrt( ...
    max((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN), eps));
mcc = (TP * TN - FP * FN) / mccDenominator;
auc = calculateAUC(trueLabel, score);

metrics = struct();
metrics.Accuracy = accuracy;
metrics.Sensitivity = sensitivity;
metrics.Specificity = specificity;
metrics.Precision = precision;
metrics.F1 = f1;
metrics.BalancedAccuracy = balancedAccuracy;
metrics.MCC = mcc;
metrics.AUC = auc;
metrics.ConfusionMatrix = [TN FP; FN TP];
end

function auc = calculateAUC(y, score)
positiveScores = score(y == 1);
negativeScores = score(y == 0);

comparison = positiveScores(:) > negativeScores(:).';
ties = positiveScores(:) == negativeScores(:).';
auc = (sum(comparison(:)) + 0.5 * sum(ties(:))) / ...
    max(numel(positiveScores) * numel(negativeScores), 1);
end

function plotConfusionMatrix(confusionMatrix, experimentName, outputFile)
figure('Visible', 'off');
imagesc(confusionMatrix);
axis equal tight;
colorbar;
xlabel('预测标签');
ylabel('真实标签');
title(['最佳实验混淆矩阵：' experimentName], 'Interpreter', 'none');
set(gca, 'XTick', [1 2], 'XTickLabel', {'0','1'}, ...
    'YTick', [1 2], 'YTickLabel', {'0','1'});

for rowIndex = 1:2
    for columnIndex = 1:2
        text(columnIndex, rowIndex, ...
            num2str(confusionMatrix(rowIndex, columnIndex)), ...
            'HorizontalAlignment', 'center', ...
            'FontWeight', 'bold');
    end
end

saveas(gcf, outputFile);
close(gcf);
end

function plotROC(y, score, auc, experimentName, outputFile)
[sortedScore, order] = sort(score, 'descend'); %#ok<ASGLU>
sortedLabel = y(order);
positiveCount = sum(y == 1);
negativeCount = sum(y == 0);

tpr = [0; cumsum(sortedLabel == 1) / max(positiveCount, 1); 1];
fpr = [0; cumsum(sortedLabel == 0) / max(negativeCount, 1); 1];

figure('Visible', 'off');
plot(fpr, tpr, 'LineWidth', 2);
hold on;
plot([0 1], [0 1], '--');
xlim([0 1]);
ylim([0 1]);
grid on;
xlabel('False Positive Rate');
ylabel('True Positive Rate');
title(sprintf('ROC：%s，AUC=%.4f', experimentName, auc), ...
    'Interpreter', 'none');
saveas(gcf, outputFile);
close(gcf);
end


function [names,types] = makeFeatureNames(nChannels,channelNames)
entropyNames = {'AE','FE','SE','PE','SpecEn'};
nFeatures = nChannels*5+nChannels*(nChannels-1)/2+nChannels*(nChannels-1);
names = cell(1,nFeatures);
types = cell(1,nFeatures);
writeIndex = 1;

for channelIndex = 1:nChannels
    for entropyIndex = 1:numel(entropyNames)
        names{writeIndex} = sprintf('%s_%s', ...
            channelNames{channelIndex},entropyNames{entropyIndex});
        types{writeIndex} = 'Entropy';
        writeIndex = writeIndex+1;
    end
end

for firstChannel = 1:nChannels-1
    for secondChannel = firstChannel+1:nChannels
        names{writeIndex} = sprintf('PLV_%s__%s', ...
            channelNames{firstChannel},channelNames{secondChannel});
        types{writeIndex} = 'PLV';
        writeIndex = writeIndex+1;
    end
end

for sourceChannel = 1:nChannels
    for targetChannel = 1:nChannels
        if sourceChannel~=targetChannel
            names{writeIndex} = sprintf('MVGC_%s_to_%s', ...
                channelNames{sourceChannel},channelNames{targetChannel});
            types{writeIndex} = 'MVGC';
            writeIndex = writeIndex+1;
        end
    end
end
end
