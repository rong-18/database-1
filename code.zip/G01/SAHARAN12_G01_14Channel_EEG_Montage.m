clc; clear; close all;

%% =========================================================
% SAHARAN12_G01_14Channel_EEG_Montage.m
%
% 功能：
%   根据 SAHARAN12-G01（Guinea-Bissau epilepsy EEG）
%   实际使用的 EMOTIV EPOC 14 个 EEG 通道，
%   绘制标准 International 10-20 头皮电极布局示意图。
%
% 已确认的 14 个 EEG 通道：
%   AF3, F7, F3, FC5, T7, P7, O1,
%   O2, P8, T8, FC6, F4, F8, AF4
%
% 说明：
%   1) 数据集使用 EMOTIV EPOC 14-channel headset；
%   2) 通道名称与 EMOTIV EPOC 官方通道一致；
%   3) 本图只绘制 14 个 EEG 通道，不绘制 CMS/DRL 参考传感器；
%   4) 不需要 EEGLAB 或其他额外工具箱；
%   5) 输出 600 dpi PNG、矢量 PDF 和通道列表 TXT。
%
% 注意：
%   若后续要把已有连接矩阵中的 Ch1~Ch14 替换为真实通道名，
%   应再确认你原始导入代码是否保持了 EPOC 原始列顺序。
%% =========================================================

%% 1. 输出目录
outputDir = 'D:\Database\Seizure\SAHARAN\SAHARAN12\G01';

if ~isfolder(outputDir)
    mkdir(outputDir);
end

pngFile = fullfile(outputDir, 'SAHARAN12-G01_14Channel_EEG_Montage.png');
pdfFile = fullfile(outputDir, 'SAHARAN12-G01_14Channel_EEG_Montage.pdf');
txtFile = fullfile(outputDir, 'SAHARAN12-G01_14Channel_List.txt');

%% 2. G01 / EMOTIV EPOC 的 14 个真实 EEG 通道
% 这里采用 EPOC 官方/常用原始通道顺序。
labels = { ...
    'AF3','F7','F3','FC5','T7','P7','O1', ...
    'O2','P8','T8','FC6','F4','F8','AF4'};

%% 3. 标准 10-20 / 10-10 二维头皮位置
% 坐标系：
%   x < 0 = 左半球
%   x > 0 = 右半球
%   y > 0 = 前额
%   y < 0 = 枕部

pos = containers.Map();

pos('AF3') = [-0.30,  0.76];
pos('AF4') = [ 0.30,  0.76];

pos('F7')  = [-0.78,  0.56];
pos('F3')  = [-0.38,  0.55];
pos('F4')  = [ 0.38,  0.55];
pos('F8')  = [ 0.78,  0.56];

pos('FC5') = [-0.60,  0.30];
pos('FC6') = [ 0.60,  0.30];

pos('T7')  = [-0.94,  0.02];
pos('T8')  = [ 0.94,  0.02];

pos('P7')  = [-0.76, -0.50];
pos('P8')  = [ 0.76, -0.50];

pos('O1')  = [-0.28, -0.82];
pos('O2')  = [ 0.28, -0.82];

%% 4. 生成坐标矩阵
xy = zeros(numel(labels), 2);

for i = 1:numel(labels)
    key = upper(labels{i});

    if ~isKey(pos, key)
        error('未定义通道 %s 的标准位置。', labels{i});
    end

    xy(i,:) = pos(key);
end

%% 5. 绘图
fig = figure( ...
    'Color', 'w', ...
    'Position', [100 50 900 980], ...
    'Renderer', 'painters');

ax = axes('Parent', fig);

hold(ax, 'on');
axis(ax, 'equal');
axis(ax, [-1.22 1.22 -1.15 1.18]);
axis(ax, 'off');

%% 6. 头部轮廓
theta = linspace(0, 2*pi, 600);

headX = 1.00 * cos(theta);
headY = 1.04 * sin(theta) - 0.02;

plot(ax, headX, headY, ...
    'k', ...
    'LineWidth', 2.2);

%% 7. 鼻子
plot(ax, ...
    [-0.09 0 0.09], ...
    [1.01 1.15 1.01], ...
    'k', ...
    'LineWidth', 2.2);

%% 8. 左右耳
earT = linspace(-pi/2, pi/2, 120);

leftEarX  = -1.00 - 0.10*cos(earT);
leftEarY  =  0.21*sin(earT);

rightEarX =  1.00 + 0.10*cos(earT);
rightEarY =  0.21*sin(earT);

plot(ax, leftEarX, leftEarY, ...
    'k', 'LineWidth', 2.0);

plot(ax, rightEarX, rightEarY, ...
    'k', 'LineWidth', 2.0);

%% 9. 电极圆点
markerSize = 1250;

scatter(ax, xy(:,1), xy(:,2), markerSize, ...
    'Marker', 'o', ...
    'MarkerFaceColor', [0.30 0.31 0.56], ...
    'MarkerEdgeColor', 'k', ...
    'LineWidth', 0.8);

%% 10. 电极名称
for i = 1:numel(labels)

    text(ax, xy(i,1), xy(i,2), labels{i}, ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'middle', ...
        'Color', 'w', ...
        'FontName', 'Times New Roman', ...
        'FontSize', 15, ...
        'FontWeight', 'bold', ...
        'Interpreter', 'none');
end

%% 11. 标题
title(ax, 'SAHARAN12-G01 | 14-channel EEG montage', ...
    'FontName', 'Times New Roman', ...
    'FontSize', 20, ...
    'FontWeight', 'bold', ...
    'Interpreter', 'none');

%% 12. 保存 PNG
exportgraphics(fig, pngFile, ...
    'Resolution', 600, ...
    'BackgroundColor', 'white');

%% 13. 保存矢量 PDF
exportgraphics(fig, pdfFile, ...
    'ContentType', 'vector', ...
    'BackgroundColor', 'white');

%% 14. 保存通道列表
fid = fopen(txtFile, 'w', 'n', 'UTF-8');

if fid >= 0
    fprintf(fid, 'SAHARAN12-G01 - 14 EEG channels used in the dataset\n\n');
    fprintf(fid, 'EMOTIV EPOC channel order:\n');

    for i = 1:numel(labels)
        fprintf(fid, '%02d\t%s\n', i, labels{i});
    end

    fprintf(fid, '\nNotes:\n');
    fprintf(fid, 'The dataset was recorded with a 14-channel EMOTIV EPOC headset.\n');
    fprintf(fid, 'The plotted locations follow the standard International 10-20/10-10 scalp positions.\n');
    fprintf(fid, 'CMS/DRL reference sensors are not included among the 14 EEG channels.\n');
    fprintf(fid, 'Before relabeling existing Ch1-Ch14 feature matrices, verify that the import code preserves the original EPOC column order.\n');

    fclose(fid);
end

%% 15. 输出信息
fprintf('\n========================================\n');
fprintf('SAHARAN12-G01 脑电通道布局图生成完成\n');
fprintf('通道数：%d\n', numel(labels));
fprintf('通道顺序：\n%s\n', strjoin(labels, ', '));
fprintf('PNG：%s\n', pngFile);
fprintf('PDF：%s\n', pdfFile);
fprintf('通道列表：%s\n', txtFile);
fprintf('========================================\n');

close(fig);
