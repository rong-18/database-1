function G01_EPG_6Classifiers_LOPO_V4
% G数据集：1/2/5秒五种熵 + PLV + Granger，六分类器LOPO
%
% 输入：
%   D:\Database\Seizure\SAHARAN\G_data.mat
%   D:\Database\Seizure\SAHARAN\G_dataLable.mat
%
% 输出：
%   D:\Database\Seizure\SAHARAN\SAHARAN12\G01
%
% 每个窗口的343维特征：
%   14通道 × 5种熵                           = 70维
%   PLV上三角                                = 91维
%   Granger完整非对角线（源通道->目标通道） = 182维
%
% 六种分类器：LinearSVM、RBFSVM、Logistic、LDA、KNN、RF
% 外层验证：每次留出一名受试者的全部窗口；训练集标准化和
% Fisher特征筛选均只使用其余受试者。窗口分数取均值得到受试者结果。
%
% 需要：Signal Processing Toolbox、Statistics and Machine Learning Toolbox

clc;
close all;
rng(20260724, 'twister');

%% 路径
srcDir = 'D:\Database\Seizure\SAHARAN';
outDir = fullfile(srcDir, 'SAHARAN12', 'G01');
if ~exist(outDir, 'dir')
    mkdir(outDir);
end

logFile = fullfile(outDir, 'G01_EPG_run_log_V4.txt');
if exist(logFile, 'file')
    delete(logFile);
end
diary(logFile);
cleanupDiary = onCleanup(@() diary('off')); %#ok<NASGU>

fprintf('开始时间：%s\n', datestr(now));
totalTimer = tic;

%% 固定参数
fs = 128;
useSec = 240;
useSamples = fs * useSec;
windowSecs = [1 2 5];
maxWindowsPerScale = 30;

entropyM = 2;
entropyRRatio = 0.20;
fuzzyExponent = 2;
permutationOrder = 3;
permutationTau = 1;
maxEntropyTemplates = 64;

% 1/2/5秒窗口分别使用2/3/5阶双变量Granger模型。
gcOrders = [2 3 5];

filterOrder = 4;
passBand = [0.5 45];
selectedFeatureCount = 50;
numberOfTrees = 50;  % 纯MATLAB随机森林，控制LOPO运行时间

classifierCodes = { ...
    'LinearSVM', 'RBFSVM', 'Logistic', ...
    'LDA', 'KNN', 'RF'};

classifierDescriptions = { ...
    '线性支持向量机', ...
    '高斯核支持向量机', ...
    'L2逻辑回归', ...
    '正则化线性判别分析', ...
    '5近邻', ...
    '随机森林'};

%% 读取G数据集
S = load(fullfile(srcDir, 'G_data.mat'), 'data');
L = load(fullfile(srcDir, 'G_dataLable.mat'), 'dataLable');

data = S.data;
ySubject = double(L.dataLable(:));
[nSubjects, nChannels] = size(data);

if nChannels ~= 14
    error('当前程序按14通道G数据集编写，实际通道数为%d。', nChannels);
end
if numel(ySubject) ~= nSubjects
    error('标签数量与受试者数量不一致。');
end
if ~all(ismember(ySubject, [0 1]))
    error('标签必须为0或1。');
end

fprintf('受试者：%d，健康：%d，患者：%d\n', ...
    nSubjects, sum(ySubject == 0), sum(ySubject == 1));
fprintf('每名受试者使用前%d秒，每尺度最多%d个窗口。\n', ...
    useSec, maxWindowsPerScale);

%% 特征名称
[featureNames, featureTypes] = makeFeatureNames(nChannels);
nFeatures = numel(featureNames);
fprintf('每个窗口总特征数：%d（熵70 + PLV91 + Granger182）\n', nFeatures);

featureNameTable = table((1:nFeatures)', featureNames(:), featureTypes(:), ...
    'VariableNames', {'FeatureIndex','FeatureName','FeatureType'});
writetable(featureNameTable, fullfile(outDir, 'G01_feature_names_V4.xlsx'));

%% 提取窗口特征；再次运行时直接复用
featureFile = fullfile(outDir, 'G01_window_features_V1.mat');

if exist(featureFile, 'file')
    fprintf('\n读取已保存的窗口特征：\n%s\n', featureFile);
    F = load(featureFile, ...
        'featureSets', 'labelSets', 'subjectSets', 'windowSets', ...
        'featureNames', 'featureTypes', 'windowSecs', 'gcOrders', ...
        'fs', 'useSec', 'maxWindowsPerScale');

    featureSets = F.featureSets;
    labelSets = F.labelSets;
    subjectSets = F.subjectSets;
    windowSets = F.windowSets;
else
    fprintf('\n开始提取1/2/5秒窗口特征……\n');

    featureSets = cell(numel(windowSecs), 1);
    labelSets = cell(numel(windowSecs), 1);
    subjectSets = cell(numel(windowSecs), 1);
    windowSets = cell(numel(windowSecs), 1);

    rowsPerScale = nSubjects * maxWindowsPerScale;
    for scaleIndex = 1:numel(windowSecs)
        featureSets{scaleIndex} = zeros(rowsPerScale, nFeatures);
        labelSets{scaleIndex} = zeros(rowsPerScale, 1);
        subjectSets{scaleIndex} = zeros(rowsPerScale, 1);
        windowSets{scaleIndex} = zeros(rowsPerScale, 1);
    end

    [bFilter, aFilter] = butter( ...
        filterOrder, passBand / (fs / 2), 'bandpass');

    for subjectIndex = 1:nSubjects
        subjectTimer = tic;

        X = readSubjectFirstSeconds( ...
            data, subjectIndex, nChannels, useSamples, fs);
        X = preprocessEEG(X, bFilter, aFilter);

        for scaleIndex = 1:numel(windowSecs)
            windowSec = windowSecs(scaleIndex);
            windowSamples = windowSec * fs;
            availableWindows = floor(size(X, 1) / windowSamples);
            selectedWindows = selectUniformWindows( ...
                availableWindows, maxWindowsPerScale);

            for localIndex = 1:numel(selectedWindows)
                windowNumber = selectedWindows(localIndex);
                sampleIndices = (windowNumber - 1) * windowSamples + ...
                    (1:windowSamples);

                XWindow = X(sampleIndices, :);
                XWindow = normalizeColumns(detrend(XWindow, 'linear'));

                features = extractWindowFeatures( ...
                    XWindow, fs, gcOrders(scaleIndex), ...
                    entropyM, entropyRRatio, fuzzyExponent, ...
                    permutationOrder, permutationTau, ...
                    maxEntropyTemplates);

                rowIndex = (subjectIndex - 1) * ...
                    maxWindowsPerScale + localIndex;

                featureSets{scaleIndex}(rowIndex, :) = features;
                labelSets{scaleIndex}(rowIndex) = ySubject(subjectIndex);
                subjectSets{scaleIndex}(rowIndex) = subjectIndex;
                windowSets{scaleIndex}(rowIndex) = windowNumber;
            end
        end

        fprintf('特征提取：受试者 %3d/%3d，耗时 %.1f 秒\n', ...
            subjectIndex, nSubjects, toc(subjectTimer));
    end

    save(featureFile, ...
        'featureSets', 'labelSets', 'subjectSets', 'windowSets', ...
        'featureNames', 'featureTypes', 'ySubject', ...
        'windowSecs', 'gcOrders', 'fs', 'useSec', ...
        'maxWindowsPerScale', 'maxEntropyTemplates', ...
        'entropyM', 'entropyRRatio', 'fuzzyExponent', ...
        'permutationOrder', 'permutationTau', '-v7.3');

    fprintf('窗口特征已保存：\n%s\n', featureFile);
end


%% =========================================================
%% PLV与Granger连接矩阵可视化
%% 该模块只读取已生成的窗口特征，不修改分类输入和LOPO过程。
%% =========================================================
visualizationDir = fullfile(outDir, ...
    'Connectivity_Visualization');

if ~exist(visualizationDir,'dir')
    mkdir(visualizationDir);
end

saveConnectivityVisualizations( ...
    featureSets,windowSecs,nChannels, ...
    compose("Ch%02d",(1:nChannels)),visualizationDir);

fprintf('PLV/Granger可视化图已保存：%s\n', ...
    visualizationDir);

%% 六分类器 × 三时间尺度 LOPO
nScales = numel(windowSecs);
nClassifiers = numel(classifierCodes);
nExperiments = nScales * nClassifiers;
results = cell(nExperiments, 1);
metricsMatrix = zeros(nExperiments, 18);

predictionTable = table((1:nSubjects)', ySubject, ...
    'VariableNames', {'Subject','TrueLabel'});

experimentIndex = 0;
fprintf('\n开始六分类器LOPO……\n');

for scaleIndex = 1:nScales
    XAll = featureSets{scaleIndex};
    yAll = labelSets{scaleIndex};
    subjectAll = subjectSets{scaleIndex};

    for classifierIndex = 1:nClassifiers
        experimentIndex = experimentIndex + 1;
        classifierCode = classifierCodes{classifierIndex};

        fprintf('\n[%d/%d] %d秒 + %s\n', ...
            experimentIndex, nExperiments, ...
            windowSecs(scaleIndex), classifierCode);

        result = runLOPO( ...
            XAll, yAll, subjectAll, ySubject, ...
            classifierCode, selectedFeatureCount, numberOfTrees);

        result.ScaleSec = windowSecs(scaleIndex);
        result.Classifier = classifierCode;
        result.ClassifierDescription = ...
            classifierDescriptions{classifierIndex};
        results{experimentIndex} = result;

        sm = result.SubjectMetrics;
        wm = result.WindowMetrics;

        metricsMatrix(experimentIndex, :) = [ ...
            windowSecs(scaleIndex), classifierIndex, ...
            size(XAll, 2), result.SelectedFeatureCount, ...
            sm.Accuracy, sm.Sensitivity, sm.Specificity, ...
            sm.Precision, sm.F1, sm.BalancedAccuracy, ...
            sm.MCC, sm.AUC, ...
            wm.Accuracy, wm.Sensitivity, wm.Specificity, ...
            wm.F1, wm.BalancedAccuracy, wm.AUC];

        suffix = sprintf('S%d_%s', ...
            windowSecs(scaleIndex), classifierCode);
        predictionTable.(['Pred_' suffix]) = ...
            result.SubjectPredictedLabel;
        predictionTable.(['Score_' suffix]) = ...
            result.SubjectPatientScore;

        fprintf('受试者级 Acc=%.4f，BalAcc=%.4f，MCC=%.4f，AUC=%.4f\n', ...
            sm.Accuracy, sm.BalancedAccuracy, sm.MCC, sm.AUC);
    end
end

%% 指标、排名与最佳实验
metricsTable = array2table(metricsMatrix, ...
    'VariableNames', { ...
    'ScaleSec','ClassifierIndex','OriginalFeatureCount', ...
    'SelectedFeatureCount', ...
    'SubjectAccuracy','SubjectSensitivity','SubjectSpecificity', ...
    'SubjectPrecision','SubjectF1','SubjectBalancedAccuracy', ...
    'SubjectMCC','SubjectAUC', ...
    'WindowAccuracy','WindowSensitivity','WindowSpecificity', ...
    'WindowF1','WindowBalancedAccuracy','WindowAUC'});

classifierColumn = reshape( ...
    classifierCodes(metricsTable.ClassifierIndex), [], 1);
classifierDescriptionColumn = reshape( ...
    classifierDescriptions(metricsTable.ClassifierIndex), [], 1);

metricsTable = addvars(metricsTable, ...
    classifierColumn, classifierDescriptionColumn, ...
    'After', 'ClassifierIndex', ...
    'NewVariableNames', {'Classifier','ClassifierDescription'});

rankingKey = [ ...
    -metricsTable.SubjectBalancedAccuracy, ...
    -metricsTable.SubjectAUC, ...
    -metricsTable.SubjectMCC, ...
    -metricsTable.SubjectAccuracy];
[~, rankingOrder] = sortrows(rankingKey, 1:4);

rankingTable = metricsTable(rankingOrder, :);
rankingTable = addvars(rankingTable, (1:nExperiments)', ...
    'Before', 1, 'NewVariableNames', 'Rank');

bestExperimentIndex = rankingOrder(1);
bestResult = results{bestExperimentIndex};
bestMetrics = bestResult.SubjectMetrics;

%% 保存结果
writetable(metricsTable, ...
    fullfile(outDir, 'G01_18experiment_metrics_V4.xlsx'));
writetable(rankingTable, ...
    fullfile(outDir, 'G01_18experiment_ranking_V4.xlsx'));
writetable(predictionTable, ...
    fullfile(outDir, 'G01_subject_predictions_V4.xlsx'));

save(fullfile(outDir, 'G01_EPG_LOPO_results_V4.mat'), ...
    'results', 'metricsTable', 'rankingTable', ...
    'predictionTable', 'bestExperimentIndex', 'bestResult', ...
    'featureNames', 'featureTypes', 'classifierCodes', ...
    'classifierDescriptions', 'windowSecs', ...
    'selectedFeatureCount', 'numberOfTrees', 'ySubject', '-v7.3');

bestName = sprintf('%ds_%s', ...
    bestResult.ScaleSec, bestResult.Classifier);

plotConfusionMatrix( ...
    bestMetrics.ConfusionMatrix, bestName, ...
    fullfile(outDir, 'G01_BEST_confusion_V4.png'));

plotROC( ...
    ySubject, bestResult.SubjectPatientScore, ...
    bestMetrics.AUC, bestName, ...
    fullfile(outDir, 'G01_BEST_ROC_V4.png'));

writeSummary( ...
    fullfile(outDir, 'G01_summary_V4.txt'), ...
    rankingTable, bestResult, featureFile, ...
    useSec, maxWindowsPerScale);

fprintf('\n==================================================\n');
fprintf('最佳实验：%d秒 + %s\n', ...
    bestResult.ScaleSec, bestResult.Classifier);
fprintf('Accuracy            = %.4f\n', bestMetrics.Accuracy);
fprintf('Sensitivity         = %.4f\n', bestMetrics.Sensitivity);
fprintf('Specificity         = %.4f\n', bestMetrics.Specificity);
fprintf('Precision           = %.4f\n', bestMetrics.Precision);
fprintf('F1                  = %.4f\n', bestMetrics.F1);
fprintf('Balanced Accuracy   = %.4f\n', bestMetrics.BalancedAccuracy);
fprintf('MCC                 = %.4f\n', bestMetrics.MCC);
fprintf('AUC                 = %.4f\n', bestMetrics.AUC);
fprintf('==================================================\n');

fprintf('\n全部结果保存到：\n%s\n', outDir);
fprintf('总耗时：%.1f分钟\n', toc(totalTimer) / 60);
fprintf('结束时间：%s\n', datestr(now));
end

%% ====================== 数据读取与预处理 ======================
function X = readSubjectFirstSeconds( ...
    data, subjectIndex, nChannels, useSamples, fs)

lengths = zeros(1, nChannels);
for channelIndex = 1:nChannels
    lengths(channelIndex) = ...
        numel(data{subjectIndex, channelIndex});
end

minimumLength = min(lengths);
if minimumLength < useSamples
    error('第%d名受试者只有%.2f秒，不足%d秒。', ...
        subjectIndex, minimumLength / fs, useSamples / fs);
end

X = zeros(useSamples, nChannels);
for channelIndex = 1:nChannels
    signal = double(data{subjectIndex, channelIndex}(:));
    X(:, channelIndex) = signal(1:useSamples);
end
end

function X = preprocessEEG(X, bFilter, aFilter)
X = detrend(double(X), 'linear');
X = filtfilt(bFilter, aFilter, X);

for channelIndex = 1:size(X, 2)
    signal = X(:, channelIndex);
    center = median(signal);
    robustScale = 1.4826 * median(abs(signal - center));
    if robustScale < eps
        robustScale = std(signal);
    end
    if robustScale < eps
        robustScale = 1;
    end

    lowerLimit = center - 8 * robustScale;
    upperLimit = center + 8 * robustScale;
    signal = min(max(signal, lowerLimit), upperLimit);
    X(:, channelIndex) = signal;
end

X = normalizeColumns(X);
end

function X = normalizeColumns(X)
columnMean = mean(X, 1);
columnStd = std(X, 0, 1);
columnStd(columnStd < 1e-12) = 1;
X = (X - columnMean) ./ columnStd;
end

function selected = selectUniformWindows(totalWindows, maximumWindows)
if totalWindows <= maximumWindows
    selected = 1:totalWindows;
else
    selected = unique(round(linspace(1, totalWindows, maximumWindows)), ...
        'stable');
end
end

%% ====================== 单窗口特征提取 ======================
function features = extractWindowFeatures( ...
    X, fs, gcOrder, entropyM, entropyRRatio, fuzzyExponent, ...
    permutationOrder, permutationTau, maxEntropyTemplates)

nChannels = size(X, 2);
entropyMatrix = zeros(nChannels, 5);

for channelIndex = 1:nChannels
    signal = X(:, channelIndex);
    signal = (signal - mean(signal)) / max(std(signal), eps);
    tolerance = entropyRRatio * std(signal);

    entropyMatrix(channelIndex, 1) = approximateEntropy( ...
        signal, entropyM, tolerance, maxEntropyTemplates);
    entropyMatrix(channelIndex, 2) = fuzzyEntropy( ...
        signal, entropyM, tolerance, fuzzyExponent, ...
        maxEntropyTemplates);
    entropyMatrix(channelIndex, 3) = sampleEntropy( ...
        signal, entropyM, tolerance, maxEntropyTemplates);
    entropyMatrix(channelIndex, 4) = permutationEntropy( ...
        signal, permutationOrder, permutationTau);
    entropyMatrix(channelIndex, 5) = spectralEntropyValue(signal, fs);
end

entropyFeatures = reshape(entropyMatrix.', 1, []);
plvFeatures = vectorizePLV(calculatePLV(X));
grangerFeatures = vectorizeGranger( ...
    pairwiseGrangerMatrix(X, gcOrder));

features = [entropyFeatures, plvFeatures, grangerFeatures];
features(~isfinite(features)) = 0;
end

%% ====================== 五种熵 ======================
function value = approximateEntropy(x, m, r, maximumTemplates)
phiM = approximatePhi(x, m, r, maximumTemplates);
phiM1 = approximatePhi(x, m + 1, r, maximumTemplates);
value = phiM - phiM1;
end

function phi = approximatePhi(x, m, r, maximumTemplates)
templates = makeTemplates(x, m);
templates = selectTemplateRows(templates, maximumTemplates);
distanceMatrix = chebyshevDistances(templates);
matchRatio = sum(distanceMatrix <= r, 2) / size(templates, 1);
phi = mean(log(max(matchRatio, eps)));
end

function value = sampleEntropy(x, m, r, maximumTemplates)
templatesM = selectTemplateRows(makeTemplates(x, m), maximumTemplates);
templatesM1 = selectTemplateRows(makeTemplates(x, m + 1), maximumTemplates);

probabilityM = pairMatchProbability(templatesM, r);
probabilityM1 = pairMatchProbability(templatesM1, r);
value = -log((probabilityM1 + eps) / (probabilityM + eps));
end

function probability = pairMatchProbability(templates, r)
n = size(templates, 1);
if n < 2
    probability = 0;
    return;
end

distanceMatrix = chebyshevDistances(templates);
upperMask = triu(true(n), 1);
probability = sum(distanceMatrix(upperMask) <= r) / ...
    (n * (n - 1) / 2);
end

function value = fuzzyEntropy( ...
    x, m, r, fuzzyExponent, maximumTemplates)

phiM = fuzzyPhi(x, m, r, fuzzyExponent, maximumTemplates);
phiM1 = fuzzyPhi(x, m + 1, r, fuzzyExponent, maximumTemplates);
value = log(phiM + eps) - log(phiM1 + eps);
end

function phi = fuzzyPhi( ...
    x, m, r, fuzzyExponent, maximumTemplates)

templates = makeTemplates(x, m);
templates = templates - mean(templates, 2);
templates = selectTemplateRows(templates, maximumTemplates);
n = size(templates, 1);

if n < 2
    phi = 0;
    return;
end

distanceMatrix = chebyshevDistances(templates);
similarity = exp(-(distanceMatrix .^ fuzzyExponent) / max(r, eps));
similarity(1:n+1:end) = 0;
phi = sum(similarity(:)) / (n * (n - 1));
end

function value = permutationEntropy(x, order, tau)
numberOfPatterns = numel(x) - (order - 1) * tau;
patterns = zeros(numberOfPatterns, order);

for rowIndex = 1:numberOfPatterns
    indices = rowIndex + (0:order-1) * tau;
    [~, patterns(rowIndex, :)] = sort(x(indices), 'ascend');
end

[~, ~, patternIndex] = unique(patterns, 'rows');
counts = accumarray(patternIndex, 1);
probabilities = counts / sum(counts);
value = -sum(probabilities .* log(probabilities + eps)) / log(factorial(order));
end

function value = spectralEntropyValue(x, fs)
[powerSpectrum, ~] = pwelch(x, [], [], [], fs);
probabilities = powerSpectrum / max(sum(powerSpectrum), eps);
value = -sum(probabilities .* log(probabilities + eps)) / ...
    log(numel(probabilities));
end

function templates = makeTemplates(x, m)
numberOfTemplates = numel(x) - m + 1;
templates = zeros(numberOfTemplates, m);
for columnIndex = 1:m
    templates(:, columnIndex) = ...
        x(columnIndex:columnIndex + numberOfTemplates - 1);
end
end

function templates = selectTemplateRows(templates, maximumTemplates)
if size(templates, 1) > maximumTemplates
    selectedRows = unique(round(linspace( ...
        1, size(templates, 1), maximumTemplates)), 'stable');
    templates = templates(selectedRows, :);
end
end

function distances = chebyshevDistances(templates)
n = size(templates, 1);
distances = zeros(n, n);
for rowIndex = 1:n
    distances(rowIndex, :) = max(abs( ...
        templates - templates(rowIndex, :)), [], 2).';
end
end

%% ====================== PLV与Granger ======================
function plvMatrix = calculatePLV(X)
phase = angle(hilbert(X));
unitPhase = exp(1i * phase);
plvMatrix = abs((unitPhase' * unitPhase) / size(unitPhase, 1));
plvMatrix = (plvMatrix + plvMatrix') / 2;
plvMatrix(1:size(plvMatrix, 1)+1:end) = 0;
end

function feature = vectorizePLV(plvMatrix)
nChannels = size(plvMatrix, 1);
feature = zeros(1, nChannels * (nChannels - 1) / 2);
writeIndex = 1;

for firstChannel = 1:nChannels-1
    for secondChannel = firstChannel+1:nChannels
        feature(writeIndex) = ...
            plvMatrix(firstChannel, secondChannel);
        writeIndex = writeIndex + 1;
    end
end
end

function grangerMatrix = pairwiseGrangerMatrix(X, order)
% grangerMatrix(source,target)：source对target的方向性预测增益。
nSamples = size(X, 1);
nChannels = size(X, 2);
grangerMatrix = zeros(nChannels, nChannels);

for targetChannel = 1:nChannels
    target = X(:, targetChannel);
    response = target(order + 1:nSamples);
    targetLags = makeLaggedPredictors(target, order);
    restrictedDesign = [ones(size(targetLags, 1), 1), targetLags];
    restrictedResidual = response - ...
        restrictedDesign * (restrictedDesign \ response);
    restrictedVariance = mean(restrictedResidual .^ 2);

    for sourceChannel = 1:nChannels
        if sourceChannel == targetChannel
            continue;
        end

        sourceLags = makeLaggedPredictors(X(:, sourceChannel), order);
        fullDesign = [restrictedDesign, sourceLags];
        fullResidual = response - fullDesign * (fullDesign \ response);
        fullVariance = mean(fullResidual .^ 2);

        score = log((restrictedVariance + eps) / (fullVariance + eps));
        grangerMatrix(sourceChannel, targetChannel) = max(score, 0);
    end
end
end

function predictors = makeLaggedPredictors(x, order)
nSamples = numel(x);
predictors = zeros(nSamples - order, order);
for lagIndex = 1:order
    predictors(:, lagIndex) = ...
        x(order + 1 - lagIndex:nSamples - lagIndex);
end
end

function feature = vectorizeGranger(grangerMatrix)
nChannels = size(grangerMatrix, 1);
feature = zeros(1, nChannels * (nChannels - 1));
writeIndex = 1;

for sourceChannel = 1:nChannels
    for targetChannel = 1:nChannels
        if sourceChannel ~= targetChannel
            feature(writeIndex) = ...
                grangerMatrix(sourceChannel, targetChannel);
            writeIndex = writeIndex + 1;
        end
    end
end
end

%% ====================== LOPO分类 ======================
function result = runLOPO( ...
    X, yWindow, subjectWindow, ySubject, ...
    classifierCode, selectedFeatureCount, numberOfTrees)

nSubjects = numel(ySubject);
nWindows = size(X, 1);

subjectPredictedLabel = zeros(nSubjects, 1);
subjectPatientScore = zeros(nSubjects, 1);
windowPredictedLabel = zeros(nWindows, 1);
windowPatientScore = zeros(nWindows, 1);
selectedFeatureIndex = cell(nSubjects, 1);

for heldOutSubject = 1:nSubjects
    trainMask = subjectWindow ~= heldOutSubject;
    testMask = subjectWindow == heldOutSubject;

    XTrain = X(trainMask, :);
    yTrain = yWindow(trainMask);
    XTest = X(testMask, :);

    featureMedian = finiteColumnMedian(XTrain);
    XTrain = replaceNonfinite(XTrain, featureMedian);
    XTest = replaceNonfinite(XTest, featureMedian);

    trainingMean = mean(XTrain, 1);
    trainingStd = std(XTrain, 0, 1);
    trainingStd(trainingStd < 1e-12) = 1;

    XTrain = (XTrain - trainingMean) ./ trainingStd;
    XTest = (XTest - trainingMean) ./ trainingStd;

    fisherScore = calculateFisherScore(XTrain, yTrain);
    [~, rankedFeatures] = sort(fisherScore, 'descend');
    selectedCount = min(selectedFeatureCount, size(XTrain, 2));
    selected = rankedFeatures(1:selectedCount);
    selectedFeatureIndex{heldOutSubject} = selected;

    model = trainClassifier( ...
        XTrain(:, selected), yTrain, ...
        classifierCode, numberOfTrees);

    [predictedLabel, patientScore, decisionThreshold] = ...
        predictClassifier(model, XTest(:, selected), classifierCode);

    windowPredictedLabel(testMask) = predictedLabel;
    windowPatientScore(testMask) = patientScore;

    meanScore = mean(patientScore);
    subjectPatientScore(heldOutSubject) = meanScore;
    subjectPredictedLabel(heldOutSubject) = ...
        double(meanScore >= decisionThreshold);

    fprintf('  留出受试者 %3d/%3d，真实=%d，预测=%d，分数=%.4f\n', ...
        heldOutSubject, nSubjects, ySubject(heldOutSubject), ...
        subjectPredictedLabel(heldOutSubject), meanScore);
end

result = struct();
result.SubjectPredictedLabel = subjectPredictedLabel;
result.SubjectPatientScore = subjectPatientScore;
result.WindowPredictedLabel = windowPredictedLabel;
result.WindowPatientScore = windowPatientScore;
result.SelectedFeatureIndex = selectedFeatureIndex;
result.SelectedFeatureCount = ...
    min(selectedFeatureCount, size(X, 2));
result.SubjectMetrics = calculateMetrics( ...
    ySubject, subjectPredictedLabel, subjectPatientScore);
result.WindowMetrics = calculateMetrics( ...
    yWindow, windowPredictedLabel, windowPatientScore);
end

function score = calculateFisherScore(X, y)
class0 = X(y == 0, :);
class1 = X(y == 1, :);

mean0 = mean(class0, 1);
mean1 = mean(class1, 1);
variance0 = var(class0, 0, 1);
variance1 = var(class1, 0, 1);

score = (mean1 - mean0) .^ 2 ./ ...
    (variance0 + variance1 + eps);
score(~isfinite(score)) = 0;
end

function model = trainClassifier(X, y, classifierCode, numberOfTrees)
switch classifierCode
    case 'LinearSVM'
        model = fitcsvm(X, y, ...
            'KernelFunction', 'linear', ...
            'BoxConstraint', 1, ...
            'ClassNames', [0; 1]);

    case 'RBFSVM'
        model = fitcsvm(X, y, ...
            'KernelFunction', 'rbf', ...
            'KernelScale', 'auto', ...
            'BoxConstraint', 1, ...
            'ClassNames', [0; 1]);

    case 'Logistic'
        model = fitclinear(X, y, ...
            'Learner', 'logistic', ...
            'Regularization', 'ridge', ...
            'Lambda', 1e-3, ...
            'ClassNames', [0; 1]);

    case 'LDA'
        model = fitcdiscr(X, y, ...
            'DiscrimType', 'linear', ...
            'Gamma', 0.1, ...
            'ClassNames', [0; 1]);

    case 'KNN'
        % 不使用 fitcknn，避免部分 MATLAB 版本中
        % ClassificationKNN/predict 调用 gather 时发生兼容性错误。
        model = struct();
        model.Type = 'ManualKNN';
        model.XTrain = X;
        model.YTrain = double(y(:));
        model.NumNeighbors = min(5, size(X, 1));

    case 'RF'
        % 不使用 TreeBagger/fitctree，避免其内部 growTree 调用
        % 冲突的 gather 函数。这里使用程序内置 CART 随机森林。
        model = trainManualRandomForest(X, y, numberOfTrees);
end
end

function [label, patientScore, threshold] = ...
    predictClassifier(model, X, classifierCode)

if strcmp(classifierCode, 'RF')
    [label, patientScore] = predictManualRandomForest(model, X);
    threshold = 0.5;
    return;
end

if strcmp(classifierCode, 'KNN')
    [label, patientScore] = predictManualKNN(model, X);
    threshold = 0.5;
    return;
end

[label, score] = predict(model, X);
classNames = model.ClassNames;
positiveColumn = find(classNames == 1, 1);
patientScore = score(:, positiveColumn);

if any(strcmp(classifierCode, {'LinearSVM','RBFSVM'}))
    threshold = 0;
else
    threshold = 0.5;
end
end


function [label, patientScore] = predictManualKNN(model, XTest)
% 欧氏距离 + squared-inverse 权重，与原 fitcknn 设置一致。
nTest = size(XTest, 1);
patientScore = zeros(nTest, 1);
k = model.NumNeighbors;

for testIndex = 1:nTest
    difference = bsxfun(@minus, model.XTrain, XTest(testIndex, :));
    squaredDistance = sum(difference .^ 2, 2);
    [sortedDistance, order] = sort(squaredDistance, 'ascend');

    neighborIndex = order(1:k);
    neighborDistance = sortedDistance(1:k);
    neighborLabel = model.YTrain(neighborIndex);

    zeroDistance = neighborDistance <= eps;
    if any(zeroDistance)
        patientScore(testIndex) = mean(neighborLabel(zeroDistance));
    else
        weight = 1 ./ neighborDistance;
        patientScore(testIndex) = ...
            sum(weight .* neighborLabel) / sum(weight);
    end
end

label = double(patientScore >= 0.5);
end


function model = trainManualRandomForest(X, y, numberOfTrees)
% 纯MATLAB二分类随机森林，不调用 TreeBagger、fitctree 或 gather。
y = double(y(:));
[nSamples, nFeatures] = size(X);

model = struct();
model.Type = 'ManualRF';
model.NumTrees = numberOfTrees;
model.Trees = cell(numberOfTrees, 1);
model.MinLeafSize = 5;
model.MaxDepth = 10;
model.NumPredictorsToSample = max(1, floor(sqrt(nFeatures)));
model.MaxSplitCandidates = 16;

for treeIndex = 1:numberOfTrees
    bootstrapIndex = randi(nSamples, nSamples, 1);
    model.Trees{treeIndex} = growManualTree( ...
        X(bootstrapIndex, :), y(bootstrapIndex), 0, ...
        model.MinLeafSize, model.MaxDepth, ...
        model.NumPredictorsToSample, model.MaxSplitCandidates);
end
end

function node = growManualTree( ...
    X, y, depth, minLeafSize, maxDepth, ...
    predictorsPerSplit, maxSplitCandidates)

node = struct( ...
    'IsLeaf', true, ...
    'Probability', mean(y), ...
    'Feature', 0, ...
    'Threshold', 0, ...
    'Left', [], ...
    'Right', []);

nSamples = size(X, 1);
if depth >= maxDepth || ...
        nSamples < 2 * minLeafSize || ...
        all(y == y(1))
    return;
end

nFeatures = size(X, 2);
featureOrder = randperm(nFeatures, min(predictorsPerSplit, nFeatures));
bestGini = inf;
bestFeature = 0;
bestThreshold = 0;

for featureIndex = featureOrder
    values = X(:, featureIndex);
    [sortedValues, order] = sort(values, 'ascend');
    sortedLabels = y(order);

    splitPositions = (1:nSamples-1)';
    validMask = ...
        sortedValues(1:end-1) < sortedValues(2:end) & ...
        splitPositions >= minLeafSize & ...
        (nSamples - splitPositions) >= minLeafSize;
    validPosition = splitPositions(validMask);

    if isempty(validPosition)
        continue;
    end

    if numel(validPosition) > maxSplitCandidates
        selectedPosition = round(linspace( ...
            1, numel(validPosition), maxSplitCandidates));
        validPosition = validPosition(selectedPosition);
    end

    cumulativePositive = cumsum(sortedLabels == 1);
    totalPositive = cumulativePositive(end);

    leftCount = validPosition;
    rightCount = nSamples - validPosition;
    leftPositive = cumulativePositive(validPosition);
    rightPositive = totalPositive - leftPositive;

    leftNegative = leftCount - leftPositive;
    rightNegative = rightCount - rightPositive;

    leftGini = 1 - ...
        (leftPositive ./ leftCount) .^ 2 - ...
        (leftNegative ./ leftCount) .^ 2;
    rightGini = 1 - ...
        (rightPositive ./ rightCount) .^ 2 - ...
        (rightNegative ./ rightCount) .^ 2;

    weightedGini = ...
        (leftCount .* leftGini + rightCount .* rightGini) ./ nSamples;
    [featureBestGini, localIndex] = min(weightedGini);

    if featureBestGini < bestGini
        splitPosition = validPosition(localIndex);
        bestGini = featureBestGini;
        bestFeature = featureIndex;
        bestThreshold = ...
            (sortedValues(splitPosition) + ...
             sortedValues(splitPosition + 1)) / 2;
    end
end

if bestFeature == 0
    return;
end

leftMask = X(:, bestFeature) <= bestThreshold;
rightMask = ~leftMask;
if sum(leftMask) < minLeafSize || sum(rightMask) < minLeafSize
    return;
end

node.IsLeaf = false;
node.Feature = bestFeature;
node.Threshold = bestThreshold;
node.Left = growManualTree( ...
    X(leftMask, :), y(leftMask), depth + 1, ...
    minLeafSize, maxDepth, predictorsPerSplit, maxSplitCandidates);
node.Right = growManualTree( ...
    X(rightMask, :), y(rightMask), depth + 1, ...
    minLeafSize, maxDepth, predictorsPerSplit, maxSplitCandidates);
end

function [label, patientScore] = predictManualRandomForest(model, X)
nSamples = size(X, 1);
patientScore = zeros(nSamples, 1);

for treeIndex = 1:model.NumTrees
    tree = model.Trees{treeIndex};
    for sampleIndex = 1:nSamples
        patientScore(sampleIndex) = patientScore(sampleIndex) + ...
            predictManualTree(tree, X(sampleIndex, :));
    end
end

patientScore = patientScore / model.NumTrees;
label = double(patientScore >= 0.5);
end

function probability = predictManualTree(node, sample)
while ~node.IsLeaf
    if sample(node.Feature) <= node.Threshold
        node = node.Left;
    else
        node = node.Right;
    end
end
probability = node.Probability;
end

function medianValues = finiteColumnMedian(X)
medianValues = zeros(1, size(X, 2));
for columnIndex = 1:size(X, 2)
    values = X(isfinite(X(:, columnIndex)), columnIndex);
    if isempty(values)
        medianValues(columnIndex) = 0;
    else
        medianValues(columnIndex) = median(values);
    end
end
end

function X = replaceNonfinite(X, replacement)
for columnIndex = 1:size(X, 2)
    invalid = ~isfinite(X(:, columnIndex));
    X(invalid, columnIndex) = replacement(columnIndex);
end
end

%% ====================== 指标与输出 ======================
function metrics = calculateMetrics(trueLabel, predictedLabel, score)
trueLabel = double(trueLabel(:));
predictedLabel = double(predictedLabel(:));
score = double(score(:));

TN = sum(trueLabel == 0 & predictedLabel == 0);
FP = sum(trueLabel == 0 & predictedLabel == 1);
FN = sum(trueLabel == 1 & predictedLabel == 0);
TP = sum(trueLabel == 1 & predictedLabel == 1);

accuracy = (TP + TN) / max(TP + TN + FP + FN, 1);
sensitivity = TP / max(TP + FN, 1);
specificity = TN / max(TN + FP, 1);
precision = TP / max(TP + FP, 1);
f1 = 2 * precision * sensitivity / max(precision + sensitivity, eps);
balancedAccuracy = (sensitivity + specificity) / 2;

mccDenominator = sqrt( ...
    max((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN), eps));
mcc = (TP * TN - FP * FN) / mccDenominator;
auc = calculateAUC(trueLabel, score);

metrics = struct();
metrics.Accuracy = accuracy;
metrics.Sensitivity = sensitivity;
metrics.Specificity = specificity;
metrics.Precision = precision;
metrics.F1 = f1;
metrics.BalancedAccuracy = balancedAccuracy;
metrics.MCC = mcc;
metrics.AUC = auc;
metrics.ConfusionMatrix = [TN FP; FN TP];
end

function auc = calculateAUC(y, score)
positiveScores = score(y == 1);
negativeScores = score(y == 0);

comparison = positiveScores(:) > negativeScores(:).';
ties = positiveScores(:) == negativeScores(:).';
auc = (sum(comparison(:)) + 0.5 * sum(ties(:))) / ...
    max(numel(positiveScores) * numel(negativeScores), 1);
end

function plotConfusionMatrix(confusionMatrix, experimentName, outputFile)
figure('Visible', 'off');
imagesc(confusionMatrix);
axis equal tight;
colorbar;
xlabel('预测标签');
ylabel('真实标签');
title(['最佳实验混淆矩阵：' experimentName], 'Interpreter', 'none');
set(gca, 'XTick', [1 2], 'XTickLabel', {'0','1'}, ...
    'YTick', [1 2], 'YTickLabel', {'0','1'});

for rowIndex = 1:2
    for columnIndex = 1:2
        text(columnIndex, rowIndex, ...
            num2str(confusionMatrix(rowIndex, columnIndex)), ...
            'HorizontalAlignment', 'center', ...
            'FontWeight', 'bold');
    end
end

saveas(gcf, outputFile);
close(gcf);
end

function plotROC(y, score, auc, experimentName, outputFile)
[sortedScore, order] = sort(score, 'descend'); %#ok<ASGLU>
sortedLabel = y(order);
positiveCount = sum(y == 1);
negativeCount = sum(y == 0);

tpr = [0; cumsum(sortedLabel == 1) / max(positiveCount, 1); 1];
fpr = [0; cumsum(sortedLabel == 0) / max(negativeCount, 1); 1];

figure('Visible', 'off');
plot(fpr, tpr, 'LineWidth', 2);
hold on;
plot([0 1], [0 1], '--');
xlim([0 1]);
ylim([0 1]);
grid on;
xlabel('False Positive Rate');
ylabel('True Positive Rate');
title(sprintf('ROC：%s，AUC=%.4f', experimentName, auc), ...
    'Interpreter', 'none');
saveas(gcf, outputFile);
close(gcf);
end

function writeSummary( ...
    outputFile, rankingTable, bestResult, featureFile, ...
    useSec, maximumWindows)

fileID = fopen(outputFile, 'w');
cleanupFile = onCleanup(@() fclose(fileID)); %#ok<NASGU>

metrics = bestResult.SubjectMetrics;
fprintf(fileID, 'G数据集：五种熵 + PLV + Granger，六分类器LOPO\n\n');
fprintf(fileID, '每名受试者使用前%d秒。\n', useSec);
fprintf(fileID, '每尺度均匀选取最多%d个非重叠窗口。\n', maximumWindows);
fprintf(fileID, '每窗口343维：熵70 + PLV91 + Granger182。\n');
fprintf(fileID, '标准化与Fisher筛选仅使用每轮训练受试者。\n');
fprintf(fileID, '特征缓存：%s\n\n', featureFile);

fprintf(fileID, '最佳实验：%d秒 + %s\n', ...
    bestResult.ScaleSec, bestResult.Classifier);
fprintf(fileID, 'Accuracy          = %.6f\n', metrics.Accuracy);
fprintf(fileID, 'Sensitivity       = %.6f\n', metrics.Sensitivity);
fprintf(fileID, 'Specificity       = %.6f\n', metrics.Specificity);
fprintf(fileID, 'Precision         = %.6f\n', metrics.Precision);
fprintf(fileID, 'F1                = %.6f\n', metrics.F1);
fprintf(fileID, 'BalancedAccuracy  = %.6f\n', metrics.BalancedAccuracy);
fprintf(fileID, 'MCC               = %.6f\n', metrics.MCC);
fprintf(fileID, 'AUC               = %.6f\n\n', metrics.AUC);

fprintf(fileID, '前10名实验：\n');
for rowIndex = 1:min(10, height(rankingTable))
    fprintf(fileID, ...
        '%2d. %d秒 + %s，BalAcc=%.4f，AUC=%.4f，MCC=%.4f，Acc=%.4f\n', ...
        rowIndex, rankingTable.ScaleSec(rowIndex), ...
        rankingTable.Classifier{rowIndex}, ...
        rankingTable.SubjectBalancedAccuracy(rowIndex), ...
        rankingTable.SubjectAUC(rowIndex), ...
        rankingTable.SubjectMCC(rowIndex), ...
        rankingTable.SubjectAccuracy(rowIndex));
end
end

%% ====================== 特征名称 ======================
function [names, types] = makeFeatureNames(nChannels)
entropyNames = {'AE','FE','SE','PE','SpecEn'};
names = cell(343, 1);
types = cell(343, 1);
writeIndex = 1;

for channelIndex = 1:nChannels
    for entropyIndex = 1:numel(entropyNames)
        names{writeIndex} = sprintf('Ch%02d_%s', ...
            channelIndex, entropyNames{entropyIndex});
        types{writeIndex} = 'Entropy';
        writeIndex = writeIndex + 1;
    end
end

for firstChannel = 1:nChannels-1
    for secondChannel = firstChannel+1:nChannels
        names{writeIndex} = sprintf('PLV_Ch%02d_Ch%02d', ...
            firstChannel, secondChannel);
        types{writeIndex} = 'PLV';
        writeIndex = writeIndex + 1;
    end
end

for sourceChannel = 1:nChannels
    for targetChannel = 1:nChannels
        if sourceChannel ~= targetChannel
            names{writeIndex} = sprintf('GC_Ch%02d_to_Ch%02d', ...
                sourceChannel, targetChannel);
            types{writeIndex} = 'Granger';
            writeIndex = writeIndex + 1;
        end
    end
end
end

%% =========================================================
%% PLV与Granger可视化辅助函数
%% =========================================================
function saveConnectivityVisualizations( ...
    featureSets,windowSecs,nChannels, ...
    channelNames,outputDir)
% 从实际进入分类流程的窗口特征中恢复代表性PLV和Granger矩阵。
% 该函数只负责绘图，不修改featureSets，也不参与分类器训练。
%
% 每个尺度使用featureSets中的第一行作为代表性窗口。
% 分类器仍使用原来的：
% [五种熵向量, PLV上三角向量, Granger非对角向量]。

channelNames = cellstr(string(channelNames(:)));

if numel(channelNames)~=nChannels
    channelNames = cellstr(compose( ...
        "Ch%02d",(1:nChannels)'));
end

entropyCount = nChannels*5;
plvCount = nChannels*(nChannels-1)/2;
grangerCount = nChannels*(nChannels-1);

requiredFeatureCount = ...
    entropyCount+plvCount+grangerCount;

for scaleIndex = 1:numel(windowSecs)
    if isempty(featureSets{scaleIndex})
        warning('%d秒尺度特征为空，跳过可视化。', ...
            windowSecs(scaleIndex));
        continue;
    end

    representativeFeature = ...
        double(featureSets{scaleIndex}(1,:));

    if numel(representativeFeature)< ...
            requiredFeatureCount
        warning(['%d秒尺度特征只有%d维，低于恢复矩阵所需%d维，' ...
            '跳过可视化。'], ...
            windowSecs(scaleIndex), ...
            numel(representativeFeature), ...
            requiredFeatureCount);
        continue;
    end

    plvStart = entropyCount+1;
    plvEnd = entropyCount+plvCount;

    grangerStart = plvEnd+1;
    grangerEnd = ...
        grangerStart+grangerCount-1;

    plvVector = representativeFeature( ...
        plvStart:plvEnd);

    grangerVector = representativeFeature( ...
        grangerStart:grangerEnd);

    plvMatrix = restorePLVMatrix( ...
        plvVector,nChannels);

    grangerMatrix = restoreGrangerMatrix( ...
        grangerVector,nChannels);

    saveConnectivityFigureSet( ...
        plvMatrix,grangerMatrix, ...
        channelNames,outputDir, ...
        windowSecs(scaleIndex));
end
end

function matrix = restorePLVMatrix( ...
    vector,nChannels)
% 按原vectorizePLV顺序恢复对称PLV矩阵。

matrix = zeros(nChannels,nChannels);
readIndex = 1;

for firstChannel = 1:nChannels-1
    for secondChannel = ...
            firstChannel+1:nChannels

        value = vector(readIndex);

        matrix(firstChannel,secondChannel) = ...
            value;

        matrix(secondChannel,firstChannel) = ...
            value;

        readIndex = readIndex+1;
    end
end

matrix(1:nChannels+1:end) = 0;
end

function matrix = restoreGrangerMatrix( ...
    vector,nChannels)
% 按原vectorizeGranger顺序恢复有向矩阵：
% 行=源通道，列=目标通道。

matrix = zeros(nChannels,nChannels);
readIndex = 1;

for sourceChannel = 1:nChannels
    for targetChannel = 1:nChannels
        if sourceChannel~=targetChannel
            matrix(sourceChannel,targetChannel) = ...
                vector(readIndex);

            readIndex = readIndex+1;
        end
    end
end

matrix(1:nChannels+1:end) = 0;
end

function saveConnectivityFigureSet( ...
    plvMatrix,grangerMatrix, ...
    channelNames,outputDir,windowSec)
% 自动输出：
%   PLV_Matrix_1s/2s/5s.png
%   Granger_Matrix_1s/2s/5s.png
%   PLV_Granger_FusedMatrix_1s/2s/5s.png
%
% 前两张图显示原始数值。
% 融合图为了同时看清两类量纲不同的连接，
% 分别对PLV和Granger进行0-1显示归一化；
% 此归一化只用于绘图，不参与分类。

nChannels = size(plvMatrix,1);
scaleText = sprintf('%ds',windowSec);

plvFile = fullfile(outputDir, ...
    sprintf('PLV_Matrix_%s.png',scaleText));

grangerFile = fullfile(outputDir, ...
    sprintf('Granger_Matrix_%s.png',scaleText));

fusedFile = fullfile(outputDir, ...
    sprintf(['PLV_Granger_FusedMatrix_' ...
    '%s.png'],scaleText));

saveSingleConnectivityHeatmap( ...
    plvMatrix,channelNames, ...
    sprintf('PLV Matrix (%s)',scaleText), ...
    'Channel','Channel',plvFile);

saveSingleConnectivityHeatmap( ...
    grangerMatrix,channelNames, ...
    sprintf('Directed Granger Matrix (%s)', ...
    scaleText), ...
    'Target Channel','Source Channel', ...
    grangerFile);

plvDisplay = normalizeOffDiagonalForDisplay( ...
    plvMatrix);

grangerDisplay = ...
    normalizeOffDiagonalForDisplay( ...
    grangerMatrix);

separator = nan(nChannels,1);

% 水平拼接展示，完整保留Granger的两个方向。
fusedDisplay = [ ...
    plvDisplay,separator,grangerDisplay];

figureHandle = figure( ...
    'Visible','off','Color','w', ...
    'Position',[100 100 1500 760]);

imageHandle = imagesc(fusedDisplay);

set(imageHandle,'AlphaData', ...
    ~isnan(fusedDisplay));

set(gca,'Color',[0.92 0.92 0.92]);

axis image;
colorbar;
caxis([0 1]);

title({ ...
    sprintf('PLV and Granger Matrix Concatenation (%s)', ...
    scaleText), ...
    ['Left: PLV matrix    Right: directed Granger matrix ' ...
    '(normalized separately for visualization only)']}, ...
    'Interpreter','none');

xlabel('Matrix Columns');
ylabel('Source / Row Channel');

xTick = [ ...
    1:nChannels, ...
    nChannels+2:2*nChannels+1];

xLabel = [ ...
    string(channelNames(:)); ...
    string(channelNames(:))];

set(gca, ...
    'XTick',xTick, ...
    'XTickLabel',cellstr(xLabel), ...
    'YTick',1:nChannels, ...
    'YTickLabel',channelNames, ...
    'TickLabelInterpreter','none', ...
    'FontSize',9);

xtickangle(45);

hold on;
plot([nChannels+1 nChannels+1], ...
    [0.5 nChannels+0.5], ...
    'k-','LineWidth',2);
hold off;

saveFigurePNG(figureHandle,fusedFile);
close(figureHandle);
end

function saveSingleConnectivityHeatmap( ...
    matrix,channelNames,titleText, ...
    xLabelText,yLabelText,filePath)

nChannels = size(matrix,1);

figureHandle = figure( ...
    'Visible','off','Color','w', ...
    'Position',[100 100 900 760]);

imagesc(matrix);
axis image;
colorbar;

title(titleText,'Interpreter','none');
xlabel(xLabelText);
ylabel(yLabelText);

set(gca, ...
    'XTick',1:nChannels, ...
    'YTick',1:nChannels, ...
    'XTickLabel',channelNames, ...
    'YTickLabel',channelNames, ...
    'TickLabelInterpreter','none', ...
    'FontSize',9);

xtickangle(45);

saveFigurePNG(figureHandle,filePath);
close(figureHandle);
end

function normalized = ...
    normalizeOffDiagonalForDisplay(matrix)

matrix = double(matrix);
n = size(matrix,1);
mask = ~eye(n);

values = matrix(mask);
values = values(isfinite(values));

normalized = zeros(size(matrix));

if isempty(values)
    normalized(:) = 0;
else
    minimumValue = min(values);
    maximumValue = max(values);

    if maximumValue-minimumValue<eps
        normalized(mask) = 0;
    else
        normalized(mask) = ...
            (matrix(mask)-minimumValue)/ ...
            (maximumValue-minimumValue);
    end
end

normalized(1:n+1:end) = 0;
normalized(~isfinite(normalized)) = 0;
end

function saveFigurePNG(figureHandle,filePath)
% 使用print兼容较旧MATLAB版本。

set(figureHandle, ...
    'PaperPositionMode','auto');

print(figureHandle,filePath, ...
    '-dpng','-r300');
end
