function G01_5s_Ablation_RBFSVM_V1
% SAHARAN12-G01：5秒窗口特征消融（论文主实验）
% 固定使用当前5秒基线最佳分类器 RBF-SVM。
% 直接复用 G01_window_features_V1.mat，不重新提取EEG特征。
%
% 共10组：
% 1 Baseline
% 2 NoEntropy   3 NoPLV   4 NoGranger
% 5 NoApEn      6 NoFuzzyEn  7 NoSampEn  8 NoPermEn  9 NoSpecEn
% 10 NoFisher

clc;
close all;

rootDir = 'D:\Database\Seizure\SAHARAN\SAHARAN12\G01';
featureFile = fullfile(rootDir, 'G01_window_features_V1.mat');
labelFile = 'D:\Database\Seizure\SAHARAN\G_dataLable.mat';
outDir = fullfile(rootDir, '消融实验');

if ~exist(outDir, 'dir')
    mkdir(outDir);
end

logFile = fullfile(outDir, 'G01_5s_Ablation_RBFSVM_log_V1.txt');
if exist(logFile, 'file')
    delete(logFile);
end
diary(logFile);
cleanupDiary = onCleanup(@() diary('off')); %#ok<NASGU>

totalTimer = tic;
fprintf('SAHARAN12-G01 5秒 RBF-SVM 消融实验\n');
fprintf('开始时间：%s\n', datestr(now));

%% 读取已有5秒特征
F = load(featureFile, 'featureSets', 'labelSets', 'subjectSets', 'windowSecs');
L = load(labelFile, 'dataLable');
ySubject = double(L.dataLable(:));

scaleIndex = find(F.windowSecs == 5, 1);
XAll = double(F.featureSets{scaleIndex});
yWindow = double(F.labelSets{scaleIndex}(:));
subjectWindow = double(F.subjectSets{scaleIndex}(:));

valid = subjectWindow > 0;
XAll = XAll(valid, :);
yWindow = yWindow(valid);
subjectWindow = subjectWindow(valid);

if size(XAll, 2) ~= 343
    error('当前程序要求343维特征，实际为%d维。', size(XAll, 2));
end

fprintf('受试者：%d；5秒窗口：%d；特征：343维\n', ...
    numel(ySubject), size(XAll, 1));

%% V4特征索引：70熵 + 91 PLV + 182 Granger
allIdx = 1:343;
entropyIdx = 1:70;
plvIdx = 71:161;
grangerIdx = 162:343;

% 熵特征在每个通道内依次为：ApEn, FuzzyEn, SampEn, PermEn, SpecEn
apenIdx = 1:5:66;
fuzzyIdx = 2:5:67;
sampenIdx = 3:5:68;
permenIdx = 4:5:69;
specenIdx = 5:5:70;

%% 消融配置
code = [ ...
    "Baseline"; "NoEntropy"; "NoPLV"; "NoGranger"; ...
    "NoApEn"; "NoFuzzyEn"; "NoSampEn"; "NoPermEn"; ...
    "NoSpecEn"; "NoFisher"];

group = [ ...
    "Baseline"; "Module"; "Module"; "Module"; ...
    "EntropyLOO"; "EntropyLOO"; "EntropyLOO"; "EntropyLOO"; ...
    "EntropyLOO"; "Fisher"];

description = [ ...
    "完整特征：Entropy + PLV + Granger；Fisher Top50"; ...
    "去掉全部熵特征，仅 PLV + Granger"; ...
    "去掉 PLV，仅 Entropy + Granger"; ...
    "去掉 Granger，仅 Entropy + PLV"; ...
    "Leave-One-Out：去掉近似熵 ApEn"; ...
    "Leave-One-Out：去掉模糊熵 FuzzyEn"; ...
    "Leave-One-Out：去掉样本熵 SampEn"; ...
    "Leave-One-Out：去掉排列熵 PermEn"; ...
    "Leave-One-Out：去掉谱熵 SpecEn"; ...
    "完整343维特征，不使用 Fisher 筛选"];

featureIndex = { ...
    allIdx; ...
    [plvIdx grangerIdx]; ...
    [entropyIdx grangerIdx]; ...
    [entropyIdx plvIdx]; ...
    setdiff(allIdx, apenIdx, 'stable'); ...
    setdiff(allIdx, fuzzyIdx, 'stable'); ...
    setdiff(allIdx, sampenIdx, 'stable'); ...
    setdiff(allIdx, permenIdx, 'stable'); ...
    setdiff(allIdx, specenIdx, 'stable'); ...
    allIdx};

useFisher = [true; true; true; true; true; true; true; true; true; false];
selectedFeatureCount = 50;
nConfigs = numel(code);

%% 结果容器
inputFeatureCount = zeros(nConfigs, 1);
finalFeatureCount = zeros(nConfigs, 1);
subjectAccuracy = zeros(nConfigs, 1);
subjectSensitivity = zeros(nConfigs, 1);
subjectSpecificity = zeros(nConfigs, 1);
subjectPrecision = zeros(nConfigs, 1);
subjectF1 = zeros(nConfigs, 1);
subjectBalancedAccuracy = zeros(nConfigs, 1);
subjectMCC = zeros(nConfigs, 1);
subjectAUC = zeros(nConfigs, 1);
windowAccuracy = zeros(nConfigs, 1);
windowBalancedAccuracy = zeros(nConfigs, 1);
windowAUC = zeros(nConfigs, 1);
results = cell(nConfigs, 1);

predictionTable = table((1:numel(ySubject))', ySubject, ...
    'VariableNames', {'Subject', 'TrueLabel'});

%% 10组消融
for i = 1:nConfigs
    X = XAll(:, featureIndex{i});
    inputFeatureCount(i) = size(X, 2);

    fprintf('\n[%d/%d] %s\n%s\n', ...
        i, nConfigs, code(i), description(i));

    % KernelScale='auto'使用随机子采样；每组从同一随机种子开始。
    rng(20260724, 'twister');

    result = runRBFLOPO( ...
        X, yWindow, subjectWindow, ySubject, ...
        useFisher(i), selectedFeatureCount);
    results{i} = result;

    finalFeatureCount(i) = result.SelectedFeatureCount;
    sm = result.SubjectMetrics;
    wm = result.WindowMetrics;

    subjectAccuracy(i) = sm.Accuracy;
    subjectSensitivity(i) = sm.Sensitivity;
    subjectSpecificity(i) = sm.Specificity;
    subjectPrecision(i) = sm.Precision;
    subjectF1(i) = sm.F1;
    subjectBalancedAccuracy(i) = sm.BalancedAccuracy;
    subjectMCC(i) = sm.MCC;
    subjectAUC(i) = sm.AUC;
    windowAccuracy(i) = wm.Accuracy;
    windowBalancedAccuracy(i) = wm.BalancedAccuracy;
    windowAUC(i) = wm.AUC;

    predictionTable.(['Pred_' char(code(i))]) = result.SubjectPredictedLabel;
    predictionTable.(['Score_' char(code(i))]) = result.SubjectPatientScore;

    fprintf('Acc=%.4f  BalAcc=%.4f  MCC=%.4f  AUC=%.4f\n', ...
        sm.Accuracy, sm.BalancedAccuracy, sm.MCC, sm.AUC);
end

%% 汇总并计算相对完整基线变化
metricsTable = table( ...
    group, code, description, inputFeatureCount, finalFeatureCount, useFisher, ...
    subjectAccuracy, subjectSensitivity, subjectSpecificity, subjectPrecision, ...
    subjectF1, subjectBalancedAccuracy, subjectMCC, subjectAUC, ...
    windowAccuracy, windowBalancedAccuracy, windowAUC, ...
    'VariableNames', { ...
    'AblationGroup', 'Configuration', 'Description', ...
    'InputFeatureCount', 'SelectedFeatureCount', 'UseFisher', ...
    'SubjectAccuracy', 'SubjectSensitivity', 'SubjectSpecificity', ...
    'SubjectPrecision', 'SubjectF1', 'SubjectBalancedAccuracy', ...
    'SubjectMCC', 'SubjectAUC', ...
    'WindowAccuracy', 'WindowBalancedAccuracy', 'WindowAUC'});

metricsTable.DeltaAccuracy = ...
    metricsTable.SubjectAccuracy - metricsTable.SubjectAccuracy(1);
metricsTable.DeltaBalancedAccuracy = ...
    metricsTable.SubjectBalancedAccuracy - metricsTable.SubjectBalancedAccuracy(1);
metricsTable.DeltaMCC = ...
    metricsTable.SubjectMCC - metricsTable.SubjectMCC(1);
metricsTable.DeltaAUC = ...
    metricsTable.SubjectAUC - metricsTable.SubjectAUC(1);

writetable(metricsTable, ...
    fullfile(outDir, 'G01_5s_RBFSVM_ablation_metrics_V1.xlsx'));
writetable(predictionTable, ...
    fullfile(outDir, 'G01_5s_RBFSVM_ablation_predictions_V1.xlsx'));

save(fullfile(outDir, 'G01_5s_RBFSVM_ablation_results_V1.mat'), ...
    'results', 'metricsTable', 'predictionTable', ...
    'featureIndex', 'useFisher', 'selectedFeatureCount', 'ySubject', '-v7.3');

writeSummary(fullfile(outDir, 'G01_5s_RBFSVM_ablation_summary_V1.txt'), ...
    metricsTable, featureFile);

fprintf('\n==================================================\n');
fprintf('完成。结果目录：%s\n', outDir);
fprintf('主结果：G01_5s_RBFSVM_ablation_metrics_V1.xlsx\n');
fprintf('总耗时：%.1f 分钟\n', toc(totalTimer) / 60);
fprintf('结束时间：%s\n', datestr(now));
fprintf('==================================================\n');
end

%% ====================== RBF-SVM LOPO ======================
function result = runRBFLOPO( ...
    X, yWindow, subjectWindow, ySubject, useFisher, selectedFeatureCount)

nSubjects = numel(ySubject);
nWindows = size(X, 1);
subjectPredictedLabel = zeros(nSubjects, 1);
subjectPatientScore = zeros(nSubjects, 1);
windowPredictedLabel = zeros(nWindows, 1);
windowPatientScore = zeros(nWindows, 1);
selectedFeatureIndex = cell(nSubjects, 1);

for heldOutSubject = 1:nSubjects
    trainMask = subjectWindow ~= heldOutSubject;
    testMask = subjectWindow == heldOutSubject;

    XTrain = X(trainMask, :);
    yTrain = yWindow(trainMask);
    XTest = X(testMask, :);

    featureMedian = finiteColumnMedian(XTrain);
    XTrain = replaceNonfinite(XTrain, featureMedian);
    XTest = replaceNonfinite(XTest, featureMedian);

    trainingMean = mean(XTrain, 1);
    trainingStd = std(XTrain, 0, 1);
    trainingStd(trainingStd < 1e-12) = 1;
    XTrain = (XTrain - trainingMean) ./ trainingStd;
    XTest = (XTest - trainingMean) ./ trainingStd;

    if useFisher
        fisherScore = calculateFisherScore(XTrain, yTrain);
        [~, ranked] = sort(fisherScore, 'descend');
        selected = ranked(1:min(selectedFeatureCount, size(XTrain, 2)));
    else
        selected = 1:size(XTrain, 2);
    end
    selectedFeatureIndex{heldOutSubject} = selected;

    model = fitcsvm( ...
        XTrain(:, selected), yTrain, ...
        'KernelFunction', 'rbf', ...
        'KernelScale', 'auto', ...
        'BoxConstraint', 1, ...
        'ClassNames', [0; 1]);

    [predictedLabel, score] = predict(model, XTest(:, selected));
    positiveColumn = find(model.ClassNames == 1, 1);
    patientScore = score(:, positiveColumn);

    windowPredictedLabel(testMask) = predictedLabel;
    windowPatientScore(testMask) = patientScore;

    meanScore = mean(patientScore);
    subjectPatientScore(heldOutSubject) = meanScore;
    subjectPredictedLabel(heldOutSubject) = double(meanScore >= 0);
end

result = struct();
result.SubjectPredictedLabel = subjectPredictedLabel;
result.SubjectPatientScore = subjectPatientScore;
result.WindowPredictedLabel = windowPredictedLabel;
result.WindowPatientScore = windowPatientScore;
result.SelectedFeatureIndex = selectedFeatureIndex;
if useFisher
    result.SelectedFeatureCount = min(selectedFeatureCount, size(X, 2));
else
    result.SelectedFeatureCount = size(X, 2);
end
result.SubjectMetrics = calculateMetrics( ...
    ySubject, subjectPredictedLabel, subjectPatientScore);
result.WindowMetrics = calculateMetrics( ...
    yWindow, windowPredictedLabel, windowPatientScore);
end

function score = calculateFisherScore(X, y)
class0 = X(y == 0, :);
class1 = X(y == 1, :);
score = (mean(class1, 1) - mean(class0, 1)) .^ 2 ./ ...
    (var(class0, 0, 1) + var(class1, 0, 1) + eps);
score(~isfinite(score)) = 0;
end

function medianValues = finiteColumnMedian(X)
medianValues = zeros(1, size(X, 2));
for j = 1:size(X, 2)
    values = X(isfinite(X(:, j)), j);
    if isempty(values)
        medianValues(j) = 0;
    else
        medianValues(j) = median(values);
    end
end
end

function X = replaceNonfinite(X, replacement)
for j = 1:size(X, 2)
    bad = ~isfinite(X(:, j));
    X(bad, j) = replacement(j);
end
end

%% ====================== 指标 ======================
function metrics = calculateMetrics(y, predicted, score)
y = double(y(:));
predicted = double(predicted(:));
score = double(score(:));

TN = sum(y == 0 & predicted == 0);
FP = sum(y == 0 & predicted == 1);
FN = sum(y == 1 & predicted == 0);
TP = sum(y == 1 & predicted == 1);

sensitivity = TP / max(TP + FN, 1);
specificity = TN / max(TN + FP, 1);
precision = TP / max(TP + FP, 1);

metrics = struct();
metrics.Accuracy = (TP + TN) / max(TP + TN + FP + FN, 1);
metrics.Sensitivity = sensitivity;
metrics.Specificity = specificity;
metrics.Precision = precision;
metrics.F1 = 2 * precision * sensitivity / max(precision + sensitivity, eps);
metrics.BalancedAccuracy = (sensitivity + specificity) / 2;
metrics.MCC = (TP * TN - FP * FN) / sqrt(max( ...
    (TP + FP) * (TP + FN) * (TN + FP) * (TN + FN), eps));
metrics.AUC = calculateAUC(y, score);
metrics.ConfusionMatrix = [TN FP; FN TP];
end

function auc = calculateAUC(y, score)
pos = score(y == 1);
neg = score(y == 0);
comparison = pos(:) > neg(:).';
ties = pos(:) == neg(:).';
auc = (sum(comparison(:)) + 0.5 * sum(ties(:))) / ...
    max(numel(pos) * numel(neg), 1);
end

%% ====================== 摘要 ======================
function writeSummary(fileName, T, featureFile)
fid = fopen(fileName, 'w');
cleanupFile = onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid, 'SAHARAN12-G01 5秒 RBF-SVM 特征消融\n');
fprintf(fid, '特征缓存：%s\n', featureFile);
fprintf(fid, 'Delta = 当前消融 - Baseline\n\n');
fprintf(fid, '%-12s  Acc      BalAcc   MCC      AUC      dBalAcc\n', 'Config');
for i = 1:height(T)
    fprintf(fid, '%-12s  %.4f   %.4f   %.4f   %.4f   %+.4f\n', ...
        char(T.Configuration(i)), T.SubjectAccuracy(i), ...
        T.SubjectBalancedAccuracy(i), T.SubjectMCC(i), ...
        T.SubjectAUC(i), T.DeltaBalancedAccuracy(i));
end
end
