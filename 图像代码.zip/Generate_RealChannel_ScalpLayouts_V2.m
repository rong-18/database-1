clc; clear; close all;

%% Generate_RealChannel_ScalpLayouts_V2.m
% 自动读取三个 EEG 数据集的真实通道名并生成脑电电极布局图。
% 关键原则：
% 1) 排除 result/ablation/prediction/classifier 等实验结果文件；
% 2) 不把 LinearSVM、RBFSVM、Logistic、LDA、KNN、RF 误识别为通道；
% 3) 若 MAT 中存在真实 chanlocs 坐标，直接使用；
% 4) 若只有真实标准电极名，则映射到标准 10-20/10-10 位置；
% 5) 若只有 Ch1~ChN 且没有真实 montage 映射，只输出通道表，不伪造头皮位置。

%% ===== 数据集路径 =====
datasets = {
    struct('name','SAHARAN12-G01', ...
           'root','D:\Database\Seizure\SAHARAN\SAHARAN12\G01')
    struct('name','MPHCED02', ...
           'root','D:\Database\Depression\MPHCED\MPHCED02')
    struct('name','MSU01', ...
           'root','D:\Database\Schizophrenia\MSU\MSU01')
};

for i = 1:numel(datasets)
    ds = datasets{i};

    fprintf('\n\n============================================\n');
    fprintf('正在处理：%s\n', ds.name);
    fprintf('目录：%s\n', ds.root);
    fprintf('============================================\n');

    if ~isfolder(ds.root)
        warning('目录不存在，跳过：%s', ds.root);
        continue;
    end

    [labels, xy, sourceFile, coordSource] = read_real_channels(ds.root);

    if isempty(labels)
        warning('%s 未找到可信的真实 EEG 通道信息。', ds.name);
        continue;
    end

    fprintf('\n>>> 找到真实 EEG 通道\n');
    fprintf('来源文件：%s\n', sourceFile);
    fprintf('通道数：%d\n', numel(labels));
    for k = 1:numel(labels)
        fprintf('%2d   %s\n', k, labels{k});
    end

    %% 保存通道表
    txtPath = fullfile(ds.root, [ds.name '_真实通道列表.txt']);
    fid = fopen(txtPath, 'w', 'n', 'UTF-8');
    if fid >= 0
        fprintf(fid, 'Dataset: %s\n', ds.name);
        fprintf(fid, 'Source file: %s\n', sourceFile);
        fprintf(fid, 'Channel count: %d\n', numel(labels));
        fprintf(fid, 'Coordinate source: %s\n\n', coordSource);
        for k = 1:numel(labels)
            fprintf(fid, '%2d\t%s\n', k, labels{k});
        end
        fclose(fid);
        fprintf('已保存通道列表：%s\n', txtPath);
    end

    %% 如果没有真实坐标，尝试按真实标准电极名映射
    if isempty(xy)
        [xyMapped, missingLabels] = map_labels_to_standard_xy(labels);
        if isempty(missingLabels)
            xy = xyMapped;
            coordSource = 'standard 10-20/10-10 coordinates mapped from real channel names';
        else
            fprintf('\n以下通道没有可确认的标准位置映射：\n%s\n', strjoin(missingLabels, ', '));
            fprintf('%s 仅输出真实通道列表，不生成脑电布局图。\n', ds.name);
            fprintf('原因：不能在缺乏真实 montage 映射时擅自给 Ch1~ChN 指定脑区位置。\n');
            continue;
        end
    end

    %% 生成脑电布局图
    savePath = fullfile(ds.root, [ds.name '_真实通道脑电布局图.png']);
    plot_scalp_layout(labels, xy, ds.name, savePath);
    fprintf('已保存脑电布局图：%s\n', savePath);
end

fprintf('\n全部处理完成。\n');


%% =========================================================
function [labels, xy, sourceFile, coordSource] = read_real_channels(rootDir)
labels = {};
xy = [];
sourceFile = '';
coordSource = 'none';

files = dir(fullfile(rootDir, '**', '*.mat'));
if isempty(files), return; end

% 排除明显的实验结果文件
badKeywords = {'result','results','ablation','prediction','predictions', ...
    'metric','metrics','summary','statistical','bootstrap','fisher', ...
    'classifier','roc','confusion','lopo_result','featureimportance', ...
    'importance','selectedfeature'};

keep = true(numel(files),1);
for i = 1:numel(files)
    fullname = lower(fullfile(files(i).folder, files(i).name));
    for k = 1:numel(badKeywords)
        if contains(fullname, badKeywords{k})
            keep(i) = false;
            break;
        end
    end
end
rawFiles = files(keep);

fprintf('共发现 %d 个 MAT 文件。\n', numel(files));
fprintf('排除明显结果文件后剩余 %d 个候选 MAT 文件。\n', numel(rawFiles));
if isempty(rawFiles), return; end

% 文件优先级
score = zeros(numel(rawFiles),1);
for i = 1:numel(rawFiles)
    n = lower(rawFiles(i).name);
    if contains(n,'chan'),      score(i)=score(i)+30; end
    if contains(n,'electrode'), score(i)=score(i)+30; end
    if contains(n,'montage'),   score(i)=score(i)+25; end
    if contains(n,'loc'),       score(i)=score(i)+20; end
    if contains(n,'label'),     score(i)=score(i)+15; end
    if contains(n,'raw'),       score(i)=score(i)+10; end
    if contains(n,'eeg'),       score(i)=score(i)+8;  end
    if contains(n,'data'),      score(i)=score(i)+5;  end
end
[~,order] = sort(score,'descend');
rawFiles = rawFiles(order);

for i = 1:numel(rawFiles)
    filePath = fullfile(rawFiles(i).folder, rawFiles(i).name);
    fprintf('\n检查：%s\n', filePath);
    try
        info = whos('-file', filePath);
        wanted = {};
        for j = 1:numel(info)
            vn = info(j).name;
            lowVN = lower(vn);
            if contains(lowVN,'chan') || contains(lowVN,'elect') || ...
               contains(lowVN,'loc') || contains(lowVN,'montage') || ...
               contains(lowVN,'label')
                wanted{end+1} = vn; %#ok<AGROW>
            end
        end

        if ~isempty(wanted)
            S = load(filePath, wanted{:});
            [tempLabels,tempXY,tempCoordSource] = search_channel_info(S);
            if is_valid_eeg_channel_list(tempLabels)
                labels = normalize_labels(tempLabels);
                xy = tempXY;
                sourceFile = filePath;
                coordSource = tempCoordSource;
                fprintf('>>> 在候选变量中找到可信 EEG 通道信息。\n');
                return;
            end
        end

        S = load(filePath);
        [tempLabels,tempXY,tempCoordSource] = search_channel_info(S);
        if is_valid_eeg_channel_list(tempLabels)
            labels = normalize_labels(tempLabels);
            xy = tempXY;
            sourceFile = filePath;
            coordSource = tempCoordSource;
            fprintf('>>> 在 MAT 中找到可信 EEG 通道信息。\n');
            return;
        end
    catch ME
        fprintf('跳过该文件：%s\n', ME.message);
    end
end
end


%% =========================================================
function [labels, xy, coordSource] = search_channel_info(S)
labels = {};
xy = [];
coordSource = 'none';
if isempty(S), return; end
[labels, xy, coordSource] = search_any(S);
end

function [labels, xy, coordSource] = search_any(x)
labels = {};
xy = [];
coordSource = 'none';
if isempty(x), return; end

if isstruct(x)
    % EEGLAB chanlocs 风格
    if numel(x) >= 4 && isfield(x,'labels')
        try
            tempLabels = {x.labels};
            if is_valid_eeg_channel_list(tempLabels)
                labels = tempLabels;
                xy = extract_xy_from_chanlocs(x);
                if ~isempty(xy)
                    coordSource = 'real chanlocs coordinates from MAT';
                end
                return;
            end
        catch
        end
    end

    fn = fieldnames(x);
    for i = 1:numel(fn)
        v = x.(fn{i});
        if is_label_field_name(fn{i})
            tempLabels = to_label_cell(v);
            if is_valid_eeg_channel_list(tempLabels)
                labels = tempLabels;
                return;
            end
        end
        [labels, xy, coordSource] = search_any(v);
        if ~isempty(labels), return; end
    end
    return;
end

if iscell(x) || isstring(x) || ischar(x)
    tempLabels = to_label_cell(x);
    if is_valid_eeg_channel_list(tempLabels)
        labels = tempLabels;
        return;
    end
end
end


%% =========================================================
function tf = is_label_field_name(name)
name = lower(name);
keys = {'label','labels','chan','chans','channel','channels', ...
    'channelnames','channel_names','channellabels','channel_labels', ...
    'electrode','electrodes','clab','chanlocs','montage'};
tf = any(strcmp(name, keys));
end

function labels = to_label_cell(x)
labels = {};
if isstring(x)
    labels = cellstr(x(:));
    return;
end
if ischar(x)
    if size(x,1) > 1
        labels = cellstr(strtrim(x));
    else
        parts = regexp(strtrim(x), '[,;\s]+', 'split');
        labels = parts(~cellfun(@isempty, parts));
    end
    return;
end
if iscell(x)
    try
        if all(cellfun(@(c)ischar(c) || isstring(c), x(:)))
            labels = cellfun(@char, x(:), 'UniformOutput', false);
        end
    catch
    end
end
end


%% =========================================================
function tf = is_valid_eeg_channel_list(labels)
tf = false;
if isempty(labels), return; end
labels = normalize_labels(labels);
N = numel(labels);
if N < 4 || N > 256, return; end

blackList = {'LINEARSVM','RBF-SVM','RBFSVM','LOGISTIC', ...
    'LOGISTICREGRESSION','L2-LR','L2LR','LDA','KNN','RF', ...
    'RANDOMFOREST','SVM','XGBOOST','CONTROL','PATIENT','HC','MDD', ...
    'SZ','ACCURACY','AUC','MCC','BALANCEDACCURACY'};

for i = 1:N
    token = regexprep(labels{i}, '[^A-Z0-9\-]', '');
    if any(strcmp(token, blackList)), return; end
end

validCount = 0;
for i = 1:N
    s = upper(strtrim(labels{i}));
    if ~isempty(regexp(s, '^CH0*\d+$', 'once'))
        validCount = validCount + 1;
        continue;
    end
    eegPattern = '^(FP|AF|F|FT|FC|T|C|TP|CP|P|PO|O|IZ)[Z0-9]+$';
    if ~isempty(regexp(s, eegPattern, 'once'))
        validCount = validCount + 1;
        continue;
    end
end

tf = (validCount / N) >= 0.80;
end


%% =========================================================
function labels = normalize_labels(labels)
if isempty(labels), labels = {}; return; end
if isstring(labels), labels = cellstr(labels(:)); end
if ischar(labels)
    if size(labels,1) > 1
        labels = cellstr(labels);
    else
        labels = regexp(labels,'[,;\s]+','split');
    end
end
labels = labels(:)';
labels = cellfun(@(x) upper(strtrim(char(x))), labels, 'UniformOutput', false);
labels = labels(~cellfun(@isempty,labels));
end


%% =========================================================
function xy = extract_xy_from_chanlocs(chanlocs)
xy = [];
try
    if isfield(chanlocs,'X') && isfield(chanlocs,'Y')
        X = [chanlocs.X]';
        Y = [chanlocs.Y]';
        if numel(X)==numel(chanlocs) && numel(Y)==numel(chanlocs) && ...
           any(isfinite(X)) && any(isfinite(Y))
            xy = normalize_xy([X Y]);
            return;
        end
    end
catch
end
try
    if isfield(chanlocs,'theta') && isfield(chanlocs,'radius')
        th = [chanlocs.theta]';
        rd = [chanlocs.radius]';
        if numel(th)==numel(chanlocs) && numel(rd)==numel(chanlocs) && ...
           any(isfinite(th)) && any(isfinite(rd))
            x = rd .* sind(th);
            y = rd .* cosd(th);
            xy = normalize_xy([x y]);
            return;
        end
    end
catch
end
end

function xy = normalize_xy(xy)
xy = double(xy);
xy(~isfinite(xy)) = 0;
mx = max(sqrt(sum(xy.^2,2)));
if mx > 0, xy = xy ./ mx * 0.88; end
end


%% =========================================================
function [xy, missingLabels] = map_labels_to_standard_xy(labels)
pos = standard_pos_map();
xy = nan(numel(labels),2);
missingLabels = {};
for i = 1:numel(labels)
    key = upper(strtrim(labels{i}));
    % 旧 10-20 命名兼容
    if strcmp(key,'T3'), key='T7'; end
    if strcmp(key,'T4'), key='T8'; end
    if strcmp(key,'T5'), key='P7'; end
    if strcmp(key,'T6'), key='P8'; end

    if isKey(pos,key)
        xy(i,:) = pos(key);
    else
        missingLabels{end+1} = labels{i}; %#ok<AGROW>
    end
end
end


%% =========================================================
function pos = standard_pos_map()
pos = containers.Map();
add('FP1',[-0.28,0.90]); add('FPZ',[0,0.94]); add('FP2',[0.28,0.90]);
add('AF7',[-0.58,0.78]); add('AF3',[-0.30,0.74]); add('AFZ',[0,0.78]); add('AF4',[0.30,0.74]); add('AF8',[0.58,0.78]);
add('F7',[-0.78,0.58]); add('F5',[-0.58,0.58]); add('F3',[-0.38,0.55]); add('F1',[-0.18,0.53]); add('FZ',[0,0.55]); add('F2',[0.18,0.53]); add('F4',[0.38,0.55]); add('F6',[0.58,0.58]); add('F8',[0.78,0.58]);
add('FT7',[-0.90,0.34]); add('FC5',[-0.62,0.34]); add('FC3',[-0.42,0.32]); add('FC1',[-0.20,0.30]); add('FCZ',[0,0.31]); add('FC2',[0.20,0.30]); add('FC4',[0.42,0.32]); add('FC6',[0.62,0.34]); add('FT8',[0.90,0.34]);
add('T7',[-0.98,0.02]); add('C5',[-0.65,0.02]); add('C3',[-0.45,0.03]); add('C1',[-0.22,0.03]); add('CZ',[0,0.04]); add('C2',[0.22,0.03]); add('C4',[0.45,0.03]); add('C6',[0.65,0.02]); add('T8',[0.98,0.02]);
add('TP7',[-0.90,-0.28]); add('CP5',[-0.62,-0.26]); add('CP3',[-0.42,-0.25]); add('CP1',[-0.20,-0.24]); add('CPZ',[0,-0.25]); add('CP2',[0.20,-0.24]); add('CP4',[0.42,-0.25]); add('CP6',[0.62,-0.26]); add('TP8',[0.90,-0.28]);
add('P7',[-0.78,-0.53]); add('P5',[-0.58,-0.50]); add('P3',[-0.38,-0.46]); add('P1',[-0.18,-0.44]); add('PZ',[0,-0.46]); add('P2',[0.18,-0.44]); add('P4',[0.38,-0.46]); add('P6',[0.58,-0.50]); add('P8',[0.78,-0.53]);
add('PO7',[-0.58,-0.68]); add('PO3',[-0.28,-0.67]); add('POZ',[0,-0.70]); add('PO4',[0.28,-0.67]); add('PO8',[0.58,-0.68]);
add('O1',[-0.28,-0.84]); add('OZ',[0,-0.91]); add('O2',[0.28,-0.84]); add('IZ',[0,-0.99]);
    function add(k,v), pos(k)=v; end
end


%% =========================================================
function plot_scalp_layout(labels, xy, figTitle, savePath)
f = figure('Color','w','Position',[100 50 850 900]);
ax = axes('Parent',f);
hold(ax,'on'); axis(ax,'equal'); axis(ax,[-1.22 1.22 -1.18 1.18]); axis(ax,'off');

% 头部轮廓
t = linspace(0,2*pi,500);
plot(ax,cos(t),sin(t),'k','LineWidth',2.0);
% 鼻子
plot(ax,[-0.09 0 0.09],[1.00 1.13 1.00],'k','LineWidth',2.0);
% 耳朵
th = linspace(-pi/2,pi/2,100);
plot(ax,-1.00-0.10*cos(th),0.20*sin(th),'k','LineWidth',2.0);
plot(ax, 1.00+0.10*cos(th),0.20*sin(th),'k','LineWidth',2.0);

% 电极
scatter(ax,xy(:,1),xy(:,2),850, ...
    'MarkerFaceColor',[0.29 0.31 0.56], ...
    'MarkerEdgeColor','k','LineWidth',0.8);

for i = 1:numel(labels)
    text(ax,xy(i,1),xy(i,2),labels{i}, ...
        'HorizontalAlignment','center','VerticalAlignment','middle', ...
        'Color','w','FontWeight','bold','FontSize',12.5, ...
        'FontName','Times New Roman');
end

title(ax,sprintf('%s | %d-channel EEG montage',figTitle,numel(labels)), ...
    'FontSize',18,'FontWeight','bold','FontName','Times New Roman', ...
    'Interpreter','none');

exportgraphics(f,savePath,'Resolution',400);
close(f);
end
