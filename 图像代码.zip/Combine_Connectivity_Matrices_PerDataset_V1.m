function Combine_Connectivity_Matrices_PerDataset_V1
% 将上一版重要连接分析结果整理为“每个数据集一张图”
%
% 前提：
% 已运行 Generate_Important_Connectivity_Matrices_V1
%
% 输入目录：
% D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices
%
% 输出：
% 1) SAHARAN12_G01_Connectivity_Combined.png   2×3
% 2) MPHCED02_Connectivity_Combined.png        4×3
% 3) MSU01_Connectivity_Combined.png           2×3

clc;
close all;

rootDir = 'D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices';

%% G01：2×3
makeTwoRowFigure( ...
    fullfile(rootDir,'SAHARAN12_G01'), ...
    'SAHARAN12-G01', ...
    fullfile(rootDir,'SAHARAN12_G01_Connectivity_Combined.png'));

%% MSU01：2×3
makeTwoRowFigure( ...
    fullfile(rootDir,'MSU01'), ...
    'MSU01', ...
    fullfile(rootDir,'MSU01_Connectivity_Combined.png'));

%% MPHCED02：4×3
makeMPHCEDFigure( ...
    fullfile(rootDir,'MPHCED02_EC'), ...
    fullfile(rootDir,'MPHCED02_EO'), ...
    fullfile(rootDir,'MPHCED02_Connectivity_Combined.png'));

fprintf('三张数据集整合图已生成：\n%s\n',rootDir);
end

%% =========================================================
%% G01 / MSU01：2×3
%% =========================================================
function makeTwoRowFigure(dataDir,datasetName,saveFile)

plvFile = fullfile(dataDir,'PLV_important_connectivity.xlsx');
gcFile = fullfile(dataDir,'Granger_important_connectivity.xlsx');

[plvC,plvP,plvD,names] = readImportantMatrices(plvFile);
[gcC,gcP,gcD,~] = readImportantMatrices(gcFile);

fig = figure('Color','w','Position',[60 80 1450 850]);
tiledlayout(2,3,'Padding','compact','TileSpacing','compact');

meanLim = commonLimit(plvC,plvP);
diffLim = matrixLimit(plvD);

nexttile;
drawMatrix(plvC,names,[0 meanLim],false);
title('PLV - Control','FontWeight','bold');

nexttile;
drawMatrix(plvP,names,[0 meanLim],false);
title('PLV - Patient','FontWeight','bold');

nexttile;
drawMatrix(plvD,names,[-diffLim diffLim],true);
title('PLV - Patient - Control','FontWeight','bold');

meanLim = commonLimit(gcC,gcP);
diffLim = matrixLimit(gcD);

nexttile;
drawMatrix(gcC,names,[0 meanLim],false);
title('Granger - Control','FontWeight','bold');

nexttile;
drawMatrix(gcP,names,[0 meanLim],false);
title('Granger - Patient','FontWeight','bold');

nexttile;
drawMatrix(gcD,names,[-diffLim diffLim],true);
title('Granger - Patient - Control','FontWeight','bold');

sgtitle([datasetName ' | Important PLV and Granger Connections'], ...
    'FontWeight','bold','FontSize',15);

exportgraphics(fig,saveFile,'Resolution',300);
close(fig);
end

%% =========================================================
%% MPHCED02：4×3
%% =========================================================
function makeMPHCEDFigure(ecDir,eoDir,saveFile)

[ecPlvC,ecPlvP,ecPlvD,names] = ...
    readImportantMatrices(fullfile(ecDir,'PLV_important_connectivity.xlsx'));
[ecGcC,ecGcP,ecGcD,~] = ...
    readImportantMatrices(fullfile(ecDir,'Granger_important_connectivity.xlsx'));

[eoPlvC,eoPlvP,eoPlvD,~] = ...
    readImportantMatrices(fullfile(eoDir,'PLV_important_connectivity.xlsx'));
[eoGcC,eoGcP,eoGcD,~] = ...
    readImportantMatrices(fullfile(eoDir,'Granger_important_connectivity.xlsx'));

% EC/EO的同一连接类型使用相同色标，便于状态间比较
plvMeanLim = max([ ...
    commonLimit(ecPlvC,ecPlvP), ...
    commonLimit(eoPlvC,eoPlvP)]);
plvDiffLim = max(matrixLimit(ecPlvD),matrixLimit(eoPlvD));

gcMeanLim = max([ ...
    commonLimit(ecGcC,ecGcP), ...
    commonLimit(eoGcC,eoGcP)]);
gcDiffLim = max(matrixLimit(ecGcD),matrixLimit(eoGcD));

fig = figure('Color','w','Position',[40 30 1450 1500]);
tiledlayout(4,3,'Padding','compact','TileSpacing','compact');

drawRow(ecPlvC,ecPlvP,ecPlvD,names, ...
    plvMeanLim,plvDiffLim,'EC - PLV');

drawRow(ecGcC,ecGcP,ecGcD,names, ...
    gcMeanLim,gcDiffLim,'EC - Granger');

drawRow(eoPlvC,eoPlvP,eoPlvD,names, ...
    plvMeanLim,plvDiffLim,'EO - PLV');

drawRow(eoGcC,eoGcP,eoGcD,names, ...
    gcMeanLim,gcDiffLim,'EO - Granger');

sgtitle('MPHCED02 | Important PLV and Granger Connections', ...
    'FontWeight','bold','FontSize',15);

exportgraphics(fig,saveFile,'Resolution',300);
close(fig);
end

function drawRow(C,P,D,names,meanLim,diffLim,rowName)

nexttile;
drawMatrix(C,names,[0 meanLim],false);
title([rowName ' - Control'],'FontWeight','bold');

nexttile;
drawMatrix(P,names,[0 meanLim],false);
title([rowName ' - Patient'],'FontWeight','bold');

nexttile;
drawMatrix(D,names,[-diffLim diffLim],true);
title([rowName ' - Patient - Control'],'FontWeight','bold');
end

%% =========================================================
%% Excel读取
%% =========================================================
function [C,P,D,names] = readImportantMatrices(fileName)

if ~isfile(fileName)
    error('未找到结果文件：%s\n请先运行 Generate_Important_Connectivity_Matrices_V1。', ...
        fileName);
end

[C,names] = readMatrixSheet(fileName,'ControlImportant');
[P,~] = readMatrixSheet(fileName,'PatientImportant');
[D,~] = readMatrixSheet(fileName,'DifferenceImportant');
end

function [M,names] = readMatrixSheet(fileName,sheetName)

T = readtable(fileName, ...
    'Sheet',sheetName, ...
    'ReadRowNames',true, ...
    'VariableNamingRule','preserve');

names = T.Properties.RowNames;
M = table2array(T);
end

%% =========================================================
%% 绘图
%% =========================================================
function drawMatrix(M,names,limits,useDiverging)

imagesc(M,'AlphaData',~isnan(M));
axis square;



set(gca, ...
    'Color',[1 1 1], ...
    'XTick',1:numel(names), ...
    'YTick',1:numel(names), ...
    'XTickLabel',names, ...
    'YTickLabel',names, ...
    'XTickLabelRotation',45, ...
    'FontSize',8);

if useDiverging
    colormap(gca,blueWhiteRed(256));
else
    colormap(gca,parula(256));
end

caxis(limits);
colorbar;
end

function lim = commonLimit(A,B)
v = [A(~isnan(A)); B(~isnan(B))];
if isempty(v)
    lim = 1;
else
    lim = max(v);
    if lim<=0
        lim = 1;
    end
end
end

function lim = matrixLimit(A)
v = abs(A(~isnan(A)));
if isempty(v)
    lim = 1;
else
    lim = max(v);
    if lim==0
        lim = 1;
    end
end
end

function cmap = blueWhiteRed(m)

x = [0 0.5 1];
r = interp1(x,[0 1 1],linspace(0,1,m));
g = interp1(x,[0 1 0],linspace(0,1,m));
b = interp1(x,[1 1 0],linspace(0,1,m));
cmap = [r(:) g(:) b(:)];
end
