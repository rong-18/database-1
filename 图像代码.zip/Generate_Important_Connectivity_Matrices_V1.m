function Generate_Important_Connectivity_Matrices_V1
% 生成重要PLV/Granger连接的患者组、对照组及组间差异矩阵
%
% 默认设置：
% - 重要连接：Top 15
% - 排序标准：|Cohen''s d| 从大到小
% - 差异方向：患者组均值 - 对照组均值
% - MPHCED02：EC / EO 分开分析
%
% 输出目录：
% D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices

clc;
close all;

topK = 15;
outDir = 'D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices';

if ~exist(outDir,'dir')
    mkdir(outDir);
end

fprintf('开始生成重要PLV/Granger连接矩阵...\n');
fprintf('输出目录：%s\n',outDir);
fprintf('TopK：%d\n\n',topK);

processG01(topK,outDir);
processMPHCED02(topK,outDir);
processMSU01(topK,outDir);

fprintf('\n全部完成。\n');
end

%% =========================================================
%% G01
%% =========================================================
function processG01(topK,outDir)

datasetName = 'SAHARAN12_G01';
saveDir = fullfile(outDir,datasetName);
if ~exist(saveDir,'dir')
    mkdir(saveDir);
end

featureFile = 'D:\Database\Seizure\SAHARAN\SAHARAN12\G01\G01_window_features_V1.mat';
labelFile = 'D:\Database\Seizure\SAHARAN\G_dataLable.mat';

F = load(featureFile,'featureSets','labelSets','subjectSets','windowSecs');
L = load(labelFile,'dataLable');

scaleIndex = find(double(F.windowSecs(:))==5,1);
X = double(F.featureSets{scaleIndex});
subjectWindow = double(F.subjectSets{scaleIndex}(:));
ySubject = double(L.dataLable(:));

valid = subjectWindow>0;
X = X(valid,:);
subjectWindow = subjectWindow(valid);

nCh = 14;
channelNames = makeChannelNames(nCh);

entropyDim = 70;
plvDim = 91;
grangerDim = 182;

plvIdx = entropyDim + (1:plvDim);
grangerIdx = entropyDim + plvDim + (1:grangerDim);

plvSubject = aggregateSubjectMean(X(:,plvIdx),subjectWindow,numel(ySubject));
grangerSubject = aggregateSubjectMean(X(:,grangerIdx),subjectWindow,numel(ySubject));

analyzeConnectivity( ...
    saveDir,datasetName,'PLV', ...
    plvSubject,ySubject,nCh,channelNames,false,topK);

analyzeConnectivity( ...
    saveDir,datasetName,'Granger', ...
    grangerSubject,ySubject,nCh,channelNames,true,topK);
end

%% =========================================================
%% MPHCED02：EC / EO 分开
%% =========================================================
function processMPHCED02(topK,outDir)

rootDir = 'D:\Database\Depression\MPHCED\MPHCED02';
featureCandidates = { ...
    fullfile(rootDir,'MPHCED02_subject_features_V3.mat'), ...
    fullfile(rootDir,'MPHCED02_subject_features_V2.mat')};

featureFile = '';
for k = 1:numel(featureCandidates)
    if isfile(featureCandidates{k})
        featureFile = featureCandidates{k};
        break;
    end
end

if isempty(featureFile)
    error('未找到MPHCED02受试者级特征文件。');
end

S = load(featureFile,'stateFeatures','windowSecs');
scaleIndex = find(double(S.windowSecs(:))==5,1);

nCh = 19;
channelNames = makeChannelNames(nCh);

meanPartDim = 608;
entropyDim = 95;
plvDim = 171;
grangerDim = 342;

plvIdx = entropyDim + (1:plvDim);
grangerIdx = entropyDim + plvDim + (1:grangerDim);

states = {'EC','EO'};
for s = 1:numel(states)
    stateName = states{s};
    saveDir = fullfile(outDir,['MPHCED02_' stateName]);
    if ~exist(saveDir,'dir')
        mkdir(saveDir);
    end

    stateData = S.stateFeatures.(stateName);
    Xfull = double(stateData.FeatureSets{scaleIndex});
    y = double(stateData.Labels(:));

    Xmean = Xfull(:,1:meanPartDim);
    plvSubject = Xmean(:,plvIdx);
    grangerSubject = Xmean(:,grangerIdx);

    analyzeConnectivity( ...
        saveDir,['MPHCED02_' stateName],'PLV', ...
        plvSubject,y,nCh,channelNames,false,topK);

    analyzeConnectivity( ...
        saveDir,['MPHCED02_' stateName],'Granger', ...
        grangerSubject,y,nCh,channelNames,true,topK);
end
end

%% =========================================================
%% MSU01
%% =========================================================
function processMSU01(topK,outDir)

datasetName = 'MSU01';
saveDir = fullfile(outDir,datasetName);
if ~exist(saveDir,'dir')
    mkdir(saveDir);
end

featureFile = 'D:\Database\Schizophrenia\MSU\MSU01\MSU01_window_features_V1.mat';

F = load(featureFile,'featureSets','subjectSets','windowSecs','ySubject');
scaleIndex = find(double(F.windowSecs(:))==5,1);

X = double(F.featureSets{scaleIndex});
subjectWindow = double(F.subjectSets{scaleIndex}(:));
ySubject = double(F.ySubject(:));

valid = subjectWindow>0;
X = X(valid,:);
subjectWindow = subjectWindow(valid);

nCh = 16;
channelNames = makeChannelNames(nCh);

entropyDim = 80;
plvDim = 120;
grangerDim = 240;

plvIdx = entropyDim + (1:plvDim);
grangerIdx = entropyDim + plvDim + (1:grangerDim);

plvSubject = aggregateSubjectMean(X(:,plvIdx),subjectWindow,numel(ySubject));
grangerSubject = aggregateSubjectMean(X(:,grangerIdx),subjectWindow,numel(ySubject));

analyzeConnectivity( ...
    saveDir,datasetName,'PLV', ...
    plvSubject,ySubject,nCh,channelNames,false,topK);

analyzeConnectivity( ...
    saveDir,datasetName,'Granger', ...
    grangerSubject,ySubject,nCh,channelNames,true,topK);
end

%% =========================================================
%% 通用分析：计算重要连接并出图出表
%% =========================================================
function analyzeConnectivity( ...
    saveDir,datasetName,featureName, ...
    Xsubject,y,nCh,channelNames,isDirected,topK)

controlMask = (y==0);
patientMask = (y==1);

Xcontrol = Xsubject(controlMask,:);
Xpatient = Xsubject(patientMask,:);

controlMeanVec = mean(Xcontrol,1);
patientMeanVec = mean(Xpatient,1);
diffVec = patientMeanVec - controlMeanVec;

dVec = computeCohensD(Xpatient,Xcontrol);
absD = abs(dVec);

[edgeRows,edgeCols] = getEdgeMapping(nCh,isDirected);
nEdges = numel(edgeRows);

[~,order] = sort(absD,'descend');
topK = min(topK,nEdges);
topIndex = order(1:topK);

controlMat = vectorToMatrix(controlMeanVec,nCh,isDirected);
patientMat = vectorToMatrix(patientMeanVec,nCh,isDirected);
diffMat = vectorToMatrix(diffVec,nCh,isDirected);

importantControlMat = maskMatrix(controlMeanVec,topIndex,nCh,isDirected);
importantPatientMat = maskMatrix(patientMeanVec,topIndex,nCh,isDirected);
importantDiffMat = maskMatrix(diffVec,topIndex,nCh,isDirected);

topTable = buildTopEdgeTable( ...
    topIndex,edgeRows,edgeCols,channelNames, ...
    controlMeanVec,patientMeanVec,diffVec,dVec,isDirected);

excelFile = fullfile(saveDir,[featureName '_important_connectivity.xlsx']);
if isfile(excelFile)
    delete(excelFile);
end

writetable(topTable,excelFile,'Sheet','TopEdges','FileType','spreadsheet');

writeMatrixToExcel(excelFile,'ControlFull',controlMat,channelNames);
writeMatrixToExcel(excelFile,'PatientFull',patientMat,channelNames);
writeMatrixToExcel(excelFile,'DifferenceFull',diffMat,channelNames);
writeMatrixToExcel(excelFile,'ControlImportant',importantControlMat,channelNames);
writeMatrixToExcel(excelFile,'PatientImportant',importantPatientMat,channelNames);
writeMatrixToExcel(excelFile,'DifferenceImportant',importantDiffMat,channelNames);

plotConnectivityFigure( ...
    datasetName,featureName, ...
    importantControlMat,importantPatientMat,importantDiffMat, ...
    channelNames,isDirected, ...
    fullfile(saveDir,[featureName '_important_matrices.png']));

writeSummaryText( ...
    fullfile(saveDir,[featureName '_summary.txt']), ...
    datasetName,featureName,topTable,topK);

fprintf('%s - %s 完成：%s\n',datasetName,featureName,saveDir);
end

%% =========================================================
%% 受试者聚合
%% =========================================================
function Xsubject = aggregateSubjectMean(Xwindow,subjectWindow,nSubjects)

Xsubject = zeros(nSubjects,size(Xwindow,2));
for s = 1:nSubjects
    mask = subjectWindow==s;
    Xsubject(s,:) = mean(Xwindow(mask,:),1);
end
end

%% =========================================================
%% 边映射
%% =========================================================
function [rows,cols] = getEdgeMapping(nCh,isDirected)

if isDirected
    rows = zeros(nCh*(nCh-1),1);
    cols = zeros(nCh*(nCh-1),1);
    idx = 0;
    for i = 1:nCh
        for j = 1:nCh
            if i~=j
                idx = idx + 1;
                rows(idx) = i;
                cols(idx) = j;
            end
        end
    end
else
    nEdges = nCh*(nCh-1)/2;
    rows = zeros(nEdges,1);
    cols = zeros(nEdges,1);
    idx = 0;
    for i = 1:nCh-1
        for j = i+1:nCh
            idx = idx + 1;
            rows(idx) = i;
            cols(idx) = j;
        end
    end
end
end

function M = vectorToMatrix(v,nCh,isDirected)

[rows,cols] = getEdgeMapping(nCh,isDirected);
M = nan(nCh,nCh);

if isDirected
    for k = 1:numel(v)
        M(rows(k),cols(k)) = v(k);
    end
else
    M(1:nCh+1:end) = 0;
    for k = 1:numel(v)
        M(rows(k),cols(k)) = v(k);
        M(cols(k),rows(k)) = v(k);
    end
end
end

function M = maskMatrix(v,topIndex,nCh,isDirected)

[rows,cols] = getEdgeMapping(nCh,isDirected);
M = nan(nCh,nCh);

if ~isDirected
    M(1:nCh+1:end) = 0;
end

for t = 1:numel(topIndex)
    k = topIndex(t);
    i = rows(k);
    j = cols(k);
    M(i,j) = v(k);
    if ~isDirected
        M(j,i) = v(k);
    end
end
end

%% =========================================================
%% 统计量与表格
%% =========================================================
function d = computeCohensD(X1,X0)

mu1 = mean(X1,1);
mu0 = mean(X0,1);
s1 = std(X1,0,1);
s0 = std(X0,0,1);
n1 = size(X1,1);
n0 = size(X0,1);

pooled = sqrt(((n1-1)*s1.^2 + (n0-1)*s0.^2) ./ max(n1+n0-2,1));
pooled(pooled<1e-12) = eps;

d = (mu1 - mu0) ./ pooled;
d(~isfinite(d)) = 0;
end

function T = buildTopEdgeTable( ...
    topIndex,edgeRows,edgeCols,channelNames, ...
    controlMeanVec,patientMeanVec,diffVec,dVec,isDirected)

n = numel(topIndex);
rankCol = (1:n)';
sourceCol = strings(n,1);
targetCol = strings(n,1);
connCol = strings(n,1);

for r = 1:n
    idx = topIndex(r);
    sourceCol(r) = string(channelNames{edgeRows(idx)});
    targetCol(r) = string(channelNames{edgeCols(idx)});
    if isDirected
        connCol(r) = sourceCol(r) + "->" + targetCol(r);
    else
        connCol(r) = sourceCol(r) + "-" + targetCol(r);
    end
end

controlCol = controlMeanVec(topIndex)';
patientCol = patientMeanVec(topIndex)';
diffCol = diffVec(topIndex)';
dCol = dVec(topIndex)';
absDCol = abs(dCol);

T = table(rankCol,connCol,sourceCol,targetCol, ...
    controlCol,patientCol,diffCol,dCol,absDCol, ...
    'VariableNames',{ ...
    'Rank','Connection','Source','Target', ...
    'ControlMean','PatientMean','Difference_PatientMinusControl', ...
    'CohensD','AbsCohensD'});
end

function writeMatrixToExcel(fileName,sheetName,M,channelNames)

T = array2table(M, ...
    'VariableNames',matlab.lang.makeValidName(channelNames), ...
    'RowNames',channelNames);

writetable(T,fileName,'Sheet',sheetName, ...
    'WriteRowNames',true,'FileType','spreadsheet');
end

%% =========================================================
%% 出图
%% =========================================================
function plotConnectivityFigure( ...
    datasetName,featureName, ...
    controlMat,patientMat,diffMat, ...
    channelNames,isDirected,saveFile)

fig = figure('Color','w','Position',[100 100 1500 430]);
tiledlayout(1,3,'Padding','compact','TileSpacing','compact');

meanMax = max([abs(controlMat(~isnan(controlMat))); ...
               abs(patientMat(~isnan(patientMat)))]);

diffMax = max(abs(diffMat(~isnan(diffMat))));
if isempty(meanMax) || meanMax==0
    meanMax = 1;
end
if isempty(diffMax) || diffMax==0
    diffMax = 1;
end

nexttile;
plotSingleMatrix(controlMat,channelNames,[-meanMax meanMax],false);
title('Control Group','FontWeight','bold');

nexttile;
plotSingleMatrix(patientMat,channelNames,[-meanMax meanMax],false);
title('Patient Group','FontWeight','bold');

nexttile;
plotSingleMatrix(diffMat,channelNames,[-diffMax diffMax],true);
title('Patient - Control','FontWeight','bold');

if isDirected
    sgtitle(sprintf('%s | %s Important Directed Connections', ...
        datasetName,featureName),'FontWeight','bold');
else
    sgtitle(sprintf('%s | %s Important Undirected Connections', ...
        datasetName,featureName),'FontWeight','bold');
end

exportgraphics(fig,saveFile,'Resolution',300);
close(fig);
end

function plotSingleMatrix(M,channelNames,clim,useDiverging)

imagesc(M,'AlphaData',~isnan(M));
set(gca,'Color',[1 1 1]);
axis square;
set(gca,'XTick',1:numel(channelNames), ...
    'YTick',1:numel(channelNames), ...
    'XTickLabel',channelNames, ...
    'YTickLabel',channelNames, ...
    'XTickLabelRotation',45, ...
    'FontSize',9);

if useDiverging
    colormap(gca,blueWhiteRed(256));
else
    colormap(gca,parula(256));
end

caxis(clim);
colorbar;
end

function cmap = blueWhiteRed(m)

if nargin<1
    m = 256;
end

bottom = [0 0 1];
middle = [1 1 1];
top = [1 0 0];

x = [0 0.5 1];
r = interp1(x,[bottom(1) middle(1) top(1)],linspace(0,1,m));
g = interp1(x,[bottom(2) middle(2) top(2)],linspace(0,1,m));
b = interp1(x,[bottom(3) middle(3) top(3)],linspace(0,1,m));
cmap = [r(:) g(:) b(:)];
end

%% =========================================================
%% 文本摘要
%% =========================================================
function writeSummaryText(fileName,datasetName,featureName,T,topK)

fid = fopen(fileName,'w');
if fid<0
    return;
end
cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid,'%s - %s 重要连接摘要\n',datasetName,featureName);
fprintf(fid,'TopK = %d，按 |Cohen''s d| 排序\n',topK);
fprintf(fid,'差异方向 = 患者组均值 - 对照组均值\n\n');

for k = 1:min(height(T),topK)
    fprintf(fid, ...
        'Top %d: %s | Control=%.4f | Patient=%.4f | Diff=%.4f | d=%.4f\n', ...
        T.Rank(k),char(T.Connection(k)), ...
        T.ControlMean(k),T.PatientMean(k), ...
        T.Difference_PatientMinusControl(k), ...
        T.CohensD(k));
end
end

%% =========================================================
%% 默认通道名
%% =========================================================
function channelNames = makeChannelNames(nCh)

channelNames = cell(nCh,1);
for k = 1:nCh
    channelNames{k} = sprintf('Ch%d',k);
end
end
