function Combine_Connectivity_Matrices_PerDataset_V9
% 每个数据集一张整合图 —— 固定像素间距版
%
% 目标：
% 三个数据集全部保持与当前 MSU01 图相同的视觉间距。
%
% 核心改动：
% - 不再用归一化 HorizontalGap / VerticalGap
% - 改为固定像素：
%     每个子图宽度一致
%     每个子图高度一致
%     横向间距一致
%     纵向间距一致
% - MPHCED02 虽然有4行，但每行尺寸和间距与G01/MSU01完全一致
%
% 输入目录：
% D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices

clc;
close all;

rootDir = 'D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices';

if ~exist(rootDir,'dir')
    error('未找到结果目录：%s',rootDir);
end

fprintf('开始生成统一像素间距版连接矩阵图...\n');
fprintf('结果目录：%s\n\n',rootDir);

style = getStyle();

makeTwoRowFigure( ...
    fullfile(rootDir,'SAHARAN12_G01'), ...
    'SAHARAN12-G01', ...
    fullfile(rootDir,'SAHARAN12_G01_Connectivity_Combined.png'), ...
    style);

makeMPHCEDFigure( ...
    fullfile(rootDir,'MPHCED02_EC'), ...
    fullfile(rootDir,'MPHCED02_EO'), ...
    fullfile(rootDir,'MPHCED02_Connectivity_Combined.png'), ...
    style);

makeTwoRowFigure( ...
    fullfile(rootDir,'MSU01'), ...
    'MSU01', ...
    fullfile(rootDir,'MSU01_Connectivity_Combined.png'), ...
    style);

fprintf('\n全部完成。\n');
end

%% =========================================================
%% 统一样式：全部用固定像素
%% =========================================================
function style = getStyle()

style = struct();

style.FontName = 'Arial';
style.MainTitleSize = 15;
style.SubTitleSize = 10;
style.AxisFontSize = 8;
style.PanelLabelSize = 9;

% 每个“tile”的固定尺寸
style.TileWidthPx = 390;
style.TileHeightPx = 260;

% 关键：固定实际像素间距
style.HorizontalGapPx = 12;
style.VerticalGapPx = 42;

% 外边距
style.LeftMarginPx = 22;
style.RightMarginPx = 20;
style.TopMarginPx = 48;
style.BottomMarginPx = 22;

% tile内部布局
style.TitleReservePx = 18;
style.LabelReservePx = 26;

% colorbar
style.ColorbarGapPx = 5;
style.ColorbarWidthPx = 12;

style.ExportResolution = 400;
end

%% =========================================================
%% G01 / MSU01：2×3
%% =========================================================
function makeTwoRowFigure(dataDir,datasetName,saveFile,style)

[plvC,plvP,plvD,names] = ...
    readImportantMatrices(fullfile(dataDir,'PLV_important_connectivity.xlsx'));

[gcC,gcP,gcD,~] = ...
    readImportantMatrices(fullfile(dataDir,'Granger_important_connectivity.xlsx'));

nRows = 2;
nCols = 3;

[fig,figW,figH] = createFigure(style,nRows,nCols);

addMainTitle(fig,datasetName + " | Important PLV and Granger Connections", ...
    style,figW,figH);

plvMeanLim = commonPositiveLimit(plvC,plvP);
plvDiffLim = symmetricLimit(plvD);

gcMeanLim = commonPositiveLimit(gcC,gcP);
gcDiffLim = symmetricLimit(gcD);

row1 = {
    plvC, 'PLV - Control', [0 plvMeanLim], false, '(a)';
    plvP, 'PLV - Patient', [0 plvMeanLim], false, '(b)';
    plvD, 'PLV - Patient - Control', [-plvDiffLim plvDiffLim], true, '(c)'};

row2 = {
    gcC, 'Granger - Control', [0 gcMeanLim], false, '(d)';
    gcP, 'Granger - Patient', [0 gcMeanLim], false, '(e)';
    gcD, 'Granger - Patient - Control', [-gcDiffLim gcDiffLim], true, '(f)'};

drawRow(fig,1,nRows,nCols,row1,names,style,figW,figH);
drawRow(fig,2,nRows,nCols,row2,names,style,figW,figH);

drawnow;
exportgraphics(fig,saveFile,'Resolution',style.ExportResolution);
close(fig);

fprintf('%s 完成：%s\n',datasetName,saveFile);
end

%% =========================================================
%% MPHCED02：4×3
%% =========================================================
function makeMPHCEDFigure(ecDir,eoDir,saveFile,style)

[ecPlvC,ecPlvP,ecPlvD,names] = ...
    readImportantMatrices(fullfile(ecDir,'PLV_important_connectivity.xlsx'));
[ecGcC,ecGcP,ecGcD,~] = ...
    readImportantMatrices(fullfile(ecDir,'Granger_important_connectivity.xlsx'));

[eoPlvC,eoPlvP,eoPlvD,~] = ...
    readImportantMatrices(fullfile(eoDir,'PLV_important_connectivity.xlsx'));
[eoGcC,eoGcP,eoGcD,~] = ...
    readImportantMatrices(fullfile(eoDir,'Granger_important_connectivity.xlsx'));

nRows = 4;
nCols = 3;

[fig,figW,figH] = createFigure(style,nRows,nCols);

addMainTitle(fig,'MPHCED02 | Important PLV and Granger Connections', ...
    style,figW,figH);

plvMeanLim = max( ...
    commonPositiveLimit(ecPlvC,ecPlvP), ...
    commonPositiveLimit(eoPlvC,eoPlvP));

plvDiffLim = max( ...
    symmetricLimit(ecPlvD), ...
    symmetricLimit(eoPlvD));

gcMeanLim = max( ...
    commonPositiveLimit(ecGcC,ecGcP), ...
    commonPositiveLimit(eoGcC,eoGcP));

gcDiffLim = max( ...
    symmetricLimit(ecGcD), ...
    symmetricLimit(eoGcD));

row1 = {
    ecPlvC, 'EC - PLV - Control', [0 plvMeanLim], false, '(a)';
    ecPlvP, 'EC - PLV - Patient', [0 plvMeanLim], false, '(b)';
    ecPlvD, 'EC - PLV - Patient - Control', [-plvDiffLim plvDiffLim], true, '(c)'};

row2 = {
    ecGcC, 'EC - Granger - Control', [0 gcMeanLim], false, '(d)';
    ecGcP, 'EC - Granger - Patient', [0 gcMeanLim], false, '(e)';
    ecGcD, 'EC - Granger - Patient - Control', [-gcDiffLim gcDiffLim], true, '(f)'};

row3 = {
    eoPlvC, 'EO - PLV - Control', [0 plvMeanLim], false, '(g)';
    eoPlvP, 'EO - PLV - Patient', [0 plvMeanLim], false, '(h)';
    eoPlvD, 'EO - PLV - Patient - Control', [-plvDiffLim plvDiffLim], true, '(i)'};

row4 = {
    eoGcC, 'EO - Granger - Control', [0 gcMeanLim], false, '(j)';
    eoGcP, 'EO - Granger - Patient', [0 gcMeanLim], false, '(k)';
    eoGcD, 'EO - Granger - Patient - Control', [-gcDiffLim gcDiffLim], true, '(l)'};

drawRow(fig,1,nRows,nCols,row1,names,style,figW,figH);
drawRow(fig,2,nRows,nCols,row2,names,style,figW,figH);
drawRow(fig,3,nRows,nCols,row3,names,style,figW,figH);
drawRow(fig,4,nRows,nCols,row4,names,style,figW,figH);

drawnow;
exportgraphics(fig,saveFile,'Resolution',style.ExportResolution);
close(fig);

fprintf('MPHCED02 完成：%s\n',saveFile);
end

%% =========================================================
%% Figure尺寸：由固定tile尺寸和固定gap计算
%% =========================================================
function [fig,figW,figH] = createFigure(style,nRows,nCols)

figW = ...
    style.LeftMarginPx + ...
    nCols*style.TileWidthPx + ...
    (nCols-1)*style.HorizontalGapPx + ...
    style.RightMarginPx;

figH = ...
    style.TopMarginPx + ...
    nRows*style.TileHeightPx + ...
    (nRows-1)*style.VerticalGapPx + ...
    style.BottomMarginPx;

fig = figure( ...
    'Color','w', ...
    'Units','pixels', ...
    'Position',[60 40 figW figH], ...
    'Visible','off', ...
    'ToolBar','none', ...
    'MenuBar','none', ...
    'NumberTitle','off');
end

%% =========================================================
%% 主标题
%% =========================================================
function addMainTitle(fig,titleText,style,figW,figH)

annotation(fig,'textbox', ...
    [0, 1-style.TopMarginPx/figH, 1, style.TopMarginPx/figH], ...
    'String',titleText, ...
    'EdgeColor','none', ...
    'HorizontalAlignment','center', ...
    'VerticalAlignment','middle', ...
    'FontName',style.FontName, ...
    'FontSize',style.MainTitleSize, ...
    'FontWeight','bold');
end

%% =========================================================
%% 画一行
%% =========================================================
function drawRow(fig,rowIndex,nRows,nCols,rowSpec,names,style,figW,figH)

for colIndex = 1:nCols

    tilePx = getTilePositionPx( ...
        rowIndex,colIndex,nRows,nCols,style,figW,figH);

    % tile内部预留标题、标号、colorbar
    axPx = [ ...
        tilePx(1), ...
        tilePx(2) + style.LabelReservePx, ...
        tilePx(3) - style.ColorbarGapPx - style.ColorbarWidthPx, ...
        tilePx(4) - style.TitleReservePx - style.LabelReservePx];

    cbPx = [ ...
        axPx(1) + axPx(3) + style.ColorbarGapPx, ...
        axPx(2), ...
        style.ColorbarWidthPx, ...
        axPx(4)];

    M = rowSpec{colIndex,1};
    subtitleText = rowSpec{colIndex,2};
    limits = rowSpec{colIndex,3};
    useDiverging = rowSpec{colIndex,4};
    panelText = rowSpec{colIndex,5};

    ax = axes(fig, ...
        'Units','pixels', ...
        'Position',axPx); %#ok<LAXES>

    drawMatrix(ax,M,names,limits,useDiverging,style,cbPx);

    title(ax,subtitleText, ...
        'FontWeight','bold', ...
        'FontName',style.FontName, ...
        'FontSize',style.SubTitleSize);

    xlabel(ax,panelText, ...
        'FontName',style.FontName, ...
        'FontSize',style.PanelLabelSize, ...
        'FontWeight','bold');
end
end

%% =========================================================
%% 单个tile位置：固定像素
%% =========================================================
function pos = getTilePositionPx( ...
    rowIndex,colIndex,nRows,nCols,style,figW,figH) %#ok<INUSD>

leftPx = ...
    style.LeftMarginPx + ...
    (colIndex-1)*(style.TileWidthPx + style.HorizontalGapPx);

topOfTilePx = ...
    figH - style.TopMarginPx - ...
    (rowIndex-1)*(style.TileHeightPx + style.VerticalGapPx);

bottomPx = topOfTilePx - style.TileHeightPx;

pos = [ ...
    leftPx, ...
    bottomPx, ...
    style.TileWidthPx, ...
    style.TileHeightPx];
end

%% =========================================================
%% Excel读取
%% =========================================================
function [C,P,D,names] = readImportantMatrices(fileName)

if ~isfile(fileName)
    error(['未找到结果文件：\n%s\n' ...
        '请先运行 Generate_Important_Connectivity_Matrices_V1。'], ...
        fileName);
end

[C,names] = readMatrixSheet(fileName,'ControlImportant');
[P,~] = readMatrixSheet(fileName,'PatientImportant');
[D,~] = readMatrixSheet(fileName,'DifferenceImportant');
end

function [M,names] = readMatrixSheet(fileName,sheetName)

T = readtable(fileName, ...
    'Sheet',sheetName, ...
    'ReadRowNames',true, ...
    'VariableNamingRule','preserve');

names = T.Properties.RowNames;
M = table2array(T);
end

%% =========================================================
%% 矩阵绘制
%% =========================================================
function drawMatrix(ax,M,names,limits,useDiverging,style,cbPx)

imagesc(ax,M,'AlphaData',~isnan(M));
axis(ax,'square');

set(ax, ...
    'Color',[1 1 1], ...
    'XTick',1:numel(names), ...
    'YTick',1:numel(names), ...
    'XTickLabel',names, ...
    'YTickLabel',names, ...
    'XTickLabelRotation',45, ...
    'FontName',style.FontName, ...
    'FontSize',style.AxisFontSize, ...
    'TickLength',[0 0], ...
    'LineWidth',0.7, ...
    'Box','on');

try
    ax.Toolbar.Visible = 'off';
catch
end

try
    disableDefaultInteractivity(ax);
catch
end

if useDiverging
    colormap(ax,blueWhiteRed(256));
else
    colormap(ax,parula(256));
end

caxis(ax,limits);

cb = colorbar(ax);
cb.Units = 'pixels';
cb.Position = cbPx;
cb.FontName = style.FontName;
cb.FontSize = style.AxisFontSize;
cb.LineWidth = 0.7;
end

%% =========================================================
%% 色标范围
%% =========================================================
function lim = commonPositiveLimit(A,B)

values = [A(~isnan(A)); B(~isnan(B))];

if isempty(values)
    lim = 1;
    return;
end

lim = max(values);

if ~isfinite(lim) || lim<=0
    lim = 1;
end
end

function lim = symmetricLimit(A)

values = abs(A(~isnan(A)));

if isempty(values)
    lim = 1;
    return;
end

lim = max(values);

if ~isfinite(lim) || lim<=0
    lim = 1;
end
end

%% =========================================================
%% 红-白-蓝色图
%% =========================================================
function cmap = blueWhiteRed(m)

if nargin<1
    m = 256;
end

x = [0 0.5 1];

r = interp1(x,[0 1 1],linspace(0,1,m));
g = interp1(x,[0 1 0],linspace(0,1,m));
b = interp1(x,[1 1 0],linspace(0,1,m));

cmap = [r(:) g(:) b(:)];
end
