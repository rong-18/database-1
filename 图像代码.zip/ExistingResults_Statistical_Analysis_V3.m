function ExistingResults_Statistical_Analysis_V3
% 现有结果统计增强分析
%
% 重要：
% 1) 只读取现有 MAT/XLSX；
% 2) 不重新提取特征；
% 3) 不重新训练任何分类器；
% 4) Bootstrap / permutation 仅对已经保存的“受试者级预测结果”重采样。
%
% 分析：
% A. 1/2/5 s 各最终代表模型：受试者级 Bootstrap 95% CI
% B. 同一场景 5 s vs 1 s / 2 s：配对统计
%    - Delta Balanced Accuracy：分层配对 Bootstrap CI + permutation p
%    - Delta AUC：分层配对 Bootstrap CI + permutation p
%    - Accuracy：McNemar exact p
%    - BH-FDR 校正
% C. 已保存的消融预测：Baseline vs Ablation 配对统计
% D. G01 / MPHCED02 Fisher 特征选择稳定性（严格按Condition/N/特征维数核对）
%    - 选择频率
%    - pairwise Jaccard
%    - Kuncheva index（若每折固定 Top-K 且保存了 SelectedIndices）
%
% 输出：
% D:\Database\EEG_Paper_Figures\ExistingResults_Statistics
%   ExistingResults_Statistical_Analysis.xlsx
%   Fig_5s_FinalModels_95CI.png
%   Fig_TimeScale_DeltaBA.png
%   Fig_Ablation_Module_DeltaBA.png
%   Fig_Ablation_Entropy_DeltaBA.png
%   Fig_Ablation_Fisher_DeltaBA.png
%   Fig_Fisher_Stability.png
%   ExistingResults_Statistics_Log.txt
%
% 需要：
% Statistics and Machine Learning Toolbox（仅用于已有环境兼容；
% 本程序没有训练模型）

clc;
close all;
rng(20260915,'twister');

%% =========================================================
%% 路径与参数
%% =========================================================
roots.G01 = { ...
    'D:\Database\Seizure\SAHARAN12\G01', ...
    'D:\Database\Seizure\SAHARAN\SAHARAN12\G01'};
roots.MPHCED02 = {'D:\Database\Depression\MPHCED\MPHCED02'};
roots.MSU01 = {'D:\Database\Schizophrenia\MSU\MSU01'};

outDir = 'D:\Database\EEG_Paper_Figures\ExistingResults_Statistics';
if ~exist(outDir,'dir')
    mkdir(outDir);
end

xlsxFile = fullfile(outDir,'ExistingResults_Statistical_Analysis.xlsx');
logFile = fullfile(outDir,'ExistingResults_Statistics_Log.txt');

if isfile(xlsxFile), delete(xlsxFile); end
if isfile(logFile), delete(logFile); end

diary(logFile);
cleanupDiary = onCleanup(@() diary('off')); %#ok<NASGU>

nBootstrap = 2000;
nPermutation = 5000;
alpha = 0.05;

fprintf('====================================================\n');
fprintf('现有结果统计增强分析\n');
fprintf('不重新训练任何模型。\n');
fprintf('Bootstrap = %d；Permutation = %d\n',nBootstrap,nPermutation);
fprintf('====================================================\n\n');

%% =========================================================
%% 论文最终使用的15个“场景×尺度代表模型”
%% 用目标 BA/AUC 仅用于从多个历史结果中识别正确版本。
%% =========================================================
spec = makeMainSpec();

%% =========================================================
%% 搜索三个结果目录中的“结果型 MAT”
%% =========================================================
records = struct([]);
sourceRows = {};

datasetNames = {'G01','MPHCED02','MSU01'};

for d = 1:numel(datasetNames)
    dataset = datasetNames{d};
    rootDirs = roots.(dataset);

    fprintf('\n扫描 %s：\n',dataset);
    for rr = 1:numel(rootDirs)
        fprintf('  %s\n',rootDirs{rr});
    end

    files = findResultMatFiles(rootDirs);
    fprintf('找到 %d 个候选结果 MAT/XLSX。\n',numel(files));

    for f = 1:numel(files)
        filePath = files{f};

        try
            rec = parsePredictionFile(filePath,dataset);
        catch ME
            fprintf('跳过：%s\n  %s\n',filePath,ME.message);
            continue;
        end

        if ~isempty(rec)
            records = appendStruct(records,rec); %#ok<AGROW>
            sourceRows(end+1,:) = {dataset,filePath,numel(rec)}; %#ok<AGROW>
        end
    end
end

if isempty(records)
    error('没有从三个目录中读取到任何受试者级预测结果。');
end

fprintf('\n共解析出 %d 组预测记录。\n',numel(records));

%% =========================================================
%% 匹配最终15个代表实验
%% =========================================================
mainRecords = struct([]);
missingRows = {};

for i = 1:height(spec)
    [r,found] = findBestRecord(records,spec(i,:));

    if found
        mainRecords = appendStruct(mainRecords,r); %#ok<AGROW>

        m = calculateMetrics(r.TrueLabel,r.PredictedLabel,r.Score);
        fprintf(['匹配：%-18s %ds %-10s ' ...
            'BA=%.4f AUC=%.4f\n'], ...
            spec.Scene{i},spec.ScaleSec(i),spec.Classifier{i}, ...
            m.BalancedAccuracy,m.AUC);
    else
        missingRows(end+1,:) = { ...
            spec.Scene{i},spec.ScaleSec(i),spec.Classifier{i}}; %#ok<AGROW>
        fprintf('未找到：%s %ds %s\n', ...
            spec.Scene{i},spec.ScaleSec(i),spec.Classifier{i});
    end
end

%% =========================================================
%% A. 各代表模型 Bootstrap 95% CI
%% =========================================================
fprintf('\n[A] Bootstrap 95%% CI...\n');

ciRows = cell(numel(mainRecords),1);

for i = 1:numel(mainRecords)
    r = mainRecords(i);

    m = calculateMetrics(r.TrueLabel,r.PredictedLabel,r.Score);

    CI = bootstrapMetrics( ...
        r.TrueLabel,r.PredictedLabel,r.Score, ...
        nBootstrap,alpha);

    ciRows{i} = table( ...
        string(r.Scene),r.ScaleSec,string(displayClassifier(r.Classifier)), ...
        numel(r.TrueLabel), ...
        m.Accuracy,CI.Accuracy(1),CI.Accuracy(2), ...
        m.BalancedAccuracy,CI.BalancedAccuracy(1),CI.BalancedAccuracy(2), ...
        m.MCC,CI.MCC(1),CI.MCC(2), ...
        m.AUC,CI.AUC(1),CI.AUC(2), ...
        string(r.SourceFile), ...
        'VariableNames',{ ...
        'Scene','ScaleSec','Classifier','N', ...
        'Accuracy','Accuracy_CI_L','Accuracy_CI_U', ...
        'BalancedAccuracy','BA_CI_L','BA_CI_U', ...
        'MCC','MCC_CI_L','MCC_CI_U', ...
        'AUC','AUC_CI_L','AUC_CI_U','SourceFile'});
end

if ~isempty(ciRows)
    ciTable = vertcat(ciRows{:});
    writetable(ciTable,xlsxFile,'Sheet','AllScale_95CI');
else
    ciTable = table();
end

%% =========================================================
%% B. 5 s vs 1 s / 2 s 配对比较
%% =========================================================
fprintf('\n[B] 时间尺度配对比较...\n');

sceneOrder = {'SAHARAN12-G01','MSU01', ...
    'MPHCED02-EC','MPHCED02-EO','MPHCED02-EC+EO'};

pairRows = {};

for s = 1:numel(sceneOrder)
    scene = sceneOrder{s};

    r5 = getMainRecord(mainRecords,scene,5);
    if isempty(r5)
        continue;
    end

    for otherScale = [1 2]
        r0 = getMainRecord(mainRecords,scene,otherScale);
        if isempty(r0)
            continue;
        end

        [a,b,ok] = alignPairedRecords(r5,r0);
        if ~ok
            fprintf('无法配对：%s，5s vs %ds\n',scene,otherScale);
            continue;
        end

        S = pairedComparison( ...
            a.TrueLabel, ...
            a.PredictedLabel,a.Score, ...
            b.PredictedLabel,b.Score, ...
            nBootstrap,nPermutation,alpha);

        pairRows(end+1,:) = { ...
            scene,5,otherScale,numel(a.TrueLabel), ...
            S.BA_A,S.BA_B,S.DeltaBA,S.DeltaBA_CI(1),S.DeltaBA_CI(2), ...
            S.P_BA,S.McNemarP, ...
            S.AUC_A,S.AUC_B,S.DeltaAUC,S.DeltaAUC_CI(1),S.DeltaAUC_CI(2), ...
            S.P_AUC}; %#ok<AGROW>
    end
end

if ~isempty(pairRows)
    timeTable = cell2table(pairRows, ...
        'VariableNames',{ ...
        'Scene','ScaleA','ScaleB','N', ...
        'BA_A','BA_B','DeltaBA','DeltaBA_CI_L','DeltaBA_CI_U', ...
        'P_BA','McNemarP', ...
        'AUC_A','AUC_B','DeltaAUC','DeltaAUC_CI_L','DeltaAUC_CI_U', ...
        'P_AUC'});

    timeTable.P_BA_FDR = bhFDR(timeTable.P_BA);
    timeTable.P_AUC_FDR = bhFDR(timeTable.P_AUC);

    writetable(timeTable,xlsxFile,'Sheet','TimeScale_Paired');
else
    timeTable = table();
end

%% =========================================================
%% C. 消融预测的配对统计
%% =========================================================
fprintf('\n[C] 搜索消融预测并做配对统计...\n');

ablationRows = {};

for d = 1:numel(datasetNames)
    dataset = datasetNames{d};
    rootDirs = roots.(dataset);

    files = findAblationMatFiles(rootDirs,dataset);

    for f = 1:numel(files)
        try
            comparisons = parseAblationComparisons( ...
                files{f},dataset,nBootstrap,nPermutation,alpha);
        catch ME
            fprintf('消融文件跳过：%s\n  %s\n',files{f},ME.message);
            continue;
        end

        if ~isempty(comparisons)
            ablationRows = [ablationRows; comparisons]; %#ok<AGROW>
        end
    end
end

if ~isempty(ablationRows)
    ablationTable = cell2table(ablationRows, ...
        'VariableNames',{ ...
        'Dataset','SourceFile','Baseline','Ablation','N', ...
        'BA_Baseline','BA_Ablation','DeltaBA', ...
        'DeltaBA_CI_L','DeltaBA_CI_U','P_BA','McNemarP', ...
        'AUC_Baseline','AUC_Ablation','DeltaAUC', ...
        'DeltaAUC_CI_L','DeltaAUC_CI_U','P_AUC'});

    % 去除完全重复行
    [~,u] = unique( ...
        strcat(string(ablationTable.Dataset),"|", ...
        string(ablationTable.SourceFile),"|", ...
        string(ablationTable.Baseline),"|", ...
        string(ablationTable.Ablation)), ...
        'stable');
    ablationTable = ablationTable(u,:);

    ablationTable.P_BA_FDR = bhFDR(ablationTable.P_BA);
    ablationTable.P_AUC_FDR = bhFDR(ablationTable.P_AUC);

    writetable(ablationTable,xlsxFile,'Sheet','Ablation_Paired');
else
    ablationTable = table();
    fprintf('没有找到能够做受试者级配对检验的消融预测表。\n');
end

%% =========================================================
%% D. Fisher 选择稳定性
%% =========================================================
fprintf('\n[D] Fisher 特征选择稳定性...\n');

stabilitySummary = {};
topFeatureRows = {};

fisherTargets = { ...
    'G01','SAHARAN12-G01',5,'RBFSVM',50; ...
    'MPHCED02','MPHCED02-EC+EO',5,'LDA',15};

for i = 1:size(fisherTargets,1)
    dataset = fisherTargets{i,1};
    scene = fisherTargets{i,2};
    scaleSec = fisherTargets{i,3};
    classifier = fisherTargets{i,4};
    topK = fisherTargets{i,5};

    r = getMainRecord(mainRecords,scene,scaleSec);
    if isempty(r)
        continue;
    end

    try
        F = extractFisherStability( ...
            r.SourceFile,scene,scaleSec,classifier,topK);
    catch ME
        fprintf('Fisher 稳定性跳过 %s：%s\n',scene,ME.message);
        continue;
    end

    if isempty(F)
        continue;
    end

    stabilitySummary(end+1,:) = { ...
        scene,F.NumFolds,F.TotalFeatures,F.TopK, ...
        F.MeanJaccard,F.MedianJaccard,F.MeanKuncheva}; %#ok<AGROW>

    topN = min(30,numel(F.Frequency));
    [freqSorted,ord] = sort(F.Frequency,'descend');

    for k = 1:topN
        idx = ord(k);
        topFeatureRows(end+1,:) = { ...
            scene,idx,string(F.FeatureNames{idx}), ...
            string(featureModule(F.FeatureNames{idx})), ...
            freqSorted(k),freqSorted(k)/F.NumFolds}; %#ok<AGROW>
    end
end

if ~isempty(stabilitySummary)
    stabilityTable = cell2table(stabilitySummary, ...
        'VariableNames',{ ...
        'Scene','NumFolds','TotalFeatures','TopK', ...
        'MeanJaccard','MedianJaccard','MeanKuncheva'});
    writetable(stabilityTable,xlsxFile,'Sheet','Fisher_Stability');
else
    stabilityTable = table();
end

if ~isempty(topFeatureRows)
    topFeatureTable = cell2table(topFeatureRows, ...
        'VariableNames',{ ...
        'Scene','FeatureIndex','FeatureName','Module', ...
        'SelectedFoldCount','SelectedFoldFraction'});
    writetable(topFeatureTable,xlsxFile,'Sheet','Fisher_TopFeatures');
else
    topFeatureTable = table();
end

%% =========================================================
%% 高维背景表
%% =========================================================
dimTable = table( ...
    string({'SAHARAN12-G01';'MPHCED02-EC+EO';'MSU01'}), ...
    [97;56;84], ...
    [343;2432;440], ...
    [50;15;440], ...
    [343/97;2432/56;440/84], ...
    100*[1-50/343;1-15/2432;0], ...
    'VariableNames',{ ...
    'Scene','N','OriginalDim','FinalDim','P_over_N','CompressionPercent'});

writetable(dimTable,xlsxFile,'Sheet','Dimensionality');

%% =========================================================
%% 数据来源与缺失项
%% =========================================================
if ~isempty(sourceRows)
    sourceTable = cell2table(sourceRows, ...
        'VariableNames',{'Dataset','SourceFile','ParsedRecords'});
    writetable(sourceTable,xlsxFile,'Sheet','Parsed_Sources');
end

if ~isempty(missingRows)
    missingTable = cell2table(missingRows, ...
        'VariableNames',{'Scene','ScaleSec','Classifier'});
    writetable(missingTable,xlsxFile,'Sheet','Missing_MainRecords');

    fprintf('\n警告：仍有 %d 个论文主记录未找到。\n',height(missingTable));
    disp(missingTable);
else
    fprintf('\n15 个论文主记录已全部找到。\n');
end

%% =========================================================
%% 论文图
%% =========================================================
if ~isempty(ciTable)
    plotFinal5sCI(ciTable,fullfile(outDir,'Fig_5s_FinalModels_95CI.png'));
end

if ~isempty(timeTable)
    plotDeltaBA( ...
        timeTable,'Time-scale comparison: 5 s vs 1/2 s', ...
        fullfile(outDir,'Fig_TimeScale_DeltaBA.png'));
end

if ~isempty(ablationTable)
    plotAblationDeltaBAByType( ...
        ablationTable,"module", ...
        fullfile(outDir,'Fig_Ablation_Module_DeltaBA.png'));

    plotAblationDeltaBAByType( ...
        ablationTable,"entropy", ...
        fullfile(outDir,'Fig_Ablation_Entropy_DeltaBA.png'));

    plotAblationDeltaBAByType( ...
        ablationTable,"fisher", ...
        fullfile(outDir,'Fig_Ablation_Fisher_DeltaBA.png'));
end

if ~isempty(topFeatureTable)
    plotFisherStability( ...
        topFeatureTable, ...
        fullfile(outDir,'Fig_Fisher_Stability.png'));
end

fprintf('\n====================================================\n');
fprintf('统计分析完成。\n');
fprintf('Excel：%s\n',xlsxFile);
fprintf('图目录：%s\n',outDir);
fprintf('日志：%s\n',logFile);
fprintf('====================================================\n');
end

%% =========================================================
%% 主实验规格
%% =========================================================
function T = makeMainSpec()

Scene = string({ ...
    'SAHARAN12-G01';'SAHARAN12-G01';'SAHARAN12-G01'; ...
    'MSU01';'MSU01';'MSU01'; ...
    'MPHCED02-EC';'MPHCED02-EC';'MPHCED02-EC'; ...
    'MPHCED02-EO';'MPHCED02-EO';'MPHCED02-EO'; ...
    'MPHCED02-EC+EO';'MPHCED02-EC+EO';'MPHCED02-EC+EO'});

ScaleSec = [1;2;5; 1;2;5; 1;2;5; 1;2;5; 1;2;5];

Classifier = string({ ...
    'RBFSVM';'RBFSVM';'RBFSVM'; ...
    'RBFSVM';'LDA';'Logistic'; ...
    'LDA';'KNN';'RBFSVM'; ...
    'LDA';'LinearSVM';'RF'; ...
    'LinearSVM';'RBFSVM';'LDA'});

TargetBA = [ ...
    .7943;.8161;.8476; ...
    .9009;.8897;.9171; ...
    .8083;.7774;.9131; ...
    .8966;.9343;.8858; ...
    .9087;.9100;.9285];

TargetAUC = [ ...
    .891;.894;.893; ...
    .950;.946;.948; ...
    .871;.806;.932; ...
    .926;.964;.894; ...
    .935;.937;.885];

TargetN = [ ...
    97;97;97; ...
    84;84;84; ...
    58;58;58; ...
    61;61;61; ...
    56;56;56];

T = table(Scene,ScaleSec,Classifier,TargetBA,TargetAUC,TargetN);
end

%% =========================================================
%% 搜索结果 MAT
%% =========================================================
function files = findResultMatFiles(rootDirs)

if ischar(rootDirs) || isstring(rootDirs)
    rootDirs = cellstr(rootDirs);
end

files = {};

for r = 1:numel(rootDirs)
    rootDir = rootDirs{r};
    if ~isfolder(rootDir)
        continue;
    end

    Dmat = dir(fullfile(rootDir,'**','*.mat'));
    Dxlsx = dir(fullfile(rootDir,'**','*.xlsx'));
    D = [Dmat; Dxlsx];

    for i = 1:numel(D)
        name = lower(D(i).name);
        fullName = fullfile(D(i).folder,D(i).name);

        if startsWith(D(i).name,'~$') || ...
           contains(name,'feature_cache') || ...
           contains(name,'subject_feature') || ...
           contains(name,'feature_names') || ...
           contains(name,'quality_report') || ...
           contains(name,'mapping') || ...
           contains(name,'statistics') || ...
           contains(name,'summary') || ...
           contains(name,'data.mat') || ...
           contains(name,'label') || ...
           D(i).bytes > 8e8
            continue;
        end

        if contains(name,'result') || ...
           contains(name,'lopo') || ...
           contains(name,'prediction') || ...
           contains(name,'ablation') || ...
           contains(name,'nofisher') || ...
           contains(name,'experiment')
            files{end+1,1} = fullName; %#ok<AGROW>
        end
    end
end

files = unique(files,'stable');
end

function files = findAblationMatFiles(rootDirs,dataset)
% 只选择当前数据集最可能的“最终5 s消融结果”文件，避免旧版本混入。

allFiles = findResultMatFiles(rootDirs);
candidates = {};
scores = [];
dates = [];

for i = 1:numel(allFiles)
    [~,name,ext] = fileparts(allFiles{i});
    if ~strcmpi(ext,'.mat')
        continue;
    end

    p = lower(allFiles{i});
    n = lower(name);

    if ~(contains(p,'ablation') || contains(p,'消融'))
        continue;
    end

    score = 0;
    if contains(n,'5s') || contains(n,'5_s'), score = score + 10; end
    if contains(n,'ablation'), score = score + 5; end

    switch upper(dataset)
        case 'G01'
            if contains(n,'g01'), score = score + 5; end
        case 'MPHCED02'
            if contains(n,'mphced02'), score = score + 5; end
            if contains(n,'lda'), score = score + 4; end
        case 'MSU01'
            if contains(n,'msu01'), score = score + 5; end
            if contains(n,'logistic'), score = score + 4; end
            if contains(n,'nofisher'), score = score + 4; end
    end

    info = dir(allFiles{i});
    candidates{end+1,1} = allFiles{i}; %#ok<AGROW>
    scores(end+1,1) = score; %#ok<AGROW>
    dates(end+1,1) = info.datenum; %#ok<AGROW>
end

if isempty(candidates)
    files = {};
    return;
end

ranking = [-scores,-dates];
[~,ord] = sortrows(ranking,[1 2]);
files = candidates(ord(1));

fprintf('  %s 消融统计仅使用：%s\n',dataset,files{1});
end

%% =========================================================
%% 解析预测结果文件
%% =========================================================
function records = parsePredictionFile(filePath,dataset)

records = struct([]);
[~,~,ext] = fileparts(filePath);

if strcmpi(ext,'.xlsx')
    try
        sheets = sheetnames(filePath);
    catch
        sheets = "Sheet1";
    end

    for s = 1:numel(sheets)
        try
            T = readtable(filePath,'Sheet',sheets(s), ...
                'VariableNamingRule','preserve');
            records = appendStruct(records, ...
                recordsFromPredictionTable(T,filePath,dataset));
        catch
        end
    end
    return;
end

info = whos('-file',filePath);
names = string({info.name});

if any(names=="predictionTable")
    S = load(filePath,'predictionTable');
    records = appendStruct(records, ...
        recordsFromPredictionTable(S.predictionTable,filePath,dataset));
end

for varName = ["results","allResults","bestResult"]
    if any(names==varName)
        S = load(filePath,char(varName));
        items = flattenResultItems(S.(char(varName)));

        for i = 1:numel(items)
            r = recordFromResultStruct(items{i},filePath,dataset);
            if ~isempty(r)
                records = appendStruct(records,r);
            end
        end
    end
end
end

function records = recordsFromPredictionTable(T,filePath,dataset)

records = struct([]);
if ~istable(T)
    return;
end

v = string(T.Properties.VariableNames);

trueVar = findTableVariable(v, ...
    ["TrueLabel","SubjectTrueLabel","True_Label","Label"]);
predVar = findTableVariable(v, ...
    ["PredictedLabel","SubjectPredictedLabel","PredLabel","Prediction"]);
scoreVar = findTableVariable(v, ...
    ["PatientScore","SubjectPatientScore","Score","DecisionScore"]);

if strlength(trueVar)==0 || strlength(predVar)==0 || strlength(scoreVar)==0
    return;
end

condition = repmat("",height(T),1);
scale = nan(height(T),1);
classifier = repmat("",height(T),1);
configuration = repmat("",height(T),1);
subjectID = string((1:height(T))');

if ismember("Condition",v), condition = string(T.Condition); end
if ismember("ScaleSec",v), scale = double(T.ScaleSec); end
if ismember("Classifier",v), classifier = string(T.Classifier); end
if ismember("Configuration",v), configuration = string(T.Configuration); end
if ismember("Ablation",v), configuration = string(T.Ablation); end
if ismember("SubjectID",v), subjectID = string(T.SubjectID); end

repeatKey = repmat("",height(T),1);
if ismember("Repeat",v)
    repeatKey = string(T.Repeat);
elseif ismember("RepeatIndex",v)
    repeatKey = string(T.RepeatIndex);
elseif ismember("Run",v)
    repeatKey = string(T.Run);
end

groupKey = condition+"|"+string(scale)+"|"+classifier+"|"+configuration+"|"+repeatKey;
groups = unique(groupKey,'stable');

for g = 1:numel(groups)
    mask = groupKey==groups(g);

    if sum(mask)<4
        continue;
    end

    scene = inferScene(dataset,condition(find(mask,1)));

    trueColumn = T.(char(trueVar));
    predColumn = T.(char(predVar));
    scoreColumn = T.(char(scoreVar));

    r = makeRecord( ...
        dataset,scene, ...
        firstFinite(scale(mask)), ...
        firstNonempty(classifier(mask)), ...
        firstNonempty(configuration(mask)), ...
        double(trueColumn(mask)), ...
        double(predColumn(mask)), ...
        double(scoreColumn(mask)), ...
        subjectID(mask),filePath);

    records = appendStruct(records,r);
end
end

function r = recordFromResultStruct(x,filePath,dataset)

r = struct([]);
if ~isstruct(x)
    return;
end

[y,pred,score] = getPredictionFields(x);
if isempty(y) || isempty(pred) || isempty(score)
    return;
end

condition = getStringField(x,{'Condition','State'},'');
scaleSec = getNumericField(x,{'ScaleSec','WindowSec'},NaN);
classifier = getStringField(x,{'Classifier','ClassifierCode'},'');
configuration = getStringField(x,{'Configuration','Ablation'},'');

subjectID = string((1:numel(y))');
if isfield(x,'SubjectIDs')
    subjectID = string(x.SubjectIDs(:));
elseif isfield(x,'SubjectID')
    subjectID = string(x.SubjectID(:));
end

scene = inferScene(dataset,condition);

r = makeRecord( ...
    dataset,scene,scaleSec,classifier,configuration, ...
    y,pred,score,subjectID,filePath);
end

function [y,pred,score] = getPredictionFields(x)

y = [];
pred = [];
score = [];

if isfield(x,'TrueLabel'), y = double(x.TrueLabel(:)); end
if isempty(y) && isfield(x,'SubjectTrueLabel')
    y = double(x.SubjectTrueLabel(:));
end

if isfield(x,'PredictedLabel')
    pred = double(x.PredictedLabel(:));
elseif isfield(x,'PredLabel')
    pred = double(x.PredLabel(:));
elseif isfield(x,'SubjectPredictedLabel')
    pred = double(x.SubjectPredictedLabel(:));
end

if isfield(x,'PatientScore')
    score = double(x.PatientScore(:));
elseif isfield(x,'Score')
    score = double(x.Score(:));
elseif isfield(x,'SubjectPatientScore')
    score = double(x.SubjectPatientScore(:));
end

if ~(numel(y)==numel(pred) && numel(y)==numel(score))
    y=[]; pred=[]; score=[];
end
end

function items = flattenResultItems(x)

items = {};

if iscell(x)
    for i = 1:numel(x)
        items = [items,flattenResultItems(x{i})]; %#ok<AGROW>
    end
elseif isstruct(x)
    for i = 1:numel(x)
        items{end+1} = x(i); %#ok<AGROW>

        fn = fieldnames(x(i));
        for k = 1:numel(fn)
            value = x(i).(fn{k});
            if iscell(value) || ...
                    (isstruct(value) && numel(value)>1)
                items = [items,flattenResultItems(value)]; %#ok<AGROW>
            end
        end
    end
end
end

function r = makeRecord( ...
    dataset,scene,scale,classifier,configuration, ...
    y,pred,score,subjectID,filePath)

r = struct();
r.Dataset = char(dataset);
r.Scene = char(scene);
r.ScaleSec = double(scale);
r.Classifier = char(classifier);
r.Configuration = char(configuration);
r.TrueLabel = double(y(:));
r.PredictedLabel = double(pred(:));
r.Score = double(score(:));
r.SubjectID = string(subjectID(:));
r.SourceFile = char(filePath);
end

%% =========================================================
%% 匹配论文最终记录
%% =========================================================
function [best,found] = findBestRecord(records,specRow)

best = struct([]);
found = false;
bestDistance = inf;

targetScene = normalizeScene(specRow.Scene);
targetClassifier = normalizeClassifier(specRow.Classifier);

for i = 1:numel(records)
    r = records(i);

    if normalizeScene(r.Scene)~=targetScene
        continue;
    end

    if isfinite(r.ScaleSec) && r.ScaleSec~=specRow.ScaleSec
        continue;
    end

    if strlength(normalizeClassifier(r.Classifier))>0 && ...
            normalizeClassifier(r.Classifier)~=targetClassifier
        continue;
    end

    % 主实验优先：若有 Configuration，则只接受空或 Baseline
    cfg = lower(string(r.Configuration));
    if strlength(cfg)>0 && ~contains(cfg,'baseline')
        continue;
    end

    % 必须是受试者级记录，避免把窗口级或多重复拼接结果误当主结果。
    if numel(r.TrueLabel)~=specRow.TargetN
        continue;
    end

    m = calculateMetrics(r.TrueLabel,r.PredictedLabel,r.Score);
    distance = ...
        abs(m.BalancedAccuracy-specRow.TargetBA) + ...
        abs(m.AUC-specRow.TargetAUC);

    if distance<bestDistance
        bestDistance = distance;
        best = r;
        found = true;
    end
end

if found
    best.Scene = char(specRow.Scene);
    best.ScaleSec = specRow.ScaleSec;
    best.Classifier = char(specRow.Classifier);
end
end

function r = getMainRecord(records,scene,scaleSec)

r = struct([]);

for i = 1:numel(records)
    if normalizeScene(records(i).Scene)==normalizeScene(scene) && ...
            records(i).ScaleSec==scaleSec
        r = records(i);
        return;
    end
end
end

%% =========================================================
%% Bootstrap CI
%% =========================================================
function CI = bootstrapMetrics(y,pred,score,B,alpha)

y = double(y(:));
pred = double(pred(:));
score = double(score(:));

boot = nan(B,4);

for b = 1:B
    idx = stratifiedBootstrapIndex(y);

    m = calculateMetrics(y(idx),pred(idx),score(idx));

    boot(b,:) = [ ...
        m.Accuracy,m.BalancedAccuracy,m.MCC,m.AUC];
end

q = [100*alpha/2,100*(1-alpha/2)];

CI.Accuracy = prctile(boot(:,1),q);
CI.BalancedAccuracy = prctile(boot(:,2),q);
CI.MCC = prctile(boot(:,3),q);
CI.AUC = prctile(boot(:,4),q);
end

function idx = stratifiedBootstrapIndex(y)

class0 = find(y==0);
class1 = find(y==1);

idx0 = class0(randi(numel(class0),numel(class0),1));
idx1 = class1(randi(numel(class1),numel(class1),1));

idx = [idx0;idx1];
idx = idx(randperm(numel(idx)));
end

%% =========================================================
%% 配对比较
%% =========================================================
function [a,b,ok] = alignPairedRecords(a,b)

ok = false;

if numel(a.TrueLabel)==numel(b.TrueLabel) && ...
        all(a.TrueLabel==b.TrueLabel) && ...
        numel(a.SubjectID)==numel(b.SubjectID)
    ok = true;
    return;
end

[common,ia,ib] = intersect(a.SubjectID,b.SubjectID,'stable');

if numel(common)<4
    return;
end

a.TrueLabel = a.TrueLabel(ia);
a.PredictedLabel = a.PredictedLabel(ia);
a.Score = a.Score(ia);
a.SubjectID = a.SubjectID(ia);

b.TrueLabel = b.TrueLabel(ib);
b.PredictedLabel = b.PredictedLabel(ib);
b.Score = b.Score(ib);
b.SubjectID = b.SubjectID(ib);

ok = all(a.TrueLabel==b.TrueLabel);
end

function S = pairedComparison( ...
    y,predA,scoreA,predB,scoreB,B,P,alpha)

mA = calculateMetrics(y,predA,scoreA);
mB = calculateMetrics(y,predB,scoreB);

deltaBoot = nan(B,2);

for b = 1:B
    idx = stratifiedBootstrapIndex(y);

    a = calculateMetrics(y(idx),predA(idx),scoreA(idx));
    c = calculateMetrics(y(idx),predB(idx),scoreB(idx));

    deltaBoot(b,:) = [ ...
        a.BalancedAccuracy-c.BalancedAccuracy, ...
        a.AUC-c.AUC];
end

q = [100*alpha/2,100*(1-alpha/2)];

observedBA = mA.BalancedAccuracy-mB.BalancedAccuracy;
observedAUC = mA.AUC-mB.AUC;

permBA = zeros(P,1);
permAUC = zeros(P,1);

for p = 1:P
    swap = rand(numel(y),1)<0.5;

    pa = predA; pb = predB;
    sa = scoreA; sb = scoreB;

    temp = pa(swap); pa(swap)=pb(swap); pb(swap)=temp;
    temp = sa(swap); sa(swap)=sb(swap); sb(swap)=temp;

    ma = calculateMetrics(y,pa,sa);
    mb = calculateMetrics(y,pb,sb);

    permBA(p) = ma.BalancedAccuracy-mb.BalancedAccuracy;
    permAUC(p) = ma.AUC-mb.AUC;
end

S = struct();
S.BA_A = mA.BalancedAccuracy;
S.BA_B = mB.BalancedAccuracy;
S.DeltaBA = observedBA;
S.DeltaBA_CI = prctile(deltaBoot(:,1),q);
S.P_BA = (1+sum(abs(permBA)>=abs(observedBA)))/(P+1);

S.AUC_A = mA.AUC;
S.AUC_B = mB.AUC;
S.DeltaAUC = observedAUC;
S.DeltaAUC_CI = prctile(deltaBoot(:,2),q);
S.P_AUC = (1+sum(abs(permAUC)>=abs(observedAUC)))/(P+1);

S.McNemarP = mcnemarExact(y,predA,predB);
end

function p = mcnemarExact(y,predA,predB)

correctA = predA(:)==y(:);
correctB = predB(:)==y(:);

b = sum(correctA & ~correctB);
c = sum(~correctA & correctB);
n = b+c;

if n==0
    p = 1;
    return;
end

k = min(b,c);
prob = 0;

for i = 0:k
    prob = prob + nchoosek(n,i)*(0.5^n);
end

p = min(1,2*prob);
end

%% =========================================================
%% 消融文件解析
%% =========================================================
function rows = parseAblationComparisons( ...
    filePath,dataset,B,P,alpha)

rows = {};

info = whos('-file',filePath);
names = string({info.name});

if ~any(names=="predictionTable")
    return;
end

S = load(filePath,'predictionTable');
T = S.predictionTable;

if ~istable(T)
    return;
end

v = string(T.Properties.VariableNames);

% ---------- 长表 ----------
if all(ismember(["TrueLabel","PredictedLabel","PatientScore"],v)) && ...
        (ismember("Configuration",v) || ismember("Ablation",v))

    if ismember("Configuration",v)
        config = string(T.Configuration);
    else
        config = string(T.Ablation);
    end

    configs = unique(config,'stable');
    baselineName = findBaselineName(configs);

    if strlength(baselineName)==0
        return;
    end

    baseMask = config==baselineName;

    for i = 1:numel(configs)
        if configs(i)==baselineName
            continue;
        end

        testMask = config==configs(i);

        [y,pb,sb,pa,sa,ok] = alignTableConfigurations( ...
            T,baseMask,testMask);

        if ~ok
            continue;
        end

        Scomp = pairedComparison(y,pb,sb,pa,sa,B,P,alpha);
        mb = calculateMetrics(y,pb,sb);
        ma = calculateMetrics(y,pa,sa);

        rows(end+1,:) = { ...
            dataset,filePath,char(baselineName),char(configs(i)), ...
            numel(y), ...
            mb.BalancedAccuracy,ma.BalancedAccuracy, ...
            ma.BalancedAccuracy-mb.BalancedAccuracy, ...
            -Scomp.DeltaBA_CI(2),-Scomp.DeltaBA_CI(1), ...
            Scomp.P_BA,Scomp.McNemarP, ...
            mb.AUC,ma.AUC,ma.AUC-mb.AUC, ...
            -Scomp.DeltaAUC_CI(2),-Scomp.DeltaAUC_CI(1), ...
            Scomp.P_AUC}; %#ok<AGROW>
    end
end

% ---------- 宽表：Pred_Baseline / Score_Baseline ----------
predVars = v(startsWith(v,"Pred_"));

if ismember("TrueLabel",v) && ~isempty(predVars)
    basePredVar = predVars(contains(lower(predVars),'baseline'));

    if ~isempty(basePredVar)
        basePredVar = basePredVar(1);
        suffixBase = extractAfter(basePredVar,"Pred_");
        baseScoreVar = "Score_"+suffixBase;

        if ismember(baseScoreVar,v)
            y = double(T.TrueLabel);
            pb = double(T.(basePredVar));
            sb = double(T.(baseScoreVar));

            for i = 1:numel(predVars)
                pv = predVars(i);
                if pv==basePredVar
                    continue;
                end

                suffix = extractAfter(pv,"Pred_");
                sv = "Score_"+suffix;

                if ~ismember(sv,v)
                    continue;
                end

                pa = double(T.(pv));
                sa = double(T.(sv));

                Scomp = pairedComparison(y,pb,sb,pa,sa,B,P,alpha);
                mb = calculateMetrics(y,pb,sb);
                ma = calculateMetrics(y,pa,sa);

                rows(end+1,:) = { ...
                    dataset,filePath,char(suffixBase),char(suffix), ...
                    numel(y), ...
                    mb.BalancedAccuracy,ma.BalancedAccuracy, ...
                    ma.BalancedAccuracy-mb.BalancedAccuracy, ...
                    -Scomp.DeltaBA_CI(2),-Scomp.DeltaBA_CI(1), ...
                    Scomp.P_BA,Scomp.McNemarP, ...
                    mb.AUC,ma.AUC,ma.AUC-mb.AUC, ...
                    -Scomp.DeltaAUC_CI(2),-Scomp.DeltaAUC_CI(1), ...
                    Scomp.P_AUC}; %#ok<AGROW>
            end
        end
    end
end
end

function [y,pb,sb,pa,sa,ok] = ...
    alignTableConfigurations(T,baseMask,testMask)

ok = false;
y=[]; pb=[]; sb=[]; pa=[]; sa=[];

v = string(T.Properties.VariableNames);

if ismember("SubjectID",v)
    baseID = string(T.SubjectID(baseMask));
    testID = string(T.SubjectID(testMask));
    [common,ib,it] = intersect(baseID,testID,'stable');

    if numel(common)<4
        return;
    end

    y = double(T.TrueLabel(baseMask));
    y = y(ib);

    y2 = double(T.TrueLabel(testMask));
    y2 = y2(it);

    if any(y~=y2)
        return;
    end

    pb0 = double(T.PredictedLabel(baseMask));
    sb0 = double(T.PatientScore(baseMask));
    pa0 = double(T.PredictedLabel(testMask));
    sa0 = double(T.PatientScore(testMask));

    pb=pb0(ib); sb=sb0(ib);
    pa=pa0(it); sa=sa0(it);

else
    if sum(baseMask)~=sum(testMask)
        return;
    end

    y = double(T.TrueLabel(baseMask));
    y2 = double(T.TrueLabel(testMask));

    if any(y~=y2)
        return;
    end

    pb = double(T.PredictedLabel(baseMask));
    sb = double(T.PatientScore(baseMask));
    pa = double(T.PredictedLabel(testMask));
    sa = double(T.PatientScore(testMask));
end

ok = true;
end

function baseline = findBaselineName(configs)

baseline = "";

priority = ["baseline","full","allfeatures","top50baseline", ...
    "top15baseline","nofisherbaseline"];

for p = 1:numel(priority)
    idx = contains(lower(configs),priority(p));
    if any(idx)
        baseline = configs(find(idx,1));
        return;
    end
end
end

%% =========================================================
%% Fisher 稳定性
%% =========================================================
function F = extractFisherStability( ...
    filePath,scene,scaleSec,classifier,topK)

F = [];

info = whos('-file',filePath);
names = string({info.name});

candidateItems = {};

for varName = ["results","allResults","bestResult"]
    if any(names==varName)
        S = load(filePath,char(varName));
        candidateItems = [candidateItems, ...
            flattenResultItems(S.(char(varName)))]; %#ok<AGROW>
    end
end

targetClassifier = normalizeClassifier(classifier);
targetCondition = inferConditionFromScene(scene);

expectedFolds = NaN;
expectedFeatures = NaN;
if normalizeScene(scene)==normalizeScene("SAHARAN12-G01")
    expectedFolds = 97;
    expectedFeatures = 343;
elseif normalizeScene(scene)==normalizeScene("MPHCED02-EC+EO")
    expectedFolds = 56;
    expectedFeatures = 2432;
end

for i = 1:numel(candidateItems)
    x = candidateItems{i};

    if ~isstruct(x) || ~isfield(x,'SelectedIndices')
        continue;
    end

    scale = getNumericField(x,{'ScaleSec','WindowSec'},NaN);
    cls = getStringField(x,{'Classifier','ClassifierCode'},'');
    cond = getStringField(x,{'Condition','State'},'');

    if isfinite(scale) && scale~=scaleSec
        continue;
    end

    if strlength(normalizeClassifier(cls))>0 && ...
            normalizeClassifier(cls)~=targetClassifier
        continue;
    end

    if strlength(string(targetCondition))>0 && strlength(string(cond))>0 && ...
            normalizeScene(cond)~=normalizeScene(targetCondition)
        continue;
    end

    sets = x.SelectedIndices;
    if ~iscell(sets) || isempty(sets)
        continue;
    end

    nFolds = numel(sets);

    if isfinite(expectedFolds) && nFolds~=expectedFolds
        continue;
    end

    if isfield(x,'SelectionFrequency')
        nFeatures = numel(x.SelectionFrequency);
        frequency = double(x.SelectionFrequency(:));
    else
        nFeatures = max(cellfun(@max,sets));
        frequency = zeros(nFeatures,1);

        for f = 1:nFolds
            idx = sets{f};
            frequency(idx) = frequency(idx)+1;
        end
    end

    if isfinite(expectedFeatures) && nFeatures~=expectedFeatures
        continue;
    end

    featureNames = defaultFeatureNames(nFeatures);

    % 优先从 experimentData 读取真实特征名
    if any(names=="experimentData")
        ED = load(filePath,'experimentData');
        condField = char(strrep(string(targetCondition),'+','_'));
        if isfield(ED.experimentData,condField) && ...
                isfield(ED.experimentData.(condField),'FeatureNames')
            candidateNames = ED.experimentData.(condField).FeatureNames;
            if numel(candidateNames)==nFeatures
                featureNames = cellstr(string(candidateNames(:)));
            end
        end
    end

    % 尝试从 selectionTable 得到真实特征名
    if any(names=="selectionTable")
        ST = load(filePath,'selectionTable');
        T = ST.selectionTable;

        if istable(T) && ...
                all(ismember(["FeatureName","SelectedFoldCount"], ...
                string(T.Properties.VariableNames)))

            mask = true(height(T),1);

            if ismember("Condition",string(T.Properties.VariableNames))
                condSel = inferConditionFromScene(scene);
                mask = mask & normalizeSceneVector(T.Condition)== ...
                    normalizeScene(condSel);
            end
            if ismember("ScaleSec",string(T.Properties.VariableNames))
                mask = mask & double(T.ScaleSec)==scaleSec;
            end
            if ismember("Classifier",string(T.Properties.VariableNames))
                mask = mask & ...
                    normalizeClassifierVector(T.Classifier)==targetClassifier;
            end

            TT = T(mask,:);
            if height(TT)==nFeatures
                featureNames = cellstr(string(TT.FeatureName));
                frequency = double(TT.SelectedFoldCount);
            end
        end
    end

    [meanJ,medianJ,meanK] = selectionSetStability(sets,nFeatures,topK);

    F = struct();
    F.NumFolds = nFolds;
    F.TotalFeatures = nFeatures;
    F.TopK = topK;
    F.Frequency = frequency;
    F.FeatureNames = featureNames;
    F.MeanJaccard = meanJ;
    F.MedianJaccard = medianJ;
    F.MeanKuncheva = meanK;
    return;
end
end

function [meanJ,medianJ,meanK] = ...
    selectionSetStability(sets,nFeatures,topK)

J = [];
K = [];

for i = 1:numel(sets)-1
    A = unique(double(sets{i}(:)));

    for j = i+1:numel(sets)
        B = unique(double(sets{j}(:)));

        inter = numel(intersect(A,B));
        uni = numel(union(A,B));

        J(end+1,1) = inter/max(uni,1); %#ok<AGROW>

        if numel(A)==topK && numel(B)==topK && nFeatures>topK
            K(end+1,1) = ...
                (inter*nFeatures-topK^2) / ...
                (topK*(nFeatures-topK)); %#ok<AGROW>
        end
    end
end

meanJ = mean(J,'omitnan');
medianJ = median(J,'omitnan');

if isempty(K)
    meanK = NaN;
else
    meanK = mean(K,'omitnan');
end
end

%% =========================================================
%% 指标
%% =========================================================
function M = calculateMetrics(y,pred,score)

y = double(y(:));
pred = double(pred(:));
score = double(score(:));

TN = sum(y==0 & pred==0);
FP = sum(y==0 & pred==1);
FN = sum(y==1 & pred==0);
TP = sum(y==1 & pred==1);

M.Accuracy = (TP+TN)/numel(y);
M.Sensitivity = TP/max(TP+FN,1);
M.Specificity = TN/max(TN+FP,1);
M.BalancedAccuracy = (M.Sensitivity+M.Specificity)/2;

den = sqrt(max((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN),eps));
M.MCC = (TP*TN-FP*FN)/den;

M.AUC = calculateAUC(y,score);
end

function auc = calculateAUC(y,score)

pos = score(y==1);
neg = score(y==0);

if isempty(pos) || isempty(neg)
    auc = NaN;
    return;
end

greater = pos(:)>neg(:)';
equal = pos(:)==neg(:)';

auc = (sum(greater(:))+0.5*sum(equal(:))) / ...
    (numel(pos)*numel(neg));
end

%% =========================================================
%% FDR
%% =========================================================
function q = bhFDR(p)

p = double(p(:));
q = nan(size(p));

valid = isfinite(p);
pv = p(valid);

if isempty(pv)
    return;
end

[ps,order] = sort(pv);
m = numel(ps);

qs = ps.*m./(1:m)';
for i = m-1:-1:1
    qs(i) = min(qs(i),qs(i+1));
end
qs = min(qs,1);

temp = nan(m,1);
temp(order) = qs;
q(valid) = temp;
end

%% =========================================================
%% 画图
%% =========================================================
function plotFinal5sCI(T,filePath)

T = T(T.ScaleSec==5,:);

desired = ["SAHARAN12-G01","MPHCED02-EC+EO","MSU01"];
[~,ord] = ismember(desired,string(T.Scene));
ord = ord(ord>0);
T = T(ord,:);

x = 1:height(T);

fig = figure('Color','w','Position',[100 100 1050 520]);
hold on;

y = 100*T.BalancedAccuracy;
lo = y-100*T.BA_CI_L;
hi = 100*T.BA_CI_U-y;

errorbar(x-0.12,y,lo,hi,'o','LineWidth',1.4,'MarkerSize',7);

y2 = 100*T.AUC;
lo2 = y2-100*T.AUC_CI_L;
hi2 = 100*T.AUC_CI_U-y2;

errorbar(x+0.12,y2,lo2,hi2,'s','LineWidth',1.4,'MarkerSize',7);

xlim([0.5 height(T)+0.5]);
ylim([65 100.5]);
grid on;
box on;

set(gca,'XTick',x,'XTickLabel',T.Scene,'FontSize',10);
ylabel('Performance (%)');
title('5 s Final Models: Subject-level 95% Bootstrap Confidence Intervals');
legend({'Balanced Accuracy','AUC'},'Location','southoutside', ...
    'Orientation','horizontal','Box','off');

exportgraphics(fig,filePath,'Resolution',400);
close(fig);
end

function plotDeltaBA(T,titleText,filePath)

labels = string(T.Scene)+" : 5 s - "+string(T.ScaleB)+" s";
n = height(T);
y = 100*T.DeltaBA;
lo = y-100*T.DeltaBA_CI_L;
hi = 100*T.DeltaBA_CI_U-y;

fig = figure('Color','w','Position',[100 100 1050 650]);

errorbar(y,1:n,lo,hi,'horizontal','o', ...
    'LineWidth',1.2,'MarkerSize',6);
hold on;
xline(0,'--','LineWidth',1);

set(gca,'YTick',1:n,'YTickLabel',labels,'YDir','reverse');
xlabel('\Delta Balanced Accuracy (percentage points)');
title(titleText);
grid on;
box on;

exportgraphics(fig,filePath,'Resolution',400);
close(fig);
end

function plotAblationDeltaBAByType(T,type,filePath)

cfg = lower(string(T.Ablation));

switch lower(string(type))
    case "module"
        keep = contains(cfg,"noentropy") | ...
               contains(cfg,"noplv") | ...
               contains(cfg,"nogranger") | ...
               strcmp(cfg,"nogc");
        titleText = 'Feature-module ablation: paired bootstrap 95% CI';

    case "entropy"
        keep = contains(cfg,"noapen") | ...
               contains(cfg,"nofuzzy") | ...
               contains(cfg,"nosamp") | ...
               contains(cfg,"noperm") | ...
               contains(cfg,"nospec");
        titleText = 'Single-entropy leave-one-out: paired bootstrap 95% CI';

    case "fisher"
        keep = contains(cfg,"fisher");
        titleText = 'Fisher-selection ablation: paired bootstrap 95% CI';

    otherwise
        return;
end

T = T(keep,:);
if isempty(T)
    return;
end

key = string(T.Dataset)+"|"+lower(string(T.Ablation));
[~,u] = unique(key,'stable');
T = T(u,:);

datasetRank = zeros(height(T),1);
datasetRank(string(T.Dataset)=="G01") = 1;
datasetRank(string(T.Dataset)=="MPHCED02") = 2;
datasetRank(string(T.Dataset)=="MSU01") = 3;
T.DatasetRank = datasetRank;
T = sortrows(T,{'DatasetRank','Ablation'});
T.DatasetRank = [];

labels = string(T.Dataset)+" | "+string(T.Ablation);
n = height(T);

y = 100*T.DeltaBA;
lo = y-100*T.DeltaBA_CI_L;
hi = 100*T.DeltaBA_CI_U-y;

figHeight = max(420,110+42*n);
fig = figure('Color','w','Position',[100 100 1150 figHeight]);

errorbar(y,1:n,lo,hi,'horizontal','o', ...
    'LineWidth',1.2,'MarkerSize',5);
hold on;
xline(0,'--','LineWidth',1);

set(gca,'YTick',1:n,'YTickLabel',labels,'YDir','reverse', ...
    'TickLabelInterpreter','none');
xlabel('\Delta Balanced Accuracy (percentage points)');
title(titleText);
grid on;
box on;

exportgraphics(fig,filePath,'Resolution',400);
close(fig);
end

function plotFisherStability(T,filePath)

scenes = unique(string(T.Scene),'stable');
fig = figure('Color','w','Position',[100 100 1200 520]);

for s = 1:min(2,numel(scenes))
    TT = T(string(T.Scene)==scenes(s),:);
    TT = sortrows(TT,'SelectedFoldFraction','descend');
    TT = TT(1:min(15,height(TT)),:);

    ax = subplot(1,2,s);
    barh(ax,flip(TT.SelectedFoldFraction));
    set(ax,'YTick',1:height(TT), ...
        'YTickLabel',flip(string(TT.FeatureName)), ...
        'TickLabelInterpreter','none', ...
        'FontSize',8);
    xlim(ax,[0 1]);
    xlabel(ax,'Selected fold fraction');
    title(ax,scenes(s));
    grid(ax,'on');
end

sgtitle('Most Frequently Selected Fisher Features');

exportgraphics(fig,filePath,'Resolution',400);
close(fig);
end

%% =========================================================
%% 文本与辅助
%% =========================================================
function scene = inferScene(dataset,condition)

dataset = string(dataset);
condition = upper(strrep(string(condition),'_','+'));

if dataset=="G01"
    scene = "SAHARAN12-G01";
elseif dataset=="MSU01"
    scene = "MSU01";
elseif dataset=="MPHCED02"
    if condition=="EC"
        scene = "MPHCED02-EC";
    elseif condition=="EO"
        scene = "MPHCED02-EO";
    elseif condition=="EC+EO"
        scene = "MPHCED02-EC+EO";
    else
        scene = "MPHCED02";
    end
else
    scene = dataset;
end
end

function x = normalizeScene(x)
x = upper(string(x));
x = replace(x,"_","+");
x = replace(x,"(","");
x = replace(x,")","");
x = replace(x," ","");
end

function out = normalizeSceneVector(x)
out = normalizeScene(string(x));
end

function x = normalizeClassifier(x)
x = upper(string(x));
x = regexprep(x,'[^A-Z0-9]','');

if contains(x,'LOGISTIC') || contains(x,'L2LR')
    x = "LOGISTIC";
elseif contains(x,'RBFSVM')
    x = "RBFSVM";
elseif contains(x,'LINEARSVM')
    x = "LINEARSVM";
elseif x=="LDA"
    x = "LDA";
elseif x=="KNN"
    x = "KNN";
elseif x=="RF" || contains(x,'RANDOMFOREST')
    x = "RF";
end
end

function out = normalizeClassifierVector(x)
x = string(x);
out = strings(size(x));
for i = 1:numel(x)
    out(i) = normalizeClassifier(x(i));
end
end

function x = displayClassifier(x)
if normalizeClassifier(x)=="LOGISTIC"
    x = "L2-LR";
else
    x = string(x);
end
end

function cond = inferConditionFromScene(scene)
scene = string(scene);
if contains(scene,'EC+EO'), cond="EC_EO";
elseif endsWith(scene,'-EC'), cond="EC";
elseif endsWith(scene,'-EO'), cond="EO";
else, cond="";
end
end

function module = featureModule(name)
n = upper(string(name));
if contains(n,'PLV')
    module = "PLV";
elseif contains(n,'MVGC') || contains(n,'GRANGER') || contains(n,'GC_')
    module = "Granger";
else
    module = "Entropy";
end
end

function names = defaultFeatureNames(n)
names = cell(n,1);
for i = 1:n
    names{i} = sprintf('Feature_%d',i);
end
end

function name = findTableVariable(variableNames,candidates)
name = "";
variableNames = string(variableNames);
for i = 1:numel(candidates)
    idx = find(strcmpi(variableNames,candidates(i)),1);
    if ~isempty(idx)
        name = variableNames(idx);
        return;
    end
end
end

function x = getStringField(S,names,defaultValue)
x = string(defaultValue);
for i = 1:numel(names)
    if isfield(S,names{i}) && ~isempty(S.(names{i}))
        x = string(S.(names{i}));
        return;
    end
end
end

function x = getNumericField(S,names,defaultValue)
x = defaultValue;
for i = 1:numel(names)
    if isfield(S,names{i}) && ~isempty(S.(names{i}))
        x = double(S.(names{i}));
        if numel(x)>1, x=x(1); end
        return;
    end
end
end

function x = firstNonempty(v)
v = string(v);
idx = find(strlength(v)>0,1);
if isempty(idx), x=""; else, x=v(idx); end
end

function x = firstFinite(v)
v = double(v);
idx = find(isfinite(v),1);
if isempty(idx), x=NaN; else, x=v(idx); end
end

function out = appendStruct(out,newItems)
if isempty(newItems), return; end
if isempty(out)
    out = newItems(:)';
else
    out = [out,newItems(:)']; %#ok<AGROW>
end
end
