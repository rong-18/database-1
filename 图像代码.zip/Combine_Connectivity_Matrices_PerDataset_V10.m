function Combine_Connectivity_Matrices_PerDataset_V10
% 每个数据集一张整合图（MPHCED02 的 EC / EO 分开）
%
% 输出：
% 1) SAHARAN12_G01_Connectivity_Combined.png
% 2) MPHCED02_EC_Connectivity_Combined.png
% 3) MPHCED02_EO_Connectivity_Combined.png
% 4) MSU01_Connectivity_Combined.png
%
% 版式统一：
% - 全部使用 2×3
% - 第1行：PLV（Control / Patient / Patient-Control）
% - 第2行：Granger（Control / Patient / Patient-Control）
%
% 输入目录：
% D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices

clc;
close all;

rootDir = 'D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices';

if ~exist(rootDir,'dir')
    error('未找到结果目录：%s',rootDir);
end

fprintf('开始生成统一 2x3 版式连接矩阵图...\n');
fprintf('结果目录：%s\n\n',rootDir);

style = getStyle();

% G01
makeTwoRowFigure( ...
    fullfile(rootDir,'SAHARAN12_G01'), ...
    'SAHARAN12-G01', ...
    fullfile(rootDir,'SAHARAN12_G01_Connectivity_Combined.png'), ...
    style);

% MPHCED02 - EC
makeTwoRowFigure( ...
    fullfile(rootDir,'MPHCED02_EC'), ...
    'MPHCED02-EC', ...
    fullfile(rootDir,'MPHCED02_EC_Connectivity_Combined.png'), ...
    style);

% MPHCED02 - EO
makeTwoRowFigure( ...
    fullfile(rootDir,'MPHCED02_EO'), ...
    'MPHCED02-EO', ...
    fullfile(rootDir,'MPHCED02_EO_Connectivity_Combined.png'), ...
    style);

% MSU01
makeTwoRowFigure( ...
    fullfile(rootDir,'MSU01'), ...
    'MSU01', ...
    fullfile(rootDir,'MSU01_Connectivity_Combined.png'), ...
    style);

fprintf('\n全部完成。\n');
end

%% =========================================================
%% 统一样式：固定像素，与当前 MSU01 图风格一致
%% =========================================================
function style = getStyle()

style = struct();

style.FontName = 'Arial';
style.MainTitleSize = 15;
style.SubTitleSize = 10;
style.AxisFontSize = 8;
style.PanelLabelSize = 9;

% 固定 tile 尺寸
style.TileWidthPx = 390;
style.TileHeightPx = 260;

% 固定间距
style.HorizontalGapPx = 12;
style.VerticalGapPx = 42;

% 外边距
style.LeftMarginPx = 22;
style.RightMarginPx = 20;
style.TopMarginPx = 48;
style.BottomMarginPx = 22;

% tile 内部预留
style.TitleReservePx = 18;
style.LabelReservePx = 26;

% colorbar
style.ColorbarGapPx = 5;
style.ColorbarWidthPx = 12;

style.ExportResolution = 400;
end

%% =========================================================
%% 通用 2×3 图
%% =========================================================
function makeTwoRowFigure(dataDir,datasetName,saveFile,style)

plvFile = fullfile(dataDir,'PLV_important_connectivity.xlsx');
gcFile = fullfile(dataDir,'Granger_important_connectivity.xlsx');

[plvC,plvP,plvD,names] = readImportantMatrices(plvFile);
[gcC,gcP,gcD,~] = readImportantMatrices(gcFile);

nRows = 2;
nCols = 3;

[fig,figW,figH] = createFigure(style,nRows,nCols);

addMainTitle(fig, ...
    [datasetName ' | Important PLV and Granger Connections'], ...
    style,figH);

plvMeanLim = commonPositiveLimit(plvC,plvP);
plvDiffLim = symmetricLimit(plvD);

gcMeanLim = commonPositiveLimit(gcC,gcP);
gcDiffLim = symmetricLimit(gcD);

row1 = {
    plvC, 'PLV - Control', [0 plvMeanLim], false, '(a)';
    plvP, 'PLV - Patient', [0 plvMeanLim], false, '(b)';
    plvD, 'PLV - Patient - Control', [-plvDiffLim plvDiffLim], true, '(c)'};

row2 = {
    gcC, 'Granger - Control', [0 gcMeanLim], false, '(d)';
    gcP, 'Granger - Patient', [0 gcMeanLim], false, '(e)';
    gcD, 'Granger - Patient - Control', [-gcDiffLim gcDiffLim], true, '(f)'};

drawRow(fig,1,nRows,nCols,row1,names,style,figH);
drawRow(fig,2,nRows,nCols,row2,names,style,figH);

drawnow;
exportgraphics(fig,saveFile,'Resolution',style.ExportResolution);
close(fig);

fprintf('%s 完成：%s\n',datasetName,saveFile);
end

%% =========================================================
%% Figure 尺寸
%% =========================================================
function [fig,figW,figH] = createFigure(style,nRows,nCols)

figW = ...
    style.LeftMarginPx + ...
    nCols*style.TileWidthPx + ...
    (nCols-1)*style.HorizontalGapPx + ...
    style.RightMarginPx;

figH = ...
    style.TopMarginPx + ...
    nRows*style.TileHeightPx + ...
    (nRows-1)*style.VerticalGapPx + ...
    style.BottomMarginPx;

fig = figure( ...
    'Color','w', ...
    'Units','pixels', ...
    'Position',[60 40 figW figH], ...
    'Visible','off', ...
    'ToolBar','none', ...
    'MenuBar','none', ...
    'NumberTitle','off');
end

%% =========================================================
%% 主标题
%% =========================================================
function addMainTitle(fig,titleText,style,figH)

annotation(fig,'textbox', ...
    [0, 1-style.TopMarginPx/figH, 1, style.TopMarginPx/figH], ...
    'String',titleText, ...
    'EdgeColor','none', ...
    'HorizontalAlignment','center', ...
    'VerticalAlignment','middle', ...
    'FontName',style.FontName, ...
    'FontSize',style.MainTitleSize, ...
    'FontWeight','bold');
end

%% =========================================================
%% 画一行
%% =========================================================
function drawRow(fig,rowIndex,nRows,nCols,rowSpec,names,style,figH)

for colIndex = 1:nCols

    tilePx = getTilePositionPx( ...
        rowIndex,colIndex,nRows,nCols,style,figH);

    axPx = [ ...
        tilePx(1), ...
        tilePx(2) + style.LabelReservePx, ...
        tilePx(3) - style.ColorbarGapPx - style.ColorbarWidthPx, ...
        tilePx(4) - style.TitleReservePx - style.LabelReservePx];

    cbPx = [ ...
        axPx(1) + axPx(3) + style.ColorbarGapPx, ...
        axPx(2), ...
        style.ColorbarWidthPx, ...
        axPx(4)];

    M = rowSpec{colIndex,1};
    subtitleText = rowSpec{colIndex,2};
    limits = rowSpec{colIndex,3};
    useDiverging = rowSpec{colIndex,4};
    panelText = rowSpec{colIndex,5};

    ax = axes(fig, ...
        'Units','pixels', ...
        'Position',axPx); %#ok<LAXES>

    drawMatrix(ax,M,names,limits,useDiverging,style,cbPx);

    title(ax,subtitleText, ...
        'FontWeight','bold', ...
        'FontName',style.FontName, ...
        'FontSize',style.SubTitleSize);

    xlabel(ax,panelText, ...
        'FontName',style.FontName, ...
        'FontSize',style.PanelLabelSize, ...
        'FontWeight','bold');
end
end

%% =========================================================
%% 单个 tile 位置
%% =========================================================
function pos = getTilePositionPx( ...
    rowIndex,colIndex,nRows,nCols,style,figH) %#ok<INUSD>

leftPx = ...
    style.LeftMarginPx + ...
    (colIndex-1)*(style.TileWidthPx + style.HorizontalGapPx);

topOfTilePx = ...
    figH - style.TopMarginPx - ...
    (rowIndex-1)*(style.TileHeightPx + style.VerticalGapPx);

bottomPx = topOfTilePx - style.TileHeightPx;

pos = [ ...
    leftPx, ...
    bottomPx, ...
    style.TileWidthPx, ...
    style.TileHeightPx];
end

%% =========================================================
%% Excel 读取
%% =========================================================
function [C,P,D,names] = readImportantMatrices(fileName)

if ~isfile(fileName)
    error(['未找到结果文件：\n%s\n' ...
        '请先运行 Generate_Important_Connectivity_Matrices_V1。'], ...
        fileName);
end

[C,names] = readMatrixSheet(fileName,'ControlImportant');
[P,~] = readMatrixSheet(fileName,'PatientImportant');
[D,~] = readMatrixSheet(fileName,'DifferenceImportant');
end

function [M,names] = readMatrixSheet(fileName,sheetName)

T = readtable(fileName, ...
    'Sheet',sheetName, ...
    'ReadRowNames',true, ...
    'VariableNamingRule','preserve');

names = T.Properties.RowNames;
M = table2array(T);
end

%% =========================================================
%% 矩阵绘制
%% =========================================================
function drawMatrix(ax,M,names,limits,useDiverging,style,cbPx)

imagesc(ax,M,'AlphaData',~isnan(M));
axis(ax,'square');

set(ax, ...
    'Color',[1 1 1], ...
    'XTick',1:numel(names), ...
    'YTick',1:numel(names), ...
    'XTickLabel',names, ...
    'YTickLabel',names, ...
    'XTickLabelRotation',45, ...
    'FontName',style.FontName, ...
    'FontSize',style.AxisFontSize, ...
    'TickLength',[0 0], ...
    'LineWidth',0.7, ...
    'Box','on');

try
    ax.Toolbar.Visible = 'off';
catch
end

try
    disableDefaultInteractivity(ax);
catch
end

if useDiverging
    colormap(ax,blueWhiteRed(256));
else
    colormap(ax,parula(256));
end

caxis(ax,limits);

cb = colorbar(ax);
cb.Units = 'pixels';
cb.Position = cbPx;
cb.FontName = style.FontName;
cb.FontSize = style.AxisFontSize;
cb.LineWidth = 0.7;
end

%% =========================================================
%% 色标范围
%% =========================================================
function lim = commonPositiveLimit(A,B)

values = [A(~isnan(A)); B(~isnan(B))];

if isempty(values)
    lim = 1;
    return;
end

lim = max(values);

if ~isfinite(lim) || lim<=0
    lim = 1;
end
end

function lim = symmetricLimit(A)

values = abs(A(~isnan(A)));

if isempty(values)
    lim = 1;
    return;
end

lim = max(values);

if ~isfinite(lim) || lim<=0
    lim = 1;
end
end

%% =========================================================
%% 红-白-蓝色图
%% =========================================================
function cmap = blueWhiteRed(m)

if nargin<1
    m = 256;
end

x = [0 0.5 1];

r = interp1(x,[0 1 1],linspace(0,1,m));
g = interp1(x,[0 1 0],linspace(0,1,m));
b = interp1(x,[1 1 0],linspace(0,1,m));

cmap = [r(:) g(:) b(:)];
end
