function Combine_Connectivity_Matrices_PerDataset_V4
% 将重要PLV/Granger连接结果整理为“每个数据集一张图”
%
% 前提：
% 已运行 Generate_Important_Connectivity_Matrices_V1
%
% 输入目录：
% D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices
%
% 输出：
% 1) SAHARAN12_G01_Connectivity_Combined.png   2×3
% 2) MPHCED02_Connectivity_Combined.png        4×3
% 3) MSU01_Connectivity_Combined.png           2×3
%
% V4修正：
% - 子图标号(a)(b)(c)... 使用xlabel放到每个子图下方，避免裁剪
% - 放宽TileSpacing，避免下方标号与下一行标题重叠
% - 继续关闭Axes Toolbar / Figure Toolbar / MenuBar
% - 保持同一类连接的患者/对照色标一致
% - 差异矩阵使用以0为中心的红-白-蓝色标

clc;
close all;

rootDir = 'D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices';

if ~exist(rootDir,'dir')
    error('未找到结果目录：%s',rootDir);
end

fprintf('开始生成每个数据集的整合连接矩阵图...\n');
fprintf('结果目录：%s\n\n',rootDir);

makeTwoRowFigure( ...
    fullfile(rootDir,'SAHARAN12_G01'), ...
    'SAHARAN12-G01', ...
    fullfile(rootDir,'SAHARAN12_G01_Connectivity_Combined.png'));

makeMPHCEDFigure( ...
    fullfile(rootDir,'MPHCED02_EC'), ...
    fullfile(rootDir,'MPHCED02_EO'), ...
    fullfile(rootDir,'MPHCED02_Connectivity_Combined.png'));

makeTwoRowFigure( ...
    fullfile(rootDir,'MSU01'), ...
    'MSU01', ...
    fullfile(rootDir,'MSU01_Connectivity_Combined.png'));

fprintf('\n全部完成。\n');
end

%% =========================================================
%% G01 / MSU01：2×3
%% =========================================================
function makeTwoRowFigure(dataDir,datasetName,saveFile)

plvFile = fullfile(dataDir,'PLV_important_connectivity.xlsx');
gcFile = fullfile(dataDir,'Granger_important_connectivity.xlsx');

[plvC,plvP,plvD,names] = readImportantMatrices(plvFile);
[gcC,gcP,gcD,~] = readImportantMatrices(gcFile);

fig = figure( ...
    'Color','w', ...
    'Position',[80 80 1500 980], ...
    'Visible','off', ...
    'ToolBar','none', ...
    'MenuBar','none', ...
    'NumberTitle','off');

t = tiledlayout(fig,2,3, ...
    'Padding','loose', ...
    'TileSpacing','loose');

%% 第1行：PLV
plvMeanLim = commonPositiveLimit(plvC,plvP);
plvDiffLim = symmetricLimit(plvD);

ax = nexttile(t);
drawMatrix(ax,plvC,names,[0 plvMeanLim],false);
title(ax,'PLV - Control','FontWeight','bold');
addPanelLabelBelow(ax,'(a)');

ax = nexttile(t);
drawMatrix(ax,plvP,names,[0 plvMeanLim],false);
title(ax,'PLV - Patient','FontWeight','bold');
addPanelLabelBelow(ax,'(b)');

ax = nexttile(t);
drawMatrix(ax,plvD,names,[-plvDiffLim plvDiffLim],true);
title(ax,'PLV - Patient - Control','FontWeight','bold');
addPanelLabelBelow(ax,'(c)');

%% 第2行：Granger
gcMeanLim = commonPositiveLimit(gcC,gcP);
gcDiffLim = symmetricLimit(gcD);

ax = nexttile(t);
drawMatrix(ax,gcC,names,[0 gcMeanLim],false);
title(ax,'Granger - Control','FontWeight','bold');
addPanelLabelBelow(ax,'(d)');

ax = nexttile(t);
drawMatrix(ax,gcP,names,[0 gcMeanLim],false);
title(ax,'Granger - Patient','FontWeight','bold');
addPanelLabelBelow(ax,'(e)');

ax = nexttile(t);
drawMatrix(ax,gcD,names,[-gcDiffLim gcDiffLim],true);
title(ax,'Granger - Patient - Control','FontWeight','bold');
addPanelLabelBelow(ax,'(f)');

title(t, ...
    [datasetName ' | Important PLV and Granger Connections'], ...
    'FontWeight','bold', ...
    'FontSize',15);

drawnow;
exportgraphics(fig,saveFile,'Resolution',300);
close(fig);

fprintf('%s 完成：%s\n',datasetName,saveFile);
end

%% =========================================================
%% MPHCED02：4×3
%% =========================================================
function makeMPHCEDFigure(ecDir,eoDir,saveFile)

[ecPlvC,ecPlvP,ecPlvD,names] = ...
    readImportantMatrices( ...
    fullfile(ecDir,'PLV_important_connectivity.xlsx'));

[ecGcC,ecGcP,ecGcD,~] = ...
    readImportantMatrices( ...
    fullfile(ecDir,'Granger_important_connectivity.xlsx'));

[eoPlvC,eoPlvP,eoPlvD,~] = ...
    readImportantMatrices( ...
    fullfile(eoDir,'PLV_important_connectivity.xlsx'));

[eoGcC,eoGcP,eoGcD,~] = ...
    readImportantMatrices( ...
    fullfile(eoDir,'Granger_important_connectivity.xlsx'));

plvMeanLim = max( ...
    commonPositiveLimit(ecPlvC,ecPlvP), ...
    commonPositiveLimit(eoPlvC,eoPlvP));

plvDiffLim = max( ...
    symmetricLimit(ecPlvD), ...
    symmetricLimit(eoPlvD));

gcMeanLim = max( ...
    commonPositiveLimit(ecGcC,ecGcP), ...
    commonPositiveLimit(eoGcC,eoGcP));

gcDiffLim = max( ...
    symmetricLimit(ecGcD), ...
    symmetricLimit(eoGcD));

fig = figure( ...
    'Color','w', ...
    'Position',[60 20 1500 1800], ...
    'Visible','off', ...
    'ToolBar','none', ...
    'MenuBar','none', ...
    'NumberTitle','off');

t = tiledlayout(fig,4,3, ...
    'Padding','loose', ...
    'TileSpacing','loose');

panelIndex = 1;

panelIndex = drawRow( ...
    t,ecPlvC,ecPlvP,ecPlvD,names, ...
    plvMeanLim,plvDiffLim,'EC - PLV',panelIndex);

panelIndex = drawRow( ...
    t,ecGcC,ecGcP,ecGcD,names, ...
    gcMeanLim,gcDiffLim,'EC - Granger',panelIndex);

panelIndex = drawRow( ...
    t,eoPlvC,eoPlvP,eoPlvD,names, ...
    plvMeanLim,plvDiffLim,'EO - PLV',panelIndex);

drawRow( ...
    t,eoGcC,eoGcP,eoGcD,names, ...
    gcMeanLim,gcDiffLim,'EO - Granger',panelIndex);

title(t, ...
    'MPHCED02 | Important PLV and Granger Connections', ...
    'FontWeight','bold', ...
    'FontSize',15);

drawnow;
exportgraphics(fig,saveFile,'Resolution',300);
close(fig);

fprintf('MPHCED02 完成：%s\n',saveFile);
end

function nextPanelIndex = drawRow( ...
    t,C,P,D,names,meanLim,diffLim,rowName,panelIndex)

ax = nexttile(t);
drawMatrix(ax,C,names,[0 meanLim],false);
title(ax,[rowName ' - Control'],'FontWeight','bold');
addPanelLabelBelow(ax,panelLabel(panelIndex));
panelIndex = panelIndex + 1;

ax = nexttile(t);
drawMatrix(ax,P,names,[0 meanLim],false);
title(ax,[rowName ' - Patient'],'FontWeight','bold');
addPanelLabelBelow(ax,panelLabel(panelIndex));
panelIndex = panelIndex + 1;

ax = nexttile(t);
drawMatrix(ax,D,names,[-diffLim diffLim],true);
title(ax,[rowName ' - Patient - Control'],'FontWeight','bold');
addPanelLabelBelow(ax,panelLabel(panelIndex));
panelIndex = panelIndex + 1;

nextPanelIndex = panelIndex;
end

%% =========================================================
%% Excel读取
%% =========================================================
function [C,P,D,names] = readImportantMatrices(fileName)

if ~isfile(fileName)
    error(['未找到结果文件：\n%s\n' ...
        '请先运行 Generate_Important_Connectivity_Matrices_V1。'], ...
        fileName);
end

[C,names] = readMatrixSheet(fileName,'ControlImportant');
[P,~] = readMatrixSheet(fileName,'PatientImportant');
[D,~] = readMatrixSheet(fileName,'DifferenceImportant');
end

function [M,names] = readMatrixSheet(fileName,sheetName)

T = readtable( ...
    fileName, ...
    'Sheet',sheetName, ...
    'ReadRowNames',true, ...
    'VariableNamingRule','preserve');

names = T.Properties.RowNames;
M = table2array(T);
end

%% =========================================================
%% 绘图
%% =========================================================
function drawMatrix(ax,M,names,limits,useDiverging)

imagesc(ax,M,'AlphaData',~isnan(M));
axis(ax,'square');

set(ax, ...
    'Color',[1 1 1], ...
    'XTick',1:numel(names), ...
    'YTick',1:numel(names), ...
    'XTickLabel',names, ...
    'YTickLabel',names, ...
    'XTickLabelRotation',45, ...
    'FontName','Times New Roman', ...
    'FontSize',8, ...
    'TickLength',[0 0]);

try
    ax.Toolbar.Visible = 'off';
catch
end

try
    disableDefaultInteractivity(ax);
catch
end

if useDiverging
    colormap(ax,blueWhiteRed(256));
else
    colormap(ax,parula(256));
end

caxis(ax,limits);

cb = colorbar(ax);
cb.FontName = 'Times New Roman';
cb.FontSize = 8;
end

function addPanelLabelBelow(ax,labelText)

% 使用xlabel作为子图编号。
% tiledlayout会自动为xlabel预留空间，避免底部子图编号被裁掉。
xlabel(ax,labelText, ...
    'FontName','Times New Roman', ...
    'FontSize',11, ...
    'FontWeight','bold');
end

%% =========================================================
%% 色标范围
%% =========================================================
function lim = commonPositiveLimit(A,B)

values = [A(~isnan(A)); B(~isnan(B))];

if isempty(values)
    lim = 1;
    return;
end

lim = max(values);

if ~isfinite(lim) || lim<=0
    lim = 1;
end
end

function lim = symmetricLimit(A)

values = abs(A(~isnan(A)));

if isempty(values)
    lim = 1;
    return;
end

lim = max(values);

if ~isfinite(lim) || lim<=0
    lim = 1;
end
end

%% =========================================================
%% 子图标签
%% =========================================================
function txt = panelLabel(index)

letters = 'abcdefghijklmnopqrstuvwxyz';

if index<=numel(letters)
    txt = ['(' letters(index) ')'];
else
    txt = ['(' num2str(index) ')'];
end
end

%% =========================================================
%% 红-白-蓝差异色图
%% =========================================================
function cmap = blueWhiteRed(m)

if nargin<1
    m = 256;
end

x = [0 0.5 1];

r = interp1(x,[0 1 1],linspace(0,1,m));
g = interp1(x,[0 1 0],linspace(0,1,m));
b = interp1(x,[1 1 0],linspace(0,1,m));

cmap = [r(:) g(:) b(:)];
end
