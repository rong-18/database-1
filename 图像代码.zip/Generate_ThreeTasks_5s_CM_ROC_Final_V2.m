function Generate_ThreeTasks_5s_CM_ROC_Final_V2
% 三个主任务 5 s 最终论文版：
% 直接读取最终实验保存的受试者级预测，不重新训练模型。
%
% 目标主结果：
% G01              Acc=84.54%  BA=84.76%  MCC=0.695  AUC=0.893
% MPHCED02-EC_EO   Acc=92.86%  BA=92.85%  MCC=0.857  AUC=0.885
% MSU01            Acc=91.67%  BA=91.71%  MCC=0.833  AUC=0.948
%
% 输出目录：
% D:\Database\EEG_Paper_Figures\ThreeTasks_5s_CM_ROC
%
% 注意：
% 1) 本脚本不重新训练任何模型；
% 2) ROC/AUC 使用最终保存的受试者级 PatientScore；
% 3) AUC 使用 perfcurve 计算；
% 4) 若读取结果与论文最终指标不一致，直接报错停止。

clc;
close all;

outDir = 'D:\Database\EEG_Paper_Figures\ThreeTasks_5s_CM_ROC';
if ~exist(outDir,'dir')
    mkdir(outDir);
end

fprintf('读取最终受试者级预测结果...\n\n');

R1 = loadG01Final();
R2 = loadMPHCED02Final();
R3 = loadMSU01Final();

% 严格核对论文最终指标
checkResult(R1,[0.8454 0.8476 0.695 0.893]);
checkResult(R2,[0.9286 0.9285 0.857 0.885]);
checkResult(R3,[0.9167 0.9171 0.833 0.948]);

% 直接覆盖原图
plotSingleResult(R1,fullfile(outDir,'G01_5s_RBFSVM_CM_ROC.png'));
plotSingleResult(R2,fullfile(outDir,'MPHCED02_EC_EO_5s_LDA_CM_ROC.png'));
plotSingleResult(R3,fullfile(outDir,'MSU01_5s_Logistic_NoFisher_CM_ROC.png'));
plotCombined({R1,R2,R3}, ...
    fullfile(outDir,'ThreeTasks_5s_CM_ROC_Combined.png'));

summaryTable = table( ...
    string({R1.Task;R2.Task;R3.Task}), ...
    string({R1.Model;R2.Model;R3.Model}), ...
    [R1.CM(1,1);R2.CM(1,1);R3.CM(1,1)], ...
    [R1.CM(1,2);R2.CM(1,2);R3.CM(1,2)], ...
    [R1.CM(2,1);R2.CM(2,1);R3.CM(2,1)], ...
    [R1.CM(2,2);R2.CM(2,2);R3.CM(2,2)], ...
    [R1.Metrics.Accuracy;R2.Metrics.Accuracy;R3.Metrics.Accuracy], ...
    [R1.Metrics.BalancedAccuracy;R2.Metrics.BalancedAccuracy;R3.Metrics.BalancedAccuracy], ...
    [R1.Metrics.MCC;R2.Metrics.MCC;R3.Metrics.MCC], ...
    [R1.Metrics.AUC;R2.Metrics.AUC;R3.Metrics.AUC], ...
    'VariableNames',{'Task','Model','TN','FP','FN','TP', ...
    'Accuracy','BalancedAccuracy','MCC','AUC'});

summaryFile = fullfile(outDir,'ThreeTasks_5s_CM_ROC_Summary.xlsx');
if isfile(summaryFile)
    delete(summaryFile);
end
writetable(summaryTable,summaryFile,'FileType','spreadsheet');

fprintf('\n完成。最终指标：\n');
disp(summaryTable);
fprintf('输出目录：%s\n',outDir);
end

%% =========================================================
%% G01：读取主实验最终结果
%% =========================================================
function R = loadG01Final()

root1 = 'D:\Database\Seizure\SAHARAN\SAHARAN12\G01';
root2 = 'D:\Database\Seizure\SAHARAN12\G01';

files = { ...
    fullfile(root1,'G01_EPG_LOPO_results_V4.mat'), ...
    fullfile(root1,'G01_EPG_LOPO_results_V3.mat'), ...
    fullfile(root1,'G01_EPG_LOPO_results_V2.mat'), ...
    fullfile(root1,'G01_EPG_LOPO_results_V1.mat'), ...
    fullfile(root2,'G01_EPG_LOPO_results_V4.mat'), ...
    fullfile(root2,'G01_EPG_LOPO_results_V3.mat'), ...
    fullfile(root2,'G01_EPG_LOPO_results_V2.mat'), ...
    fullfile(root2,'G01_EPG_LOPO_results_V1.mat')};

labelFile = 'D:\Database\Seizure\SAHARAN\G_dataLable.mat';
L = load(labelFile,'dataLable');
defaultY = double(L.dataLable(:));

found = false;

for k = 1:numel(files)
    if ~isfile(files{k})
        continue;
    end

    fprintf('检查 G01 主结果：%s\n',files{k});
    S = load(files{k});

    [ok,y,pred,score] = extractSavedPredictions( ...
        S,5,{'RBF-SVM','RBFSVM','RBF_SVM'},'',defaultY);

    if ok
        candidate = makeResult( ...
            'SAHARAN12-G01', ...
            '5 s + RBF-SVM + Fisher Top50', ...
            y,pred,score,{'Non-Patient','Patient'},files{k});

        % 只接受与主结果相符的文件
        if closeTo(candidate,[0.8454 0.8476 0.695 0.893])
            R = candidate;
            found = true;
            break;
        end
    end
end

if ~found
    error([ ...
        '没有在 G01 主结果 MAT 中找到与论文最终结果一致的受试者级预测。\n' ...
        '需要的目标：Acc=84.54%%, BA=84.76%%, MCC=0.695, AUC=0.893。\n' ...
        '请确认 G01_EPG_LOPO_results_V4/V3/V2/V1.mat 中保存了\n' ...
        'SubjectPredictedLabel 和 SubjectPatientScore。']);
end
end

%% =========================================================
%% MPHCED02：读取最终5s LDA Baseline预测
%% =========================================================
function R = loadMPHCED02Final()

rootDir = 'D:\Database\Depression\MPHCED\MPHCED02';

files = { ...
    fullfile(rootDir,'消融实验','MPHCED02_5s_LDA_ablation_results_V3.mat'), ...
    fullfile(rootDir,'MPHCED02_EC_EO_MSE_PLV_MVGC_LOPO_results_V3.mat'), ...
    fullfile(rootDir,'MPHCED02_EC_EO_MSE_PLV_MVGC_LOPO_results_V2.mat')};

found = false;

for k = 1:numel(files)
    if ~isfile(files{k})
        continue;
    end

    fprintf('检查 MPHCED02 结果：%s\n',files{k});
    S = load(files{k});

    % 优先使用消融Baseline；它与最终主模型完全同配置且为确定性LDA
    if isfield(S,'predictionTable') && istable(S.predictionTable)
        T = S.predictionTable;
        vars = string(T.Properties.VariableNames);

        if all(ismember(["TrueLabel","PredictedLabel","PatientScore"],vars))
            mask = true(height(T),1);

            if ismember("Configuration",vars)
                mask = mask & string(T.Configuration)=="Baseline";
            end
            if ismember("Condition",vars)
                mask = mask & string(T.Condition)=="EC_EO";
            end
            if ismember("ScaleSec",vars)
                mask = mask & double(T.ScaleSec)==5;
            end
            if ismember("Classifier",vars)
                mask = mask & matchClassifier(T.Classifier,{'LDA'});
            end

            if any(mask)
                y = double(T.TrueLabel(mask));
                pred = double(T.PredictedLabel(mask));
                score = double(T.PatientScore(mask));

                candidate = makeResult( ...
                    'MPHCED02 (EC+EO)', ...
                    '5 s + LDA + Fisher Top15', ...
                    y,pred,score,{'HC','MDD'},files{k});

                if closeTo(candidate,[0.9286 0.9285 0.857 0.885])
                    R = candidate;
                    found = true;
                    break;
                end
            end
        end
    end

    [ok,y,pred,score] = extractSavedPredictions( ...
        S,5,{'LDA'},'EC_EO',[]);

    if ok
        candidate = makeResult( ...
            'MPHCED02 (EC+EO)', ...
            '5 s + LDA + Fisher Top15', ...
            y,pred,score,{'HC','MDD'},files{k});

        if closeTo(candidate,[0.9286 0.9285 0.857 0.885])
            R = candidate;
            found = true;
            break;
        end
    end
end

if ~found
    error('未找到与 MPHCED02 最终主结果一致的受试者级预测。');
end
end

%% =========================================================
%% MSU01：读取最终5s Logistic + NoFisher预测
%% =========================================================
function R = loadMSU01Final()

rootDir = 'D:\Database\Schizophrenia\MSU\MSU01';

files = { ...
    fullfile(rootDir,'消融实验2.0', ...
        'MSU01_5s_Logistic_NoFisher_ablation_results_V2.mat'), ...
    fullfile(rootDir,'消融实验', ...
        'MSU01_NoFisher_1s2s5s_6Classifiers_V1.mat')};

found = false;

for k = 1:numel(files)
    if ~isfile(files{k})
        continue;
    end

    fprintf('检查 MSU01 结果：%s\n',files{k});
    S = load(files{k});

    if isfield(S,'predictionTable') && istable(S.predictionTable)
        T = S.predictionTable;
        vars = string(T.Properties.VariableNames);

        % 消融结果：宽表 Pred_Baseline / Score_Baseline
        if all(ismember(["TrueLabel","Pred_Baseline","Score_Baseline"],vars))
            y = double(T.TrueLabel);
            pred = double(T.Pred_Baseline);
            score = double(T.Score_Baseline);

            candidate = makeResult( ...
                'MSU01','5 s + Logistic + NoFisher', ...
                y,pred,score,{'HC','SZ'},files{k});

            if closeTo(candidate,[0.9167 0.9171 0.833 0.948])
                R = candidate;
                found = true;
                break;
            end
        end

        % 方案B主实验：长表
        if all(ismember(["ScaleSec","Classifier","TrueLabel", ...
                "PredictedLabel","PatientScore"],vars))

            mask = double(T.ScaleSec)==5 & ...
                matchClassifier(T.Classifier,{'Logistic','L2-LR','L2LR'});

            if ismember("Repeat",vars)
                mask = mask & double(T.Repeat)==1;
            end

            if any(mask)
                y = double(T.TrueLabel(mask));
                pred = double(T.PredictedLabel(mask));
                score = double(T.PatientScore(mask));

                candidate = makeResult( ...
                    'MSU01','5 s + Logistic + NoFisher', ...
                    y,pred,score,{'HC','SZ'},files{k});

                if closeTo(candidate,[0.9167 0.9171 0.833 0.948])
                    R = candidate;
                    found = true;
                    break;
                end
            end
        end
    end

    [ok,y,pred,score] = extractSavedPredictions( ...
        S,5,{'Logistic','L2-LR','L2LR'},'',[]);

    if ok
        candidate = makeResult( ...
            'MSU01','5 s + Logistic + NoFisher', ...
            y,pred,score,{'HC','SZ'},files{k});

        if closeTo(candidate,[0.9167 0.9171 0.833 0.948])
            R = candidate;
            found = true;
            break;
        end
    end
end

if ~found
    error('未找到与 MSU01 最终主结果一致的受试者级预测。');
end
end

%% =========================================================
%% 从主结果MAT的 results / allResults 中提取预测
%% =========================================================
function [ok,y,pred,score] = extractSavedPredictions( ...
    S,targetScale,classifierNames,targetCondition,defaultY)

ok = false;
y = [];
pred = [];
score = [];

rootY = defaultY;
if isfield(S,'ySubject')
    rootY = double(S.ySubject(:));
end

containers = {'results','allResults'};

for c = 1:numel(containers)
    if ~isfield(S,containers{c})
        continue;
    end

    items = flattenItems(S.(containers{c}));

    for i = 1:numel(items)
        r = items{i};

        if ~isstruct(r) || isempty(r)
            continue;
        end

        if isfield(r,'ScaleSec') && ~isempty(r.ScaleSec)
            if double(r.ScaleSec)~=targetScale
                continue;
            end
        end

        if isfield(r,'Classifier') && ~isempty(r.Classifier)
            if ~matchClassifier(r.Classifier,classifierNames)
                continue;
            end
        end

        if ~isempty(targetCondition) && ...
                isfield(r,'Condition') && ~isempty(r.Condition)
            if string(r.Condition)~=string(targetCondition)
                continue;
            end
        end

        [pred0,score0] = getPredictionFields(r);

        if isempty(pred0) || isempty(score0)
            continue;
        end

        if isfield(r,'TrueLabel')
            y0 = double(r.TrueLabel(:));
        elseif isfield(r,'SubjectTrueLabel')
            y0 = double(r.SubjectTrueLabel(:));
        else
            y0 = rootY;
        end

        if isempty(y0) || ...
                numel(y0)~=numel(pred0) || ...
                numel(y0)~=numel(score0)
            continue;
        end

        y = double(y0(:));
        pred = double(pred0(:));
        score = double(score0(:));
        ok = true;
        return;
    end
end
end

function items = flattenItems(x)

items = {};

if iscell(x)
    for k = 1:numel(x)
        items = [items,flattenItems(x{k})]; %#ok<AGROW>
    end
elseif isstruct(x)
    for k = 1:numel(x)
        items{end+1} = x(k); %#ok<AGROW>
        f = fieldnames(x(k));

        % allResults 常见形式：结构中再嵌套结果cell
        for j = 1:numel(f)
            v = x(k).(f{j});
            if iscell(v)
                items = [items,flattenItems(v)]; %#ok<AGROW>
            end
        end
    end
end
end

function [pred,score] = getPredictionFields(r)

pred = [];
score = [];

if isfield(r,'SubjectPredictedLabel')
    pred = r.SubjectPredictedLabel;
elseif isfield(r,'PredictedLabel')
    pred = r.PredictedLabel;
end

if isfield(r,'SubjectPatientScore')
    score = r.SubjectPatientScore;
elseif isfield(r,'PatientScore')
    score = r.PatientScore;
end
end

function mask = matchClassifier(values,names)

v = upper(regexprep(string(values),'[^A-Z0-9]',''));
mask = false(size(v));

for k = 1:numel(names)
    n = upper(regexprep(string(names{k}),'[^A-Z0-9]',''));
    mask = mask | v==n;
end
end

%% =========================================================
%% 统一计算：混淆矩阵 + perfcurve ROC/AUC
%% =========================================================
function R = makeResult(task,model,y,pred,score,classNames,sourceFile)

y = double(y(:));
pred = double(pred(:));
score = double(score(:));

TN = sum(y==0 & pred==0);
FP = sum(y==0 & pred==1);
FN = sum(y==1 & pred==0);
TP = sum(y==1 & pred==1);

acc = (TP+TN)/numel(y);
sen = TP/(TP+FN);
spe = TN/(TN+FP);
ba = (sen+spe)/2;

den = sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN));
mcc = (TP*TN-FP*FN)/den;

[fpr,tpr,~,auc] = perfcurve(y,score,1);

R = struct();
R.Task = task;
R.Model = model;
R.TrueLabel = y;
R.PredLabel = pred;
R.Score = score;
R.ClassNames = classNames;
R.SourceFile = sourceFile;
R.CM = [TN FP;FN TP];
R.FPR = fpr;
R.TPR = tpr;

R.Metrics = struct( ...
    'Accuracy',acc, ...
    'Sensitivity',sen, ...
    'Specificity',spe, ...
    'BalancedAccuracy',ba, ...
    'MCC',mcc, ...
    'AUC',auc);
end

%% =========================================================
%% 指标核对
%% =========================================================
function tf = closeTo(R,target)

actual = [ ...
    R.Metrics.Accuracy, ...
    R.Metrics.BalancedAccuracy, ...
    R.Metrics.MCC, ...
    R.Metrics.AUC];

% 前三项允许四舍五入误差；AUC允许0.0015
tf = abs(actual(1)-target(1))<0.0015 && ...
     abs(actual(2)-target(2))<0.0015 && ...
     abs(actual(3)-target(3))<0.0020 && ...
     abs(actual(4)-target(4))<0.0015;
end

function checkResult(R,target)

if ~closeTo(R,target)
    error([ ...
        '%s读取出的预测与论文最终结果不一致。\n' ...
        '当前：Acc=%.4f BA=%.4f MCC=%.4f AUC=%.4f\n' ...
        '目标：Acc=%.4f BA=%.4f MCC=%.4f AUC=%.4f\n' ...
        '来源：%s'], ...
        R.Task, ...
        R.Metrics.Accuracy,R.Metrics.BalancedAccuracy, ...
        R.Metrics.MCC,R.Metrics.AUC, ...
        target(1),target(2),target(3),target(4), ...
        R.SourceFile);
end

fprintf('%s 核对通过：Acc=%.4f BA=%.4f MCC=%.4f AUC=%.4f\n', ...
    R.Task,R.Metrics.Accuracy,R.Metrics.BalancedAccuracy, ...
    R.Metrics.MCC,R.Metrics.AUC);
fprintf('  来源：%s\n\n',R.SourceFile);
end

%% =========================================================
%% 单任务图
%% =========================================================
function plotSingleResult(R,saveFile)

if isfile(saveFile)
    delete(saveFile);
end

fig = figure( ...
    'Color','w', ...
    'Position',[100 100 1260 520], ...
    'ToolBar','none', ...
    'MenuBar','none', ...
    'NumberTitle','off');

annotation(fig,'textbox',[0.08 0.930 0.84 0.045], ...
    'String',sprintf('%s | %s',R.Task,R.Model), ...
    'EdgeColor','none', ...
    'HorizontalAlignment','center', ...
    'VerticalAlignment','middle', ...
    'FontWeight','bold', ...
    'FontSize',12.5);

ax1 = axes(fig,'Position',[0.09 0.18 0.34 0.62]);
plotConfusion(ax1,R.CM,R.ClassNames);
title(ax1,'Subject-level Confusion Matrix', ...
    'FontWeight','bold','FontSize',11.5);

ax2 = axes(fig,'Position',[0.57 0.18 0.30 0.62]);
plot(ax2,R.FPR,R.TPR,'LineWidth',2);
hold(ax2,'on');
plot(ax2,[0 1],[0 1],'k--','LineWidth',1);
grid(ax2,'on');
axis(ax2,'square');
xlim(ax2,[0 1]);
ylim(ax2,[0 1]);
xlabel(ax2,'False Positive Rate');
ylabel(ax2,'True Positive Rate');
title(ax2,sprintf('ROC Curve (AUC = %.3f)',R.Metrics.AUC), ...
    'FontWeight','bold','FontSize',11.5);

text(ax2,0.62,0.12, ...
    sprintf('Acc = %.2f%%\nBalAcc = %.2f%%\nMCC = %.3f', ...
    100*R.Metrics.Accuracy, ...
    100*R.Metrics.BalancedAccuracy, ...
    R.Metrics.MCC), ...
    'Units','normalized', ...
    'BackgroundColor','w', ...
    'EdgeColor',[0.7 0.7 0.7], ...
    'Margin',6);

exportgraphics(fig,saveFile,'Resolution',300);
close(fig);
end

%% =========================================================
%% 三任务总图
%% =========================================================
function plotCombined(results,saveFile)

if isfile(saveFile)
    delete(saveFile);
end

fig = figure( ...
    'Color','w', ...
    'Position',[80 40 1260 1340], ...
    'ToolBar','none', ...
    'MenuBar','none', ...
    'NumberTitle','off');

annotation(fig,'textbox',[0.10 0.968 0.80 0.022], ...
    'String','Three Main Tasks: 5 s Best Models', ...
    'EdgeColor','none', ...
    'HorizontalAlignment','center', ...
    'FontWeight','bold', ...
    'FontSize',13);

rowBottom = [0.695 0.390 0.085];
axHeight = 0.195;

for i = 1:3
    R = results{i};

    annotation(fig,'textbox', ...
        [0.10 rowBottom(i)+axHeight+0.020 0.80 0.022], ...
        'String',sprintf('%s | %s',R.Task,R.Model), ...
        'EdgeColor','none', ...
        'HorizontalAlignment','center', ...
        'FontWeight','bold', ...
        'FontSize',10.5);

    ax1 = axes(fig,'Position',[0.09 rowBottom(i) 0.34 axHeight]);
    plotConfusion(ax1,R.CM,R.ClassNames);
    title(ax1,'Confusion Matrix','FontWeight','bold','FontSize',10);

    ax2 = axes(fig,'Position',[0.57 rowBottom(i) 0.29 axHeight]);
    plot(ax2,R.FPR,R.TPR,'LineWidth',2);
    hold(ax2,'on');
    plot(ax2,[0 1],[0 1],'k--','LineWidth',1);
    grid(ax2,'on');
    axis(ax2,'square');
    xlim(ax2,[0 1]);
    ylim(ax2,[0 1]);
    xlabel(ax2,'False Positive Rate','FontSize',9);
    ylabel(ax2,'True Positive Rate','FontSize',9);
    title(ax2,sprintf('ROC (AUC = %.3f)',R.Metrics.AUC), ...
        'FontWeight','bold','FontSize',10);
end

exportgraphics(fig,saveFile,'Resolution',300);
close(fig);
end

function plotConfusion(ax,CM,classNames)

imagesc(ax,CM);
axis(ax,'equal');
axis(ax,'tight');

set(ax, ...
    'XTick',1:2, ...
    'YTick',1:2, ...
    'XTickLabel',classNames, ...
    'YTickLabel',classNames, ...
    'XAxisLocation','bottom', ...
    'FontSize',10);

xlabel(ax,'Predicted');
ylabel(ax,'True');

for r = 1:2
    for c = 1:2
        text(ax,c,r,num2str(CM(r,c)), ...
            'HorizontalAlignment','center', ...
            'VerticalAlignment','middle', ...
            'FontWeight','bold', ...
            'FontSize',14, ...
            'Color','w');
    end
end

colorbar(ax);
end
