function Combine_Connectivity_Matrices_PerDataset_V7
% 每个数据集一张整合图
%
% V7修正：
% - 子图尽量紧挨着：Padding='none', TileSpacing='none'
% - 整体图缩小
% - 字体仍统一，但字号略缩，保证紧凑与清晰平衡
% - MPHCED02 与另外两个数据集保持同一套紧凑规则

clc;
close all;

rootDir = 'D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices';

if ~exist(rootDir,'dir')
    error('未找到结果目录：%s',rootDir);
end

fprintf('开始生成每个数据集的紧凑版整合连接矩阵图...\n');
fprintf('结果目录：%s\n\n',rootDir);

style = getStyle();

makeTwoRowFigure( ...
    fullfile(rootDir,'SAHARAN12_G01'), ...
    'SAHARAN12-G01', ...
    fullfile(rootDir,'SAHARAN12_G01_Connectivity_Combined.png'), ...
    style);

makeMPHCEDFigure( ...
    fullfile(rootDir,'MPHCED02_EC'), ...
    fullfile(rootDir,'MPHCED02_EO'), ...
    fullfile(rootDir,'MPHCED02_Connectivity_Combined.png'), ...
    style);

makeTwoRowFigure( ...
    fullfile(rootDir,'MSU01'), ...
    'MSU01', ...
    fullfile(rootDir,'MSU01_Connectivity_Combined.png'), ...
    style);

fprintf('\n全部完成。\n');
end

%% =========================================================
%% 统一样式
%% =========================================================
function style = getStyle()

style = struct();
style.FontName = 'Arial';

style.MainTitleSize = 14;
style.SubTitleSize = 10;
style.AxisFontSize = 8;
style.PanelLabelSize = 9;

style.FigureWidth = 1240;
style.RowHeight = 305;

style.Padding = 'none';
style.TileSpacing = 'none';

style.ExportResolution = 400;
end

%% =========================================================
%% G01 / MSU01：2×3
%% =========================================================
function makeTwoRowFigure(dataDir,datasetName,saveFile,style)

plvFile = fullfile(dataDir,'PLV_important_connectivity.xlsx');
gcFile = fullfile(dataDir,'Granger_important_connectivity.xlsx');

[plvC,plvP,plvD,names] = readImportantMatrices(plvFile);
[gcC,gcP,gcD,~] = readImportantMatrices(gcFile);

nRows = 2;
fig = createFigure(style,nRows);

t = tiledlayout(fig,2,3, ...
    'Padding',style.Padding, ...
    'TileSpacing',style.TileSpacing);

plvMeanLim = commonPositiveLimit(plvC,plvP);
plvDiffLim = symmetricLimit(plvD);

ax = nexttile(t);
drawMatrix(ax,plvC,names,[0 plvMeanLim],false,style);
title(ax,'PLV - Control', ...
    'FontWeight','bold', ...
    'FontName',style.FontName, ...
    'FontSize',style.SubTitleSize);
addPanelLabelBelow(ax,'(a)',style);

ax = nexttile(t);
drawMatrix(ax,plvP,names,[0 plvMeanLim],false,style);
title(ax,'PLV - Patient', ...
    'FontWeight','bold', ...
    'FontName',style.FontName, ...
    'FontSize',style.SubTitleSize);
addPanelLabelBelow(ax,'(b)',style);

ax = nexttile(t);
drawMatrix(ax,plvD,names,[-plvDiffLim plvDiffLim],true,style);
title(ax,'PLV - Patient - Control', ...
    'FontWeight','bold', ...
    'FontName',style.FontName, ...
    'FontSize',style.SubTitleSize);
addPanelLabelBelow(ax,'(c)',style);

gcMeanLim = commonPositiveLimit(gcC,gcP);
gcDiffLim = symmetricLimit(gcD);

ax = nexttile(t);
drawMatrix(ax,gcC,names,[0 gcMeanLim],false,style);
title(ax,'Granger - Control', ...
    'FontWeight','bold', ...
    'FontName',style.FontName, ...
    'FontSize',style.SubTitleSize);
addPanelLabelBelow(ax,'(d)',style);

ax = nexttile(t);
drawMatrix(ax,gcP,names,[0 gcMeanLim],false,style);
title(ax,'Granger - Patient', ...
    'FontWeight','bold', ...
    'FontName',style.FontName, ...
    'FontSize',style.SubTitleSize);
addPanelLabelBelow(ax,'(e)',style);

ax = nexttile(t);
drawMatrix(ax,gcD,names,[-gcDiffLim gcDiffLim],true,style);
title(ax,'Granger - Patient - Control', ...
    'FontWeight','bold', ...
    'FontName',style.FontName, ...
    'FontSize',style.SubTitleSize);
addPanelLabelBelow(ax,'(f)',style);

title(t, ...
    [datasetName ' | Important PLV and Granger Connections'], ...
    'FontWeight','bold', ...
    'FontName',style.FontName, ...
    'FontSize',style.MainTitleSize);

drawnow;
exportgraphics(fig,saveFile,'Resolution',style.ExportResolution);
close(fig);

fprintf('%s 完成：%s\n',datasetName,saveFile);
end

%% =========================================================
%% MPHCED02：4×3
%% =========================================================
function makeMPHCEDFigure(ecDir,eoDir,saveFile,style)

[ecPlvC,ecPlvP,ecPlvD,names] = ...
    readImportantMatrices(fullfile(ecDir,'PLV_important_connectivity.xlsx'));
[ecGcC,ecGcP,ecGcD,~] = ...
    readImportantMatrices(fullfile(ecDir,'Granger_important_connectivity.xlsx'));

[eoPlvC,eoPlvP,eoPlvD,~] = ...
    readImportantMatrices(fullfile(eoDir,'PLV_important_connectivity.xlsx'));
[eoGcC,eoGcP,eoGcD,~] = ...
    readImportantMatrices(fullfile(eoDir,'Granger_important_connectivity.xlsx'));

plvMeanLim = max( ...
    commonPositiveLimit(ecPlvC,ecPlvP), ...
    commonPositiveLimit(eoPlvC,eoPlvP));

plvDiffLim = max( ...
    symmetricLimit(ecPlvD), ...
    symmetricLimit(eoPlvD));

gcMeanLim = max( ...
    commonPositiveLimit(ecGcC,ecGcP), ...
    commonPositiveLimit(eoGcC,eoGcP));

gcDiffLim = max( ...
    symmetricLimit(ecGcD), ...
    symmetricLimit(eoGcD));

nRows = 4;
fig = createFigure(style,nRows);

t = tiledlayout(fig,4,3, ...
    'Padding',style.Padding, ...
    'TileSpacing',style.TileSpacing);

panelIndex = 1;

panelIndex = drawRow( ...
    t,ecPlvC,ecPlvP,ecPlvD,names, ...
    plvMeanLim,plvDiffLim,'EC - PLV',panelIndex,style);

panelIndex = drawRow( ...
    t,ecGcC,ecGcP,ecGcD,names, ...
    gcMeanLim,gcDiffLim,'EC - Granger',panelIndex,style);

panelIndex = drawRow( ...
    t,eoPlvC,eoPlvP,eoPlvD,names, ...
    plvMeanLim,plvDiffLim,'EO - PLV',panelIndex,style);

drawRow( ...
    t,eoGcC,eoGcP,eoGcD,names, ...
    gcMeanLim,gcDiffLim,'EO - Granger',panelIndex,style);

title(t, ...
    'MPHCED02 | Important PLV and Granger Connections', ...
    'FontWeight','bold', ...
    'FontName',style.FontName, ...
    'FontSize',style.MainTitleSize);

drawnow;
exportgraphics(fig,saveFile,'Resolution',style.ExportResolution);
close(fig);

fprintf('MPHCED02 完成：%s\n',saveFile);
end

function nextPanelIndex = drawRow( ...
    t,C,P,D,names,meanLim,diffLim,rowName,panelIndex,style)

ax = nexttile(t);
drawMatrix(ax,C,names,[0 meanLim],false,style);
title(ax,[rowName ' - Control'], ...
    'FontWeight','bold', ...
    'FontName',style.FontName, ...
    'FontSize',style.SubTitleSize);
addPanelLabelBelow(ax,panelLabel(panelIndex),style);
panelIndex = panelIndex + 1;

ax = nexttile(t);
drawMatrix(ax,P,names,[0 meanLim],false,style);
title(ax,[rowName ' - Patient'], ...
    'FontWeight','bold', ...
    'FontName',style.FontName, ...
    'FontSize',style.SubTitleSize);
addPanelLabelBelow(ax,panelLabel(panelIndex),style);
panelIndex = panelIndex + 1;

ax = nexttile(t);
drawMatrix(ax,D,names,[-diffLim diffLim],true,style);
title(ax,[rowName ' - Patient - Control'], ...
    'FontWeight','bold', ...
    'FontName',style.FontName, ...
    'FontSize',style.SubTitleSize);
addPanelLabelBelow(ax,panelLabel(panelIndex),style);
panelIndex = panelIndex + 1;

nextPanelIndex = panelIndex;
end

%% =========================================================
%% 创建Figure
%% =========================================================
function fig = createFigure(style,nRows)

figHeight = style.RowHeight * nRows;

fig = figure( ...
    'Color','w', ...
    'Position',[60 40 style.FigureWidth figHeight], ...
    'Visible','off', ...
    'ToolBar','none', ...
    'MenuBar','none', ...
    'NumberTitle','off');
end

%% =========================================================
%% Excel读取
%% =========================================================
function [C,P,D,names] = readImportantMatrices(fileName)

if ~isfile(fileName)
    error(['未找到结果文件：\n%s\n' ...
        '请先运行 Generate_Important_Connectivity_Matrices_V1。'], ...
        fileName);
end

[C,names] = readMatrixSheet(fileName,'ControlImportant');
[P,~] = readMatrixSheet(fileName,'PatientImportant');
[D,~] = readMatrixSheet(fileName,'DifferenceImportant');
end

function [M,names] = readMatrixSheet(fileName,sheetName)

T = readtable(fileName, ...
    'Sheet',sheetName, ...
    'ReadRowNames',true, ...
    'VariableNamingRule','preserve');

names = T.Properties.RowNames;
M = table2array(T);
end

%% =========================================================
%% 绘图
%% =========================================================
function drawMatrix(ax,M,names,limits,useDiverging,style)

imagesc(ax,M,'AlphaData',~isnan(M));
axis(ax,'square');

set(ax, ...
    'Color',[1 1 1], ...
    'XTick',1:numel(names), ...
    'YTick',1:numel(names), ...
    'XTickLabel',names, ...
    'YTickLabel',names, ...
    'XTickLabelRotation',45, ...
    'FontName',style.FontName, ...
    'FontSize',style.AxisFontSize, ...
    'TickLength',[0 0], ...
    'LineWidth',0.7, ...
    'Box','on');

try
    ax.Toolbar.Visible = 'off';
catch
end

try
    disableDefaultInteractivity(ax);
catch
end

if useDiverging
    colormap(ax,blueWhiteRed(256));
else
    colormap(ax,parula(256));
end

caxis(ax,limits);

cb = colorbar(ax);
cb.FontName = style.FontName;
cb.FontSize = style.AxisFontSize;
cb.LineWidth = 0.7;
end

function addPanelLabelBelow(ax,labelText,style)

xlabel(ax,labelText, ...
    'FontName',style.FontName, ...
    'FontSize',style.PanelLabelSize, ...
    'FontWeight','bold');
end

%% =========================================================
%% 色标范围
%% =========================================================
function lim = commonPositiveLimit(A,B)

values = [A(~isnan(A)); B(~isnan(B))];

if isempty(values)
    lim = 1;
    return;
end

lim = max(values);

if ~isfinite(lim) || lim<=0
    lim = 1;
end
end

function lim = symmetricLimit(A)

values = abs(A(~isnan(A)));

if isempty(values)
    lim = 1;
    return;
end

lim = max(values);

if ~isfinite(lim) || lim<=0
    lim = 1;
end
end

%% =========================================================
%% 子图标签
%% =========================================================
function txt = panelLabel(index)

letters = 'abcdefghijklmnopqrstuvwxyz';

if index<=numel(letters)
    txt = ['(' letters(index) ')'];
else
    txt = ['(' num2str(index) ')'];
end
end

%% =========================================================
%% 红-白-蓝差异色图
%% =========================================================
function cmap = blueWhiteRed(m)

if nargin<1
    m = 256;
end

x = [0 0.5 1];

r = interp1(x,[0 1 1],linspace(0,1,m));
g = interp1(x,[0 1 0],linspace(0,1,m));
b = interp1(x,[1 1 0],linspace(0,1,m));

cmap = [r(:) g(:) b(:)];
end
