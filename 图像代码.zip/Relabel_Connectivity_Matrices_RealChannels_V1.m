function Relabel_Connectivity_Matrices_RealChannels_V1
% ============================================================
% 将三个数据集的重要 PLV / Granger 连接矩阵中的 Ch1...ChN
% 替换为真实 EEG 通道名称，并重新生成整合图。
%
% 不重新计算任何 PLV / Granger 数值，仅修改行列标签。
%
% 输入目录：
% D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices
%
% 会直接覆盖以下 Excel 工作簿中的 3 个矩阵 sheet：
%   ControlImportant
%   PatientImportant
%   DifferenceImportant
%
% 会重新覆盖：
%   SAHARAN12_G01_Connectivity_Combined.png
%   MPHCED02_Connectivity_Combined.png
%   MSU01_Connectivity_Combined.png
%
% 真实通道顺序：
%
% G01 / EMOTIV EPOC：
% 1 AF3, 2 F7, 3 F3, 4 FC5, 5 T7, 6 P7, 7 O1,
% 8 O2, 9 P8, 10 T8, 11 FC6, 12 F4, 13 F8, 14 AF4
%
% MPHCED02：
% 1 Fp1, 2 F3, 3 C3, 4 P3, 5 O1, 6 F7, 7 T3, 8 T5,
% 9 Fz, 10 Fp2, 11 F4, 12 C4, 13 P4, 14 O2, 15 F8,
% 16 T4, 17 T6, 18 Cz, 19 Pz
%
% MSU01：
% 1 F7, 2 F3, 3 F4, 4 F8, 5 T3, 6 C3, 7 Cz, 8 C4,
% 9 T4, 10 T5, 11 P3, 12 Pz, 13 P4, 14 T6, 15 O1, 16 O2
%
% 重要：
% G01 的矩阵标签替换采用 EMOTIV EPOC 原始通道顺序。
% 如果你的原始 G_data 导入阶段曾经重排过 14 个通道，
% 请先修改下面 g01Names 的顺序后再运行。
% ============================================================

clc;
close all;

rootDir = 'D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices';

if ~isfolder(rootDir)
    error('未找到连接矩阵目录：%s', rootDir);
end

%% ============================================================
% 1. 三个数据集的真实通道顺序
%% ============================================================

g01Names = { ...
    'AF3','F7','F3','FC5','T7','P7','O1', ...
    'O2','P8','T8','FC6','F4','F8','AF4'};

mphcedNames = { ...
    'Fp1','F3','C3','P3','O1','F7','T3','T5','Fz', ...
    'Fp2','F4','C4','P4','O2','F8','T4','T6','Cz','Pz'};

msuNames = { ...
    'F7','F3','F4','F8','T3','C3','Cz','C4','T4', ...
    'T5','P3','Pz','P4','T6','O1','O2'};

fprintf('====================================================\n');
fprintf('开始替换三个数据集连接矩阵的真实 EEG 通道名称\n');
fprintf('仅修改标签，不改变任何矩阵数值。\n');
fprintf('====================================================\n\n');

%% ============================================================
% 2. SAHARAN12-G01
%% ============================================================

g01Dir = fullfile(rootDir,'SAHARAN12_G01');

fprintf('\n========== SAHARAN12-G01 ==========\n');

relabelConnectivityWorkbook( ...
    fullfile(g01Dir,'PLV_important_connectivity.xlsx'), ...
    g01Names,'SAHARAN12-G01 PLV');

relabelConnectivityWorkbook( ...
    fullfile(g01Dir,'Granger_important_connectivity.xlsx'), ...
    g01Names,'SAHARAN12-G01 Granger');

%% ============================================================
% 3. MPHCED02 EC / EO
%% ============================================================

ecDir = fullfile(rootDir,'MPHCED02_EC');
eoDir = fullfile(rootDir,'MPHCED02_EO');

fprintf('\n========== MPHCED02-EC ==========\n');

relabelConnectivityWorkbook( ...
    fullfile(ecDir,'PLV_important_connectivity.xlsx'), ...
    mphcedNames,'MPHCED02-EC PLV');

relabelConnectivityWorkbook( ...
    fullfile(ecDir,'Granger_important_connectivity.xlsx'), ...
    mphcedNames,'MPHCED02-EC Granger');

fprintf('\n========== MPHCED02-EO ==========\n');

relabelConnectivityWorkbook( ...
    fullfile(eoDir,'PLV_important_connectivity.xlsx'), ...
    mphcedNames,'MPHCED02-EO PLV');

relabelConnectivityWorkbook( ...
    fullfile(eoDir,'Granger_important_connectivity.xlsx'), ...
    mphcedNames,'MPHCED02-EO Granger');

%% ============================================================
% 4. MSU01
%% ============================================================

msuDir = fullfile(rootDir,'MSU01');

fprintf('\n========== MSU01 ==========\n');

relabelConnectivityWorkbook( ...
    fullfile(msuDir,'PLV_important_connectivity.xlsx'), ...
    msuNames,'MSU01 PLV');

relabelConnectivityWorkbook( ...
    fullfile(msuDir,'Granger_important_connectivity.xlsx'), ...
    msuNames,'MSU01 Granger');

%% ============================================================
% 5. 重新生成三张整合图，覆盖原图
%% ============================================================

fprintf('\n====================================================\n');
fprintf('Excel 标签替换完成，开始重新生成连接矩阵图...\n');
fprintf('====================================================\n');

makeTwoRowFigure( ...
    g01Dir, ...
    'SAHARAN12-G01', ...
    g01Names, ...
    fullfile(rootDir,'SAHARAN12_G01_Connectivity_Combined.png'));

makeMPHCEDFigure( ...
    ecDir, ...
    eoDir, ...
    mphcedNames, ...
    fullfile(rootDir,'MPHCED02_Connectivity_Combined.png'));

makeTwoRowFigure( ...
    msuDir, ...
    'MSU01', ...
    msuNames, ...
    fullfile(rootDir,'MSU01_Connectivity_Combined.png'));

%% ============================================================
% 6. 输出映射核对文件
%% ============================================================

reportFile = fullfile(rootDir,'Real_Channel_Name_Mapping.txt');

fid = fopen(reportFile,'w','n','UTF-8');

if fid >= 0

    fprintf(fid,'Real EEG channel mapping used for connectivity matrices\n');
    fprintf(fid,'Generated: %s\n\n',datestr(now));

    writeMapping(fid,'SAHARAN12-G01',g01Names);
    writeMapping(fid,'MPHCED02',mphcedNames);
    writeMapping(fid,'MSU01',msuNames);

    fprintf(fid,['NOTE FOR G01:\n' ...
        'The mapping assumes that Ch1-Ch14 preserve the original ' ...
        'EMOTIV EPOC channel order.\n']);

    fclose(fid);
end

fprintf('\n====================================================\n');
fprintf('全部完成。\n');
fprintf('映射核对文件：%s\n',reportFile);
fprintf('====================================================\n');

end


%% ============================================================
% 修改 Excel 中矩阵 sheet 的行列名称
%% ============================================================
function relabelConnectivityWorkbook(fileName,channelNames,description)

if ~isfile(fileName)
    error('未找到文件：%s',fileName);
end

sheetNames = { ...
    'ControlImportant', ...
    'PatientImportant', ...
    'DifferenceImportant'};

nExpected = numel(channelNames);

fprintf('\n%s\n',description);
fprintf('文件：%s\n',fileName);

for s = 1:numel(sheetNames)

    sheetName = sheetNames{s};

    T = readtable( ...
        fileName, ...
        'Sheet',sheetName, ...
        'ReadRowNames',true, ...
        'VariableNamingRule','preserve');

    M = table2array(T);

    if size(M,1) ~= nExpected || size(M,2) ~= nExpected

        error([ ...
            '%s 的 %s 尺寸为 %d×%d，但真实通道数为 %d。\n' ...
            '程序已停止，未对该 sheet 进行错误重标。'], ...
            fileName,sheetName,size(M,1),size(M,2),nExpected);
    end

    % 记录原来的标签，便于命令行核对
    oldNames = T.Properties.RowNames;

    fprintf('  %s：%d×%d\n',sheetName,size(M,1),size(M,2));

    if ~isempty(oldNames)
        fprintf('    原标签：%s ... %s\n', ...
            oldNames{1},oldNames{end});
    end

    fprintf('    新标签：%s ... %s\n', ...
        channelNames{1},channelNames{end});

    % 数值矩阵完全保持不变，仅重建行列名称
    Tout = array2table( ...
        M, ...
        'VariableNames',channelNames);

    Tout.Properties.RowNames = channelNames(:);

    % 只覆盖当前 sheet，不删除工作簿中的其他 sheet
    writetable( ...
        Tout, ...
        fileName, ...
        'Sheet',sheetName, ...
        'WriteRowNames',true, ...
        'WriteMode','overwritesheet');
end

% 写完后重新读取一次，验证
Tcheck = readtable( ...
    fileName, ...
    'Sheet','ControlImportant', ...
    'ReadRowNames',true, ...
    'VariableNamingRule','preserve');

if ~isequal(Tcheck.Properties.RowNames(:),channelNames(:))
    error('%s 写入后行名称校验失败。',description);
end

if ~isequal(Tcheck.Properties.VariableNames(:),channelNames(:))
    error('%s 写入后列名称校验失败。',description);
end

fprintf('  -> 行列标签替换并校验成功。\n');

end


%% ============================================================
% G01 / MSU01：2×3
%% ============================================================
function makeTwoRowFigure(dataDir,datasetName,names,saveFile)

[plvC,plvP,plvD] = readImportantMatrices( ...
    fullfile(dataDir,'PLV_important_connectivity.xlsx'),names);

[gcC,gcP,gcD] = readImportantMatrices( ...
    fullfile(dataDir,'Granger_important_connectivity.xlsx'),names);

fig = figure( ...
    'Color','w', ...
    'Position',[80 80 1500 980], ...
    'Visible','off', ...
    'ToolBar','none', ...
    'MenuBar','none', ...
    'NumberTitle','off');

t = tiledlayout(fig,2,3, ...
    'Padding','loose', ...
    'TileSpacing','loose');

%% PLV
plvMeanLim = commonPositiveLimit(plvC,plvP);
plvDiffLim = symmetricLimit(plvD);

ax = nexttile(t);
drawMatrix(ax,plvC,names,[0 plvMeanLim],false);
title(ax,'PLV - Control','FontWeight','bold');
addPanelLabelBelow(ax,'(a)');

ax = nexttile(t);
drawMatrix(ax,plvP,names,[0 plvMeanLim],false);
title(ax,'PLV - Patient','FontWeight','bold');
addPanelLabelBelow(ax,'(b)');

ax = nexttile(t);
drawMatrix(ax,plvD,names,[-plvDiffLim plvDiffLim],true);
title(ax,'PLV - Patient - Control','FontWeight','bold');
addPanelLabelBelow(ax,'(c)');

%% Granger
gcMeanLim = commonPositiveLimit(gcC,gcP);
gcDiffLim = symmetricLimit(gcD);

ax = nexttile(t);
drawMatrix(ax,gcC,names,[0 gcMeanLim],false);
title(ax,'Granger - Control','FontWeight','bold');
addPanelLabelBelow(ax,'(d)');

ax = nexttile(t);
drawMatrix(ax,gcP,names,[0 gcMeanLim],false);
title(ax,'Granger - Patient','FontWeight','bold');
addPanelLabelBelow(ax,'(e)');

ax = nexttile(t);
drawMatrix(ax,gcD,names,[-gcDiffLim gcDiffLim],true);
title(ax,'Granger - Patient - Control','FontWeight','bold');
addPanelLabelBelow(ax,'(f)');

title(t, ...
    [datasetName ' | Important PLV and Granger Connections'], ...
    'FontWeight','bold', ...
    'FontSize',15);

drawnow;
exportgraphics(fig,saveFile,'Resolution',300);
close(fig);

fprintf('%s 图已覆盖：%s\n',datasetName,saveFile);

end


%% ============================================================
% MPHCED02：4×3
%% ============================================================
function makeMPHCEDFigure(ecDir,eoDir,names,saveFile)

[ecPlvC,ecPlvP,ecPlvD] = readImportantMatrices( ...
    fullfile(ecDir,'PLV_important_connectivity.xlsx'),names);

[ecGcC,ecGcP,ecGcD] = readImportantMatrices( ...
    fullfile(ecDir,'Granger_important_connectivity.xlsx'),names);

[eoPlvC,eoPlvP,eoPlvD] = readImportantMatrices( ...
    fullfile(eoDir,'PLV_important_connectivity.xlsx'),names);

[eoGcC,eoGcP,eoGcD] = readImportantMatrices( ...
    fullfile(eoDir,'Granger_important_connectivity.xlsx'),names);

plvMeanLim = max( ...
    commonPositiveLimit(ecPlvC,ecPlvP), ...
    commonPositiveLimit(eoPlvC,eoPlvP));

plvDiffLim = max( ...
    symmetricLimit(ecPlvD), ...
    symmetricLimit(eoPlvD));

gcMeanLim = max( ...
    commonPositiveLimit(ecGcC,ecGcP), ...
    commonPositiveLimit(eoGcC,eoGcP));

gcDiffLim = max( ...
    symmetricLimit(ecGcD), ...
    symmetricLimit(eoGcD));

fig = figure( ...
    'Color','w', ...
    'Position',[60 20 1500 1800], ...
    'Visible','off', ...
    'ToolBar','none', ...
    'MenuBar','none', ...
    'NumberTitle','off');

t = tiledlayout(fig,4,3, ...
    'Padding','loose', ...
    'TileSpacing','loose');

panelIndex = 1;

panelIndex = drawRow( ...
    t,ecPlvC,ecPlvP,ecPlvD,names, ...
    plvMeanLim,plvDiffLim,'EC - PLV',panelIndex);

panelIndex = drawRow( ...
    t,ecGcC,ecGcP,ecGcD,names, ...
    gcMeanLim,gcDiffLim,'EC - Granger',panelIndex);

panelIndex = drawRow( ...
    t,eoPlvC,eoPlvP,eoPlvD,names, ...
    plvMeanLim,plvDiffLim,'EO - PLV',panelIndex);

drawRow( ...
    t,eoGcC,eoGcP,eoGcD,names, ...
    gcMeanLim,gcDiffLim,'EO - Granger',panelIndex);

title(t, ...
    'MPHCED02 | Important PLV and Granger Connections', ...
    'FontWeight','bold', ...
    'FontSize',15);

drawnow;
exportgraphics(fig,saveFile,'Resolution',300);
close(fig);

fprintf('MPHCED02 图已覆盖：%s\n',saveFile);

end


function nextPanelIndex = drawRow( ...
    t,C,P,D,names,meanLim,diffLim,rowName,panelIndex)

ax = nexttile(t);
drawMatrix(ax,C,names,[0 meanLim],false);
title(ax,[rowName ' - Control'],'FontWeight','bold');
addPanelLabelBelow(ax,panelLabel(panelIndex));
panelIndex = panelIndex + 1;

ax = nexttile(t);
drawMatrix(ax,P,names,[0 meanLim],false);
title(ax,[rowName ' - Patient'],'FontWeight','bold');
addPanelLabelBelow(ax,panelLabel(panelIndex));
panelIndex = panelIndex + 1;

ax = nexttile(t);
drawMatrix(ax,D,names,[-diffLim diffLim],true);
title(ax,[rowName ' - Patient - Control'],'FontWeight','bold');
addPanelLabelBelow(ax,panelLabel(panelIndex));
panelIndex = panelIndex + 1;

nextPanelIndex = panelIndex;

end


%% ============================================================
% 读取矩阵并再次核验通道标签
%% ============================================================
function [C,P,D] = readImportantMatrices(fileName,expectedNames)

C = readMatrixSheet(fileName,'ControlImportant',expectedNames);
P = readMatrixSheet(fileName,'PatientImportant',expectedNames);
D = readMatrixSheet(fileName,'DifferenceImportant',expectedNames);

end


function M = readMatrixSheet(fileName,sheetName,expectedNames)

T = readtable( ...
    fileName, ...
    'Sheet',sheetName, ...
    'ReadRowNames',true, ...
    'VariableNamingRule','preserve');

M = table2array(T);

n = numel(expectedNames);

if size(M,1)~=n || size(M,2)~=n
    error('%s / %s 的矩阵维数不是 %d×%d。', ...
        fileName,sheetName,n,n);
end

if ~isequal(T.Properties.RowNames(:),expectedNames(:))
    error('%s / %s 的行标签与预期真实通道名不一致。', ...
        fileName,sheetName);
end

if ~isequal(T.Properties.VariableNames(:),expectedNames(:))
    error('%s / %s 的列标签与预期真实通道名不一致。', ...
        fileName,sheetName);
end

end


%% ============================================================
% 绘图
%% ============================================================
function drawMatrix(ax,M,names,limits,useDiverging)

imagesc(ax,M,'AlphaData',~isnan(M));
axis(ax,'square');

set(ax, ...
    'Color',[1 1 1], ...
    'XTick',1:numel(names), ...
    'YTick',1:numel(names), ...
    'XTickLabel',names, ...
    'YTickLabel',names, ...
    'XTickLabelRotation',45, ...
    'FontName','Times New Roman', ...
    'FontSize',8, ...
    'TickLength',[0 0]);

try
    ax.Toolbar.Visible = 'off';
catch
end

try
    disableDefaultInteractivity(ax);
catch
end

if useDiverging
    colormap(ax,blueWhiteRed(256));
else
    colormap(ax,parula(256));
end

caxis(ax,limits);

cb = colorbar(ax);
cb.FontName = 'Times New Roman';
cb.FontSize = 8;

end


function addPanelLabelBelow(ax,labelText)

xlabel(ax,labelText, ...
    'FontName','Times New Roman', ...
    'FontSize',11, ...
    'FontWeight','bold');

end


%% ============================================================
% 色标
%% ============================================================
function lim = commonPositiveLimit(A,B)

values = [A(~isnan(A)); B(~isnan(B))];

if isempty(values)
    lim = 1;
    return;
end

lim = max(values);

if ~isfinite(lim) || lim<=0
    lim = 1;
end

end


function lim = symmetricLimit(A)

values = abs(A(~isnan(A)));

if isempty(values)
    lim = 1;
    return;
end

lim = max(values);

if ~isfinite(lim) || lim<=0
    lim = 1;
end

end


%% ============================================================
% 子图标签
%% ============================================================
function txt = panelLabel(index)

letters = 'abcdefghijklmnopqrstuvwxyz';

if index<=numel(letters)
    txt = ['(' letters(index) ')'];
else
    txt = ['(' num2str(index) ')'];
end

end


%% ============================================================
% 红-白-蓝色图
%% ============================================================
function cmap = blueWhiteRed(m)

if nargin<1
    m = 256;
end

x = [0 0.5 1];

r = interp1(x,[0 1 1],linspace(0,1,m));
g = interp1(x,[0 1 0],linspace(0,1,m));
b = interp1(x,[1 1 0],linspace(0,1,m));

cmap = [r(:) g(:) b(:)];

end


%% ============================================================
% 映射报告
%% ============================================================
function writeMapping(fid,datasetName,names)

fprintf(fid,'%s\n',datasetName);

for i = 1:numel(names)
    fprintf(fid,'Ch%d -> %s\n',i,names{i});
end

fprintf(fid,'\n');

end
