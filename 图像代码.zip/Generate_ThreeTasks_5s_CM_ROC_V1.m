function Generate_ThreeTasks_5s_CM_ROC_V1
% 三个主任务 5s 最佳模型：受试者级混淆矩阵 + ROC曲线
%
% 输出：
% 1) G01_5s_RBFSVM_CM_ROC.png
% 2) MPHCED02_EC_EO_5s_LDA_CM_ROC.png
% 3) MSU01_5s_Logistic_NoFisher_CM_ROC.png
% 4) ThreeTasks_5s_CM_ROC_Combined.png
% 5) ThreeTasks_5s_CM_ROC_Summary.xlsx
%
% 最佳模型固定为：
% - SAHARAN12-G01：5s + RBF-SVM + Fisher Top50
% - MPHCED02-EC_EO：5s + LDA + Fisher Top15
% - MSU01：5s + Logistic + NoFisher

clc;
close all;

outDir = 'D:\Database\EEG_Paper_Figures\ThreeTasks_5s_CM_ROC';
if ~exist(outDir,'dir')
    mkdir(outDir);
end

fprintf('开始生成三个主任务 5s 最佳模型的受试者级混淆矩阵和ROC曲线...\n');
fprintf('输出目录：%s\n\n',outDir);

R1 = runG01_5s_RBFSVM();
R2 = runMPHCED02_ECEO_5s_LDA();
R3 = runMSU01_5s_Logistic_NoFisher();

plotSingleResult(R1,fullfile(outDir,'G01_5s_RBFSVM_CM_ROC.png'));
plotSingleResult(R2,fullfile(outDir,'MPHCED02_EC_EO_5s_LDA_CM_ROC.png'));
plotSingleResult(R3,fullfile(outDir,'MSU01_5s_Logistic_NoFisher_CM_ROC.png'));
plotCombined({R1,R2,R3},fullfile(outDir,'ThreeTasks_5s_CM_ROC_Combined.png'));

summaryTable = table( ...
    string({R1.Task;R2.Task;R3.Task}), ...
    string({R1.Model;R2.Model;R3.Model}), ...
    [R1.CM(1,1);R2.CM(1,1);R3.CM(1,1)], ...
    [R1.CM(1,2);R2.CM(1,2);R3.CM(1,2)], ...
    [R1.CM(2,1);R2.CM(2,1);R3.CM(2,1)], ...
    [R1.CM(2,2);R2.CM(2,2);R3.CM(2,2)], ...
    [R1.Metrics.Accuracy;R2.Metrics.Accuracy;R3.Metrics.Accuracy], ...
    [R1.Metrics.Sensitivity;R2.Metrics.Sensitivity;R3.Metrics.Sensitivity], ...
    [R1.Metrics.Specificity;R2.Metrics.Specificity;R3.Metrics.Specificity], ...
    [R1.Metrics.BalancedAccuracy;R2.Metrics.BalancedAccuracy;R3.Metrics.BalancedAccuracy], ...
    [R1.Metrics.MCC;R2.Metrics.MCC;R3.Metrics.MCC], ...
    [R1.Metrics.AUC;R2.Metrics.AUC;R3.Metrics.AUC], ...
    'VariableNames',{'Task','Model','TN','FP','FN','TP', ...
    'Accuracy','Sensitivity','Specificity','BalancedAccuracy','MCC','AUC'});

writetable(summaryTable, ...
    fullfile(outDir,'ThreeTasks_5s_CM_ROC_Summary.xlsx'), ...
    'FileType','spreadsheet');

fprintf('\n已完成。\n');
disp(summaryTable);
end

%% =========================================================
%% G01：5s + RBF-SVM + Fisher Top50
%% =========================================================
function result = runG01_5s_RBFSVM()

rootDir = 'D:\Database\Seizure\SAHARAN\SAHARAN12\G01';
featureFile = fullfile(rootDir,'G01_window_features_V1.mat');
labelFile = 'D:\Database\Seizure\SAHARAN\G_dataLable.mat';

F = load(featureFile,'featureSets','labelSets','subjectSets','windowSecs');
L = load(labelFile,'dataLable');
ySubject = double(L.dataLable(:));

scaleIndex = find(double(F.windowSecs(:))==5,1);
X = double(F.featureSets{scaleIndex});
yWindow = double(F.labelSets{scaleIndex}(:));
subjectWindow = double(F.subjectSets{scaleIndex}(:));

valid = subjectWindow>0;
X = X(valid,:);
yWindow = yWindow(valid);
subjectWindow = subjectWindow(valid);

nSubjects = numel(ySubject);
subjectPred = zeros(nSubjects,1);
subjectScore = zeros(nSubjects,1);

for heldOut = 1:nSubjects
    trainMask = subjectWindow~=heldOut;
    testMask = subjectWindow==heldOut;

    XTrain = X(trainMask,:);
    yTrain = yWindow(trainMask);
    XTest = X(testMask,:);

    med = finiteColumnMedian(XTrain);
    XTrain = replaceNonfinite(XTrain,med);
    XTest = replaceNonfinite(XTest,med);

    mu = mean(XTrain,1);
    sigma = std(XTrain,0,1);
    sigma(sigma<1e-12) = 1;
    XTrain = (XTrain-mu)./sigma;
    XTest = (XTest-mu)./sigma;

    fisherScore = calculateFisherScore(XTrain,yTrain);
    [~,ranked] = sort(fisherScore,'descend');
    selected = ranked(1:min(50,size(XTrain,2)));

    model = fitcsvm( ...
        XTrain(:,selected),yTrain, ...
        'KernelFunction','rbf', ...
        'KernelScale','auto', ...
        'BoxConstraint',1, ...
        'ClassNames',[0;1]);

    [~,score] = predict(model,XTest(:,selected));
    positiveCol = find(model.ClassNames==1,1);
    winScore = score(:,positiveCol);

    subjectScore(heldOut) = mean(winScore);
    subjectPred(heldOut) = double(subjectScore(heldOut)>=0);
end

result = packResult( ...
    'SAHARAN12-G01', ...
    '5 s + RBF-SVM + Fisher Top50', ...
    ySubject,subjectPred,subjectScore, ...
    {'Non-Patient','Patient'});
end

%% =========================================================
%% MPHCED02：EC_EO + 5s + LDA + Fisher Top15
%% =========================================================
function result = runMPHCED02_ECEO_5s_LDA()

rng(20260725,'twister');

rootDir = 'D:\Database\Depression\MPHCED\MPHCED02';
baseDir = 'F:\Database\MPHCED-Depression\MDD Patients and Healthy Controls EEG Data';

featureCandidates = { ...
    fullfile(rootDir,'MPHCED02_subject_features_V3.mat'), ...
    fullfile(rootDir,'MPHCED02_subject_features_V2.mat')};

sourceFeatureFile = '';
for k = 1:numel(featureCandidates)
    if isfile(featureCandidates{k})
        sourceFeatureFile = featureCandidates{k};
        break;
    end
end
if isempty(sourceFeatureFile)
    error('未找到MPHCED02受试者级特征文件。');
end

S = load(sourceFeatureFile,'stateFeatures','windowSecs');
scaleIndex = find(double(S.windowSecs(:))==5,1);

ECsubjects = string(S.stateFeatures.EC.Subjects(:));
EOsubjects = string(S.stateFeatures.EO.Subjects(:));
subjects = intersect(ECsubjects,EOsubjects,'stable');

[~,ecIndex] = ismember(subjects,ECsubjects);
[~,eoIndex] = ismember(subjects,EOsubjects);

labelsEC = double(S.stateFeatures.EC.Labels(ecIndex));
labelsEO = double(S.stateFeatures.EO.Labels(eoIndex));
if any(labelsEC~=labelsEO)
    error('EC与EO共同受试者标签不一致。');
end

XEC = double(S.stateFeatures.EC.FeatureSets{scaleIndex}(ecIndex,:));
XEO = double(S.stateFeatures.EO.FeatureSets{scaleIndex}(eoIndex,:));
X = [XEC,XEO];
y = labelsEC(:);

covariates = [];
covariateCandidates = { ...
    fullfile(baseDir,'MPHCED_subject_covariates.csv'), ...
    fullfile(rootDir,'MPHCED_subject_covariates.csv')};
covFile = '';
for k = 1:numel(covariateCandidates)
    if isfile(covariateCandidates{k})
        covFile = covariateCandidates{k};
        break;
    end
end
if ~isempty(covFile)
    covTable = readtable(covFile,'VariableNamingRule','preserve');
    T = table(string(covTable.SubjectID(:)), ...
        double(covTable.Age(:)),double(covTable.GenderMale1(:)), ...
        'VariableNames',{'SubjectID','Age','GenderMale1'});
    covariates = zeros(numel(subjects),2);
    for k = 1:numel(subjects)
        row = find(T.SubjectID==subjects(k));
        covariates(k,:) = [T.Age(row),T.GenderMale1(row)];
    end
end

nSubjects = numel(y);
pred = zeros(nSubjects,1);
scoreOut = zeros(nSubjects,1);

for heldOut = 1:nSubjects
    trainMask = true(nSubjects,1);
    trainMask(heldOut) = false;

    XTrain = X(trainMask,:);
    XTest = X(heldOut,:);
    yTrain = y(trainMask);

    med = finiteColumnMedian(XTrain);
    XTrain = replaceNonfinite(XTrain,med);
    XTest = replaceNonfinite(XTest,med);

    if ~isempty(covariates)
        [XTrain,XTest] = correctConfoundsTrainingOnly( ...
            XTrain,XTest,covariates(trainMask,:),covariates(heldOut,:));
    end

    mu = mean(XTrain,1);
    sigma = std(XTrain,0,1);
    sigma(sigma<1e-12) = 1;
    XTrain = (XTrain-mu)./sigma;
    XTest = (XTest-mu)./sigma;

    fisherScore = calculateFisherScore(XTrain,yTrain);
    [~,ranked] = sort(fisherScore,'descend');
    selected = ranked(1:min(15,size(XTrain,2)));

    model = fitcdiscr( ...
        XTrain(:,selected),yTrain, ...
        'DiscrimType','linear', ...
        'Gamma',0.1, ...
        'ClassNames',[0;1]);

    [~,score] = predict(model,XTest(:,selected));
    positiveCol = find(model.ClassNames==1,1);
    scoreOut(heldOut) = score(:,positiveCol);
    pred(heldOut) = double(scoreOut(heldOut)>=0.5);
end

result = packResult( ...
    'MPHCED02-EC_EO', ...
    '5 s + LDA + Fisher Top15', ...
    y,pred,scoreOut, ...
    {'HC','MDD'});
end

%% =========================================================
%% MSU01：5s + Logistic + NoFisher
%% =========================================================
function result = runMSU01_5s_Logistic_NoFisher()

rng(20260727,'twister');

rootDir = 'D:\Database\Schizophrenia\MSU\MSU01';
featureFile = fullfile(rootDir,'MSU01_window_features_V1.mat');

F = load(featureFile, ...
    'featureSets','labelSets','subjectSets','windowSecs','ySubject');

scaleIndex = find(double(F.windowSecs(:))==5,1);

X = double(F.featureSets{scaleIndex});
yWindow = double(F.labelSets{scaleIndex}(:));
subjectWindow = double(F.subjectSets{scaleIndex}(:));
ySubject = double(F.ySubject(:));

valid = subjectWindow>0;
X = X(valid,:);
yWindow = yWindow(valid);
subjectWindow = subjectWindow(valid);

nSubjects = numel(ySubject);
subjectPred = zeros(nSubjects,1);
subjectScore = zeros(nSubjects,1);

for heldOut = 1:nSubjects
    trainMask = subjectWindow~=heldOut;
    testMask = subjectWindow==heldOut;

    XTrain = X(trainMask,:);
    yTrain = yWindow(trainMask);
    XTest = X(testMask,:);

    med = finiteColumnMedian(XTrain);
    XTrain = replaceNonfinite(XTrain,med);
    XTest = replaceNonfinite(XTest,med);

    mu = mean(XTrain,1);
    sigma = std(XTrain,0,1);
    sigma(sigma<1e-12) = 1;
    XTrain = (XTrain-mu)./sigma;
    XTest = (XTest-mu)./sigma;

    model = fitclinear( ...
        XTrain,yTrain, ...
        'Learner','logistic', ...
        'Regularization','ridge', ...
        'Lambda',1e-3, ...
        'ClassNames',[0;1]);

    [~,score] = predict(model,XTest);
    positiveCol = find(model.ClassNames==1,1);
    winScore = score(:,positiveCol);

    subjectScore(heldOut) = mean(winScore);
    subjectPred(heldOut) = double(subjectScore(heldOut)>=0.5);
end

result = packResult( ...
    'MSU01', ...
    '5 s + Logistic + NoFisher', ...
    ySubject,subjectPred,subjectScore, ...
    {'HC','SZ'});
end

%% =========================================================
%% 打包结果
%% =========================================================
function result = packResult(taskName,modelName,trueLabel,predLabel,score,classNames)

metrics = calculateMetrics(trueLabel,predLabel,score);
[fpr,tpr,auc] = buildROC(trueLabel,score);
metrics.AUC = auc;

result = struct();
result.Task = taskName;
result.Model = modelName;
result.TrueLabel = trueLabel(:);
result.PredLabel = predLabel(:);
result.Score = score(:);
result.CM = metrics.ConfusionMatrix;
result.Metrics = metrics;
result.FPR = fpr;
result.TPR = tpr;
result.ClassNames = classNames;
end

%% =========================================================
%% 画单图
%% =========================================================
function plotSingleResult(R,saveFile)

fig = figure('Color','w','Position',[100 100 1100 420]);
tiledlayout(1,2,'Padding','compact','TileSpacing','compact');

nexttile;
plotConfusion(R.CM,R.ClassNames);
title(sprintf('%s\nSubject-level Confusion Matrix',R.Task), ...
    'FontWeight','bold');

nexttile;
plot(R.FPR,R.TPR,'LineWidth',2);
hold on;
plot([0 1],[0 1],'k--','LineWidth',1);
grid on;
axis square;
xlim([0 1]); ylim([0 1]);
xlabel('False Positive Rate');
ylabel('True Positive Rate');
title(sprintf('%s\nROC Curve (AUC = %.4f)',R.Task,R.Metrics.AUC), ...
    'FontWeight','bold');
text(0.62,0.12, ...
    sprintf(['Acc = %.2f%%\nBalAcc = %.2f%%\nMCC = %.3f'], ...
    100*R.Metrics.Accuracy,100*R.Metrics.BalancedAccuracy,R.Metrics.MCC), ...
    'Units','normalized', ...
    'BackgroundColor','w', ...
    'EdgeColor',[0.7 0.7 0.7], ...
    'Margin',6);

sgtitle(sprintf('%s | %s',R.Task,R.Model),'FontWeight','bold');
exportgraphics(fig,saveFile,'Resolution',300);
close(fig);
end

%% =========================================================
%% 画总图
%% =========================================================
function plotCombined(results,saveFile)

fig = figure('Color','w','Position',[80 40 1200 1200]);
tiledlayout(3,2,'Padding','compact','TileSpacing','compact');

for i = 1:3
    R = results{i};

    nexttile;
    plotConfusion(R.CM,R.ClassNames);
    title(sprintf('%s\nConfusion Matrix',R.Task),'FontWeight','bold');

    nexttile;
    plot(R.FPR,R.TPR,'LineWidth',2);
    hold on;
    plot([0 1],[0 1],'k--','LineWidth',1);
    grid on;
    axis square;
    xlim([0 1]); ylim([0 1]);
    xlabel('False Positive Rate');
    ylabel('True Positive Rate');
    title(sprintf('%s\nROC (AUC = %.4f)',R.Task,R.Metrics.AUC), ...
        'FontWeight','bold');
end

sgtitle('Three Main Tasks: 5 s Best Models', ...
    'FontWeight','bold','FontSize',14);
exportgraphics(fig,saveFile,'Resolution',300);
close(fig);
end

function plotConfusion(CM,classNames)

imagesc(CM);
axis equal tight;
set(gca,'XTick',1:2,'YTick',1:2, ...
    'XTickLabel',classNames,'YTickLabel',classNames, ...
    'XAxisLocation','top','FontSize',11);
xlabel('Predicted');
ylabel('True');

for r = 1:2
    for c = 1:2
        text(c,r,num2str(CM(r,c)), ...
            'HorizontalAlignment','center', ...
            'FontWeight','bold', ...
            'FontSize',14, ...
            'Color','w');
    end
end
colorbar;
end

%% =========================================================
%% 通用工具
%% =========================================================
function score = calculateFisherScore(X,y)
class0 = X(y==0,:);
class1 = X(y==1,:);
score = (mean(class1,1)-mean(class0,1)).^2 ./ ...
    (var(class0,0,1)+var(class1,0,1)+eps);
score(~isfinite(score)) = 0;
end

function [trainCorrected,testCorrected] = ...
    correctConfoundsTrainingOnly(XTrain,XTest,covTrain,covTest)

covMean = mean(covTrain,1);
covStd = std(covTrain,0,1);
covStd(covStd<1e-12) = 1;

covTrainZ = (covTrain-covMean)./covStd;
covTestZ = (covTest-covMean)./covStd;

designTrain = [ones(size(covTrainZ,1),1),covTrainZ];
designTest = [ones(size(covTestZ,1),1),covTestZ];

penalty = eye(size(designTrain,2));
penalty(1,1) = 0;
lambda = 1e-6;

beta = (designTrain'*designTrain+lambda*penalty)\(designTrain'*XTrain);
trainCorrected = XTrain-designTrain*beta;
testCorrected = XTest-designTest*beta;
end

function medianValues = finiteColumnMedian(X)
medianValues = zeros(1,size(X,2));
for i = 1:size(X,2)
    values = X(isfinite(X(:,i)),i);
    if isempty(values)
        medianValues(i) = 0;
    else
        medianValues(i) = median(values);
    end
end
end

function X = replaceNonfinite(X,replacement)
for i = 1:size(X,2)
    invalid = ~isfinite(X(:,i));
    X(invalid,i) = replacement(i);
end
end

function metrics = calculateMetrics(yTrue,yPred,score)
yTrue = double(yTrue(:));
yPred = double(yPred(:));
score = double(score(:));

TN = sum(yTrue==0 & yPred==0);
FP = sum(yTrue==0 & yPred==1);
FN = sum(yTrue==1 & yPred==0);
TP = sum(yTrue==1 & yPred==1);

metrics = struct();
metrics.Accuracy = (TP+TN)/max(TP+TN+FP+FN,1);
metrics.Sensitivity = TP/max(TP+FN,1);
metrics.Specificity = TN/max(TN+FP,1);
precision = TP/max(TP+FP,1);
metrics.F1 = 2*precision*metrics.Sensitivity / ...
    max(precision+metrics.Sensitivity,eps);
metrics.BalancedAccuracy = ...
    (metrics.Sensitivity+metrics.Specificity)/2;
den = sqrt(max((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN),eps));
metrics.MCC = (TP*TN-FP*FN)/den;
metrics.AUC = calculateAUC(yTrue,score);
metrics.ConfusionMatrix = [TN FP; FN TP];
end

function auc = calculateAUC(y,score)
pos = score(y==1);
neg = score(y==0);
cmp = pos(:)>neg(:).';
ties = pos(:)==neg(:).';
auc = (sum(cmp(:))+0.5*sum(ties(:))) / max(numel(pos)*numel(neg),1);
end

function [fpr,tpr,auc] = buildROC(y,score)
y = double(y(:));
score = double(score(:));

[scoreSorted,idx] = sort(score,'descend');
ySorted = y(idx);

P = sum(ySorted==1);
N = sum(ySorted==0);

tp = cumsum(ySorted==1);
fp = cumsum(ySorted==0);

changeIdx = [find(diff(scoreSorted)~=0); numel(scoreSorted)];
tpr = [0; tp(changeIdx)/max(P,1); 1];
fpr = [0; fp(changeIdx)/max(N,1); 1];

[fpr,uniqIdx] = unique(fpr,'stable');
tpr = tpr(uniqIdx);
auc = trapz(fpr,tpr);
end
