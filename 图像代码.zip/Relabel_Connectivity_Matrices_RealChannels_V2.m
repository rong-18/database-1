function Relabel_Connectivity_Matrices_RealChannels_V2
% ============================================================
% 将三个数据集的重要 PLV / Granger 连接矩阵中的 Ch1...ChN
% 替换为真实 EEG 通道名称，并重新生成整合图。
%
% V2 修正：
%   MPHCED02 的 EC 和 EO 不再合并为一张 4×3 图，
%   而是分别生成两张独立的 2×3 图：
%     MPHCED02_EC_Connectivity_Combined.png
%     MPHCED02_EO_Connectivity_Combined.png
%
% 不重新计算任何 PLV / Granger 数值，仅修改行列标签。
%
% 输入目录：
% D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices
%
% 会直接覆盖各 Excel 工作簿中的 3 个矩阵 sheet：
%   ControlImportant
%   PatientImportant
%   DifferenceImportant
%
% 输出图：
%   SAHARAN12_G01_Connectivity_Combined.png
%   MPHCED02_EC_Connectivity_Combined.png
%   MPHCED02_EO_Connectivity_Combined.png
%   MSU01_Connectivity_Combined.png
% ============================================================

clc;
close all;

rootDir = 'D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices';

if ~isfolder(rootDir)
    error('未找到连接矩阵目录：%s', rootDir);
end

%% ============================================================
% 1. 三个数据集的真实通道顺序
%% ============================================================

g01Names = { ...
    'AF3','F7','F3','FC5','T7','P7','O1', ...
    'O2','P8','T8','FC6','F4','F8','AF4'};

mphcedNames = { ...
    'Fp1','F3','C3','P3','O1','F7','T3','T5','Fz', ...
    'Fp2','F4','C4','P4','O2','F8','T4','T6','Cz','Pz'};

msuNames = { ...
    'F7','F3','F4','F8','T3','C3','Cz','C4','T4', ...
    'T5','P3','Pz','P4','T6','O1','O2'};

fprintf('====================================================\n');
fprintf('开始替换三个数据集连接矩阵的真实 EEG 通道名称\n');
fprintf('仅修改标签，不改变任何矩阵数值。\n');
fprintf('MPHCED02 的 EC / EO 将分别输出独立图。\n');
fprintf('====================================================\n\n');

%% ============================================================
% 2. SAHARAN12-G01
%% ============================================================

g01Dir = fullfile(rootDir,'SAHARAN12_G01');

fprintf('\n========== SAHARAN12-G01 ==========\n');

relabelConnectivityWorkbook( ...
    fullfile(g01Dir,'PLV_important_connectivity.xlsx'), ...
    g01Names,'SAHARAN12-G01 PLV');

relabelConnectivityWorkbook( ...
    fullfile(g01Dir,'Granger_important_connectivity.xlsx'), ...
    g01Names,'SAHARAN12-G01 Granger');

%% ============================================================
% 3. MPHCED02-EC
%% ============================================================

ecDir = fullfile(rootDir,'MPHCED02_EC');

fprintf('\n========== MPHCED02-EC ==========\n');

relabelConnectivityWorkbook( ...
    fullfile(ecDir,'PLV_important_connectivity.xlsx'), ...
    mphcedNames,'MPHCED02-EC PLV');

relabelConnectivityWorkbook( ...
    fullfile(ecDir,'Granger_important_connectivity.xlsx'), ...
    mphcedNames,'MPHCED02-EC Granger');

%% ============================================================
% 4. MPHCED02-EO
%% ============================================================

eoDir = fullfile(rootDir,'MPHCED02_EO');

fprintf('\n========== MPHCED02-EO ==========\n');

relabelConnectivityWorkbook( ...
    fullfile(eoDir,'PLV_important_connectivity.xlsx'), ...
    mphcedNames,'MPHCED02-EO PLV');

relabelConnectivityWorkbook( ...
    fullfile(eoDir,'Granger_important_connectivity.xlsx'), ...
    mphcedNames,'MPHCED02-EO Granger');

%% ============================================================
% 5. MSU01
%% ============================================================

msuDir = fullfile(rootDir,'MSU01');

fprintf('\n========== MSU01 ==========\n');

relabelConnectivityWorkbook( ...
    fullfile(msuDir,'PLV_important_connectivity.xlsx'), ...
    msuNames,'MSU01 PLV');

relabelConnectivityWorkbook( ...
    fullfile(msuDir,'Granger_important_connectivity.xlsx'), ...
    msuNames,'MSU01 Granger');

%% ============================================================
% 6. 重新生成 4 张独立图
%% ============================================================

fprintf('\n====================================================\n');
fprintf('Excel 标签替换完成，开始重新生成连接矩阵图...\n');
fprintf('====================================================\n');

makeTwoRowFigure( ...
    g01Dir, ...
    'SAHARAN12-G01', ...
    g01Names, ...
    fullfile(rootDir,'SAHARAN12_G01_Connectivity_Combined.png'));

makeTwoRowFigure( ...
    ecDir, ...
    'MPHCED02-EC', ...
    mphcedNames, ...
    fullfile(rootDir,'MPHCED02_EC_Connectivity_Combined.png'));

makeTwoRowFigure( ...
    eoDir, ...
    'MPHCED02-EO', ...
    mphcedNames, ...
    fullfile(rootDir,'MPHCED02_EO_Connectivity_Combined.png'));

makeTwoRowFigure( ...
    msuDir, ...
    'MSU01', ...
    msuNames, ...
    fullfile(rootDir,'MSU01_Connectivity_Combined.png'));

%% ============================================================
% 7. 输出映射核对文件
%% ============================================================

reportFile = fullfile(rootDir,'Real_Channel_Name_Mapping.txt');

fid = fopen(reportFile,'w','n','UTF-8');

if fid >= 0

    fprintf(fid,'Real EEG channel mapping used for connectivity matrices\n');
    fprintf(fid,'Generated: %s\n\n',datestr(now));

    writeMapping(fid,'SAHARAN12-G01',g01Names);
    writeMapping(fid,'MPHCED02-EC',mphcedNames);
    writeMapping(fid,'MPHCED02-EO',mphcedNames);
    writeMapping(fid,'MSU01',msuNames);

    fprintf(fid,['NOTE FOR G01:\n' ...
        'The mapping assumes that Ch1-Ch14 preserve the original ' ...
        'EMOTIV EPOC channel order.\n']);

    fclose(fid);
end

fprintf('\n====================================================\n');
fprintf('全部完成。\n');
fprintf('MPHCED02-EC 和 MPHCED02-EO 已分开输出。\n');
fprintf('映射核对文件：%s\n',reportFile);
fprintf('====================================================\n');

end


%% ============================================================
% 修改 Excel 中矩阵 sheet 的行列名称
%% ============================================================
function relabelConnectivityWorkbook(fileName,channelNames,description)

if ~isfile(fileName)
    error('未找到文件：%s',fileName);
end

sheetNames = { ...
    'ControlImportant', ...
    'PatientImportant', ...
    'DifferenceImportant'};

nExpected = numel(channelNames);

fprintf('\n%s\n',description);
fprintf('文件：%s\n',fileName);

for s = 1:numel(sheetNames)

    sheetName = sheetNames{s};

    T = readtable( ...
        fileName, ...
        'Sheet',sheetName, ...
        'ReadRowNames',true, ...
        'VariableNamingRule','preserve');

    M = table2array(T);

    if size(M,1) ~= nExpected || size(M,2) ~= nExpected

        error([ ...
            '%s 的 %s 尺寸为 %d×%d，但真实通道数为 %d。\n' ...
            '程序已停止，未对该 sheet 进行错误重标。'], ...
            fileName,sheetName,size(M,1),size(M,2),nExpected);
    end

    oldNames = T.Properties.RowNames;

    fprintf('  %s：%d×%d\n',sheetName,size(M,1),size(M,2));

    if ~isempty(oldNames)
        fprintf('    原标签：%s ... %s\n', ...
            oldNames{1},oldNames{end});
    end

    fprintf('    新标签：%s ... %s\n', ...
        channelNames{1},channelNames{end});

    Tout = array2table( ...
        M, ...
        'VariableNames',channelNames);

    Tout.Properties.RowNames = channelNames(:);

    writetable( ...
        Tout, ...
        fileName, ...
        'Sheet',sheetName, ...
        'WriteRowNames',true, ...
        'WriteMode','overwritesheet');
end

Tcheck = readtable( ...
    fileName, ...
    'Sheet','ControlImportant', ...
    'ReadRowNames',true, ...
    'VariableNamingRule','preserve');

if ~isequal(Tcheck.Properties.RowNames(:),channelNames(:))
    error('%s 写入后行名称校验失败。',description);
end

if ~isequal(Tcheck.Properties.VariableNames(:),channelNames(:))
    error('%s 写入后列名称校验失败。',description);
end

fprintf('  -> 行列标签替换并校验成功。\n');

end


%% ============================================================
% 每个数据集 / 状态：2×3
%% ============================================================
function makeTwoRowFigure(dataDir,datasetName,names,saveFile)

[plvC,plvP,plvD] = readImportantMatrices( ...
    fullfile(dataDir,'PLV_important_connectivity.xlsx'),names);

[gcC,gcP,gcD] = readImportantMatrices( ...
    fullfile(dataDir,'Granger_important_connectivity.xlsx'),names);

fig = figure( ...
    'Color','w', ...
    'Position',[80 80 1500 980], ...
    'Visible','off', ...
    'ToolBar','none', ...
    'MenuBar','none', ...
    'NumberTitle','off');

t = tiledlayout(fig,2,3, ...
    'Padding','loose', ...
    'TileSpacing','loose');

%% PLV
plvMeanLim = commonPositiveLimit(plvC,plvP);
plvDiffLim = symmetricLimit(plvD);

ax = nexttile(t);
drawMatrix(ax,plvC,names,[0 plvMeanLim],false);
title(ax,'PLV - Control','FontWeight','bold');
addPanelLabelBelow(ax,'(a)');

ax = nexttile(t);
drawMatrix(ax,plvP,names,[0 plvMeanLim],false);
title(ax,'PLV - Patient','FontWeight','bold');
addPanelLabelBelow(ax,'(b)');

ax = nexttile(t);
drawMatrix(ax,plvD,names,[-plvDiffLim plvDiffLim],true);
title(ax,'PLV - Patient - Control','FontWeight','bold');
addPanelLabelBelow(ax,'(c)');

%% Granger
gcMeanLim = commonPositiveLimit(gcC,gcP);
gcDiffLim = symmetricLimit(gcD);

ax = nexttile(t);
drawMatrix(ax,gcC,names,[0 gcMeanLim],false);
title(ax,'Granger - Control','FontWeight','bold');
addPanelLabelBelow(ax,'(d)');

ax = nexttile(t);
drawMatrix(ax,gcP,names,[0 gcMeanLim],false);
title(ax,'Granger - Patient','FontWeight','bold');
addPanelLabelBelow(ax,'(e)');

ax = nexttile(t);
drawMatrix(ax,gcD,names,[-gcDiffLim gcDiffLim],true);
title(ax,'Granger - Patient - Control','FontWeight','bold');
addPanelLabelBelow(ax,'(f)');

title(t, ...
    [datasetName ' | Important PLV and Granger Connections'], ...
    'FontWeight','bold', ...
    'FontSize',15);

drawnow;
exportgraphics(fig,saveFile,'Resolution',300);
close(fig);

fprintf('%s 图已覆盖/生成：%s\n',datasetName,saveFile);

end


%% ============================================================
% 读取矩阵并核验通道标签
%% ============================================================
function [C,P,D] = readImportantMatrices(fileName,expectedNames)

C = readMatrixSheet(fileName,'ControlImportant',expectedNames);
P = readMatrixSheet(fileName,'PatientImportant',expectedNames);
D = readMatrixSheet(fileName,'DifferenceImportant',expectedNames);

end


function M = readMatrixSheet(fileName,sheetName,expectedNames)

T = readtable( ...
    fileName, ...
    'Sheet',sheetName, ...
    'ReadRowNames',true, ...
    'VariableNamingRule','preserve');

M = table2array(T);

n = numel(expectedNames);

if size(M,1)~=n || size(M,2)~=n
    error('%s / %s 的矩阵维数不是 %d×%d。', ...
        fileName,sheetName,n,n);
end

if ~isequal(T.Properties.RowNames(:),expectedNames(:))
    error('%s / %s 的行标签与预期真实通道名不一致。', ...
        fileName,sheetName);
end

if ~isequal(T.Properties.VariableNames(:),expectedNames(:))
    error('%s / %s 的列标签与预期真实通道名不一致。', ...
        fileName,sheetName);
end

end


%% ============================================================
% 绘图
%% ============================================================
function drawMatrix(ax,M,names,limits,useDiverging)

imagesc(ax,M,'AlphaData',~isnan(M));
axis(ax,'square');

set(ax, ...
    'Color',[1 1 1], ...
    'XTick',1:numel(names), ...
    'YTick',1:numel(names), ...
    'XTickLabel',names, ...
    'YTickLabel',names, ...
    'XTickLabelRotation',45, ...
    'FontName','Times New Roman', ...
    'FontSize',8, ...
    'TickLength',[0 0]);

try
    ax.Toolbar.Visible = 'off';
catch
end

try
    disableDefaultInteractivity(ax);
catch
end

if useDiverging
    colormap(ax,blueWhiteRed(256));
else
    colormap(ax,parula(256));
end

caxis(ax,limits);

cb = colorbar(ax);
cb.FontName = 'Times New Roman';
cb.FontSize = 8;

end


function addPanelLabelBelow(ax,labelText)

xlabel(ax,labelText, ...
    'FontName','Times New Roman', ...
    'FontSize',11, ...
    'FontWeight','bold');

end


%% ============================================================
% 色标
%% ============================================================
function lim = commonPositiveLimit(A,B)

values = [A(~isnan(A)); B(~isnan(B))];

if isempty(values)
    lim = 1;
    return;
end

lim = max(values);

if ~isfinite(lim) || lim<=0
    lim = 1;
end

end


function lim = symmetricLimit(A)

values = abs(A(~isnan(A)));

if isempty(values)
    lim = 1;
    return;
end

lim = max(values);

if ~isfinite(lim) || lim<=0
    lim = 1;
end

end


%% ============================================================
% 红-白-蓝色图
%% ============================================================
function cmap = blueWhiteRed(m)

if nargin<1
    m = 256;
end

x = [0 0.5 1];

r = interp1(x,[0 1 1],linspace(0,1,m));
g = interp1(x,[0 1 0],linspace(0,1,m));
b = interp1(x,[1 1 0],linspace(0,1,m));

cmap = [r(:) g(:) b(:)];

end


%% ============================================================
% 映射报告
%% ============================================================
function writeMapping(fid,datasetName,names)

fprintf(fid,'%s\n',datasetName);

for i = 1:numel(names)
    fprintf(fid,'Ch%d -> %s\n',i,names{i});
end

fprintf(fid,'\n');

end
