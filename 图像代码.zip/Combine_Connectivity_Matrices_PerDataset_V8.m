function Combine_Connectivity_Matrices_PerDataset_V8
% 每个数据集一张整合图（手工布局版）
%
% V8目的：
% - 只把“横向距离”收紧
% - 保持“纵向距离”正常，不让上下图连在一起
% - 不再依赖 tiledlayout 的统一间距
% - 改为手工控制：
%     hGap = 列间距（更小）
%     vGap = 行间距（正常）
%
% 输入目录：
% D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices
%
% 输出：
% 1) SAHARAN12_G01_Connectivity_Combined.png
% 2) MPHCED02_Connectivity_Combined.png
% 3) MSU01_Connectivity_Combined.png

clc;
close all;

rootDir = 'D:\Database\EEG_Paper_Figures\Important_Connectivity_Matrices';

if ~exist(rootDir,'dir')
    error('未找到结果目录：%s',rootDir);
end

fprintf('开始生成每个数据集的手工布局紧凑版整合图...\n');
fprintf('结果目录：%s\n\n',rootDir);

style = getStyle();

makeTwoRowFigure( ...
    fullfile(rootDir,'SAHARAN12_G01'), ...
    'SAHARAN12-G01', ...
    fullfile(rootDir,'SAHARAN12_G01_Connectivity_Combined.png'), ...
    style);

makeMPHCEDFigure( ...
    fullfile(rootDir,'MPHCED02_EC'), ...
    fullfile(rootDir,'MPHCED02_EO'), ...
    fullfile(rootDir,'MPHCED02_Connectivity_Combined.png'), ...
    style);

makeTwoRowFigure( ...
    fullfile(rootDir,'MSU01'), ...
    'MSU01', ...
    fullfile(rootDir,'MSU01_Connectivity_Combined.png'), ...
    style);

fprintf('\n全部完成。\n');
end

%% =========================================================
%% 样式：横向更紧，纵向正常
%% =========================================================
function style = getStyle()

style = struct();

style.FontName = 'Arial';
style.MainTitleSize = 15;
style.SubTitleSize = 10;
style.AxisFontSize = 8;
style.PanelLabelSize = 9;

style.FigureWidth = 1260;
style.RowHeight = 330;

% 手工布局参数
style.LeftMargin = 0.035;
style.RightMargin = 0.025;
style.TopMargin = 0.065;
style.BottomMargin = 0.040;

% 关键：横向更紧，纵向保持正常
style.HorizontalGap = 0.018;
style.VerticalGap = 0.090;

% 每个子图内部给 colorbar 的空间
style.ColorbarGap = 0.004;
style.ColorbarWidth = 0.012;

% 给子图标题和下方(a)(b)(c)编号预留空间
style.TitleReserve = 0.020;
style.LabelReserve = 0.055;

style.ExportResolution = 400;
end

%% =========================================================
%% G01 / MSU01：2×3
%% =========================================================
function makeTwoRowFigure(dataDir,datasetName,saveFile,style)

plvFile = fullfile(dataDir,'PLV_important_connectivity.xlsx');
gcFile = fullfile(dataDir,'Granger_important_connectivity.xlsx');

[plvC,plvP,plvD,names] = readImportantMatrices(plvFile);
[gcC,gcP,gcD,~] = readImportantMatrices(gcFile);

fig = createFigure(style,2);

% 主标题
annotation(fig,'textbox',[0 0.965 1 0.03], ...
    'String',[datasetName ' | Important PLV and Granger Connections'], ...
    'EdgeColor','none', ...
    'HorizontalAlignment','center', ...
    'VerticalAlignment','middle', ...
    'FontName',style.FontName, ...
    'FontSize',style.MainTitleSize, ...
    'FontWeight','bold');

plvMeanLim = commonPositiveLimit(plvC,plvP);
plvDiffLim = symmetricLimit(plvD);

gcMeanLim = commonPositiveLimit(gcC,gcP);
gcDiffLim = symmetricLimit(gcD);

row1 = {
    plvC, 'PLV - Control', [0 plvMeanLim], false, '(a)';
    plvP, 'PLV - Patient', [0 plvMeanLim], false, '(b)';
    plvD, 'PLV - Patient - Control', [-plvDiffLim plvDiffLim], true, '(c)'};

row2 = {
    gcC, 'Granger - Control', [0 gcMeanLim], false, '(d)';
    gcP, 'Granger - Patient', [0 gcMeanLim], false, '(e)';
    gcD, 'Granger - Patient - Control', [-gcDiffLim gcDiffLim], true, '(f)'};

drawManualRow(fig,1,2,3,row1,names,style);
drawManualRow(fig,2,2,3,row2,names,style);

drawnow;
exportgraphics(fig,saveFile,'Resolution',style.ExportResolution);
close(fig);

fprintf('%s 完成：%s\n',datasetName,saveFile);
end

%% =========================================================
%% MPHCED02：4×3
%% =========================================================
function makeMPHCEDFigure(ecDir,eoDir,saveFile,style)

[ecPlvC,ecPlvP,ecPlvD,names] = ...
    readImportantMatrices(fullfile(ecDir,'PLV_important_connectivity.xlsx'));
[ecGcC,ecGcP,ecGcD,~] = ...
    readImportantMatrices(fullfile(ecDir,'Granger_important_connectivity.xlsx'));

[eoPlvC,eoPlvP,eoPlvD,~] = ...
    readImportantMatrices(fullfile(eoDir,'PLV_important_connectivity.xlsx'));
[eoGcC,eoGcP,eoGcD,~] = ...
    readImportantMatrices(fullfile(eoDir,'Granger_important_connectivity.xlsx'));

fig = createFigure(style,4);

annotation(fig,'textbox',[0 0.97 1 0.025], ...
    'String','MPHCED02 | Important PLV and Granger Connections', ...
    'EdgeColor','none', ...
    'HorizontalAlignment','center', ...
    'VerticalAlignment','middle', ...
    'FontName',style.FontName, ...
    'FontSize',style.MainTitleSize, ...
    'FontWeight','bold');

plvMeanLim = max( ...
    commonPositiveLimit(ecPlvC,ecPlvP), ...
    commonPositiveLimit(eoPlvC,eoPlvP));

plvDiffLim = max( ...
    symmetricLimit(ecPlvD), ...
    symmetricLimit(eoPlvD));

gcMeanLim = max( ...
    commonPositiveLimit(ecGcC,ecGcP), ...
    commonPositiveLimit(eoGcC,eoGcP));

gcDiffLim = max( ...
    symmetricLimit(ecGcD), ...
    symmetricLimit(eoGcD));

row1 = {
    ecPlvC, 'EC - PLV - Control', [0 plvMeanLim], false, '(a)';
    ecPlvP, 'EC - PLV - Patient', [0 plvMeanLim], false, '(b)';
    ecPlvD, 'EC - PLV - Patient - Control', [-plvDiffLim plvDiffLim], true, '(c)'};

row2 = {
    ecGcC, 'EC - Granger - Control', [0 gcMeanLim], false, '(d)';
    ecGcP, 'EC - Granger - Patient', [0 gcMeanLim], false, '(e)';
    ecGcD, 'EC - Granger - Patient - Control', [-gcDiffLim gcDiffLim], true, '(f)'};

row3 = {
    eoPlvC, 'EO - PLV - Control', [0 plvMeanLim], false, '(g)';
    eoPlvP, 'EO - PLV - Patient', [0 plvMeanLim], false, '(h)';
    eoPlvD, 'EO - PLV - Patient - Control', [-plvDiffLim plvDiffLim], true, '(i)'};

row4 = {
    eoGcC, 'EO - Granger - Control', [0 gcMeanLim], false, '(j)';
    eoGcP, 'EO - Granger - Patient', [0 gcMeanLim], false, '(k)';
    eoGcD, 'EO - Granger - Patient - Control', [-gcDiffLim gcDiffLim], true, '(l)'};

drawManualRow(fig,1,4,3,row1,names,style);
drawManualRow(fig,2,4,3,row2,names,style);
drawManualRow(fig,3,4,3,row3,names,style);
drawManualRow(fig,4,4,3,row4,names,style);

drawnow;
exportgraphics(fig,saveFile,'Resolution',style.ExportResolution);
close(fig);

fprintf('MPHCED02 完成：%s\n',saveFile);
end

%% =========================================================
%% 手工绘制一整行
%% =========================================================
function drawManualRow(fig,rowIndex,nRows,nCols,rowSpec,names,style)

for colIndex = 1:nCols
    tilePos = getTilePosition(rowIndex,colIndex,nRows,nCols,style);

    % 当前tile中，主坐标轴 + colorbar 的实际位置
    axPos = [ ...
        tilePos(1), ...
        tilePos(2) + style.LabelReserve, ...
        tilePos(3) - style.ColorbarGap - style.ColorbarWidth, ...
        tilePos(4) - style.LabelReserve - style.TitleReserve];

    cbPos = [ ...
        axPos(1) + axPos(3) + style.ColorbarGap, ...
        axPos(2), ...
        style.ColorbarWidth, ...
        axPos(4)];

    M = rowSpec{colIndex,1};
    subtitleText = rowSpec{colIndex,2};
    limits = rowSpec{colIndex,3};
    useDiverging = rowSpec{colIndex,4};
    panelText = rowSpec{colIndex,5};

    ax = axes(fig,'Position',axPos); %#ok<LAXES>
    drawMatrix(ax,M,names,limits,useDiverging,style,cbPos);

    title(ax,subtitleText, ...
        'FontWeight','bold', ...
        'FontName',style.FontName, ...
        'FontSize',style.SubTitleSize);

    xlabel(ax,panelText, ...
        'FontName',style.FontName, ...
        'FontSize',style.PanelLabelSize, ...
        'FontWeight','bold');
end
end

%% =========================================================
%% 计算单个tile位置
%% =========================================================
function pos = getTilePosition(rowIndex,colIndex,nRows,nCols,style)

usableW = 1 - style.LeftMargin - style.RightMargin;
usableH = 1 - style.TopMargin - style.BottomMargin;

tileW = (usableW - (nCols-1)*style.HorizontalGap) / nCols;
tileH = (usableH - (nRows-1)*style.VerticalGap) / nRows;

left = style.LeftMargin + (colIndex-1)*(tileW + style.HorizontalGap);

bottom = 1 - style.TopMargin - rowIndex*tileH - (rowIndex-1)*style.VerticalGap;

pos = [left,bottom,tileW,tileH];
end

%% =========================================================
%% 创建Figure
%% =========================================================
function fig = createFigure(style,nRows)

figHeight = style.RowHeight * nRows;

fig = figure( ...
    'Color','w', ...
    'Position',[60 40 style.FigureWidth figHeight], ...
    'Visible','off', ...
    'ToolBar','none', ...
    'MenuBar','none', ...
    'NumberTitle','off');
end

%% =========================================================
%% Excel读取
%% =========================================================
function [C,P,D,names] = readImportantMatrices(fileName)

if ~isfile(fileName)
    error(['未找到结果文件：\n%s\n' ...
        '请先运行 Generate_Important_Connectivity_Matrices_V1。'], ...
        fileName);
end

[C,names] = readMatrixSheet(fileName,'ControlImportant');
[P,~] = readMatrixSheet(fileName,'PatientImportant');
[D,~] = readMatrixSheet(fileName,'DifferenceImportant');
end

function [M,names] = readMatrixSheet(fileName,sheetName)

T = readtable(fileName, ...
    'Sheet',sheetName, ...
    'ReadRowNames',true, ...
    'VariableNamingRule','preserve');

names = T.Properties.RowNames;
M = table2array(T);
end

%% =========================================================
%% 绘图
%% =========================================================
function drawMatrix(ax,M,names,limits,useDiverging,style,cbPos)

imagesc(ax,M,'AlphaData',~isnan(M));
axis(ax,'square');

set(ax, ...
    'Color',[1 1 1], ...
    'XTick',1:numel(names), ...
    'YTick',1:numel(names), ...
    'XTickLabel',names, ...
    'YTickLabel',names, ...
    'XTickLabelRotation',45, ...
    'FontName',style.FontName, ...
    'FontSize',style.AxisFontSize, ...
    'TickLength',[0 0], ...
    'LineWidth',0.7, ...
    'Box','on');

try
    ax.Toolbar.Visible = 'off';
catch
end

try
    disableDefaultInteractivity(ax);
catch
end

if useDiverging
    colormap(ax,blueWhiteRed(256));
else
    colormap(ax,parula(256));
end

caxis(ax,limits);

cb = colorbar(ax);
cb.Position = cbPos;
cb.FontName = style.FontName;
cb.FontSize = style.AxisFontSize;
cb.LineWidth = 0.7;
end

%% =========================================================
%% 色标范围
%% =========================================================
function lim = commonPositiveLimit(A,B)

values = [A(~isnan(A)); B(~isnan(B))];

if isempty(values)
    lim = 1;
    return;
end

lim = max(values);

if ~isfinite(lim) || lim<=0
    lim = 1;
end
end

function lim = symmetricLimit(A)

values = abs(A(~isnan(A)));

if isempty(values)
    lim = 1;
    return;
end

lim = max(values);

if ~isfinite(lim) || lim<=0
    lim = 1;
end
end

%% =========================================================
%% 红-白-蓝差异色图
%% =========================================================
function cmap = blueWhiteRed(m)

if nargin<1
    m = 256;
end

x = [0 0.5 1];

r = interp1(x,[0 1 1],linspace(0,1,m));
g = interp1(x,[0 1 0],linspace(0,1,m));
b = interp1(x,[1 1 0],linspace(0,1,m));

cmap = [r(:) g(:) b(:)];
end
